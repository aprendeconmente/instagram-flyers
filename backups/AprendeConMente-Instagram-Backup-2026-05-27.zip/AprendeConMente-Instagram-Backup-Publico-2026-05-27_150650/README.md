# Asistente de Instagram - Aprende con Mente

Asistente local y gratuito para crear publicaciones diarias de `@aprendeconmente.ar`.

## Estado actual

- Genera un flyer cuadrado y su caption cada dia, usando el logo y la identidad de Aprende con Mente.
- Alterna contenidos sobre alfabetización, atención, lectoescritura, funciones ejecutivas, regulación emocional y orientación a familias.
- Incluye un módulo de publicación mediante la API oficial de Instagram, a activar cuando la cuenta sea profesional y esté autorizada en Meta.
- La autorización se guarda cifrada con protección del usuario de Windows; no se almacena la contraseña de Instagram.

## Generar el post de hoy

```powershell
.\scripts\New-DailyPost.ps1 -Slot '1100'
```

Los archivos quedan en `output\AAAA-MM-DD\1100\` y `output\AAAA-MM-DD\1500\`.

## Programar generación diaria

```powershell
.\scripts\Register-DailyGenerationTask.ps1 -Slot '1100' -At '11:00'
.\scripts\Register-DailyGenerationTask.ps1 -Slot '1500' -At '15:00'
```

Esto crea una tarea de Windows que genera la publicacion, sube el flyer a GitHub y publica en Instagram. Si el horario paso mientras la computadora estaba apagada, intenta ejecutarla al volver a encenderse.

## Activación de publicación automática

Para publicar automáticamente faltan tres pasos externos:

1. Cambiar `@aprendeconmente.ar` a cuenta profesional en Instagram.
2. Crear una aplicación de Meta y autorizar la cuenta mediante **Instagram API with Instagram Login**. Esta ruta oficial no exige una Página de Facebook.
3. Elegir un alojamiento gratuito para que Meta pueda leer la imagen mediante una URL pública HTTPS. La API no toma archivos directamente desde el disco local.

La cuenta autorizada se almacena cifrada en `config\instagram.credential.xml`; solo el mismo usuario de Windows puede descifrarla. El archivo esta excluido de Git mediante `.gitignore`. Tambien se pueden usar variables de entorno para pruebas puntuales:

```powershell
$env:INSTAGRAM_USER_ID = '...'
$env:INSTAGRAM_ACCESS_TOKEN = '...'
.\scripts\Publish-InstagramPost.ps1 -PostDirectory '.\output\2026-05-27' -PublicImageUrl 'https://.../post.png'
```

El token se mantiene fuera de los archivos del proyecto.

## Imagenes publicas en GitHub

Instagram necesita descargar cada flyer desde una URL publica. Se usa el repositorio publico `aprendeconmente/instagram-flyers` y un token de GitHub limitado a ese unico repositorio con permiso `Contents: Read and write`.

El token se cifra localmente ejecutando:

```powershell
.\scripts\Protect-GitHubCredential.ps1 -TokenFile '.\config\.github-token.tmp'
```

Despues, el flujo completo diario es:

```powershell
.\scripts\Invoke-DailyPublish.ps1 -Slot '1100'
.\scripts\Invoke-DailyPublish.ps1 -Slot '1500'
```

## Datos de marca

Los textos, colores, WhatsApp y calendario están en `config\brand.json`.

## Biblioteca editorial

Las palabras y enfoques que inspiran los flyers futuros estan en `config\biblioteca-contenidos.json`. Incluye:

- voz de marca y palabras base;
- situaciones frecuentes de las familias;
- expresiones que no deben aparecer;
- una rotacion ampliada de mensajes para los flyers.

Al agregar un tema nuevo a `topics`, el asistente lo incorpora automaticamente en las publicaciones siguientes.

La direccion oficial `aprendeconmente.github.io/web` se incluye de forma visible en cada flyer generado.

La rotacion tambien incluye promociones diferenciadas de `Neuro Play`, con su web `neuroplayar.github.io/web` y mensajes orientados a juguetes educativos. Esas piezas no publican un telefono hasta confirmar el contacto comercial correcto de Neuro Play.

## Flyers detallados

El flujo diario utiliza flyers verticales `1080x1350` de estilo informativo, definidos en `config\flyers-detallados.json`. Actualmente rota piezas institucionales, taller de alfabetizacion, bases del aprendizaje, atencion, familias, lectoescritura e inclusion educativa.

`Neuro Play` aparece de forma promocional periodica dentro de la rotacion, manteniendo como foco principal a Aprende con Mente.

## Backup portable

Para respaldar el asistente, sus piezas generadas y las tareas de Windows:

```powershell
.\scripts\New-PortableBackup.ps1
```

El `.zip` resultante se guarda en `backups\`. Las credenciales no se incluyen porque estan cifradas para esta computadora y deben autorizarse nuevamente en una restauracion. Consultar `BACKUP-Y-RESTAURACION.md`.

Luego de la publicacion de las `15:00`, el asistente genera automaticamente una version segura del backup y la sube a la carpeta `backups/` del repositorio publico de GitHub. Esa version no contiene credenciales ni exportaciones XML de tareas con rutas locales.

## Lista diaria para crecimiento manual

Despues de la publicacion de las `15:00`, el asistente deja en el Escritorio un archivo de texto simple con 10 busquedas al azar para descubrir cuentas reales y contenidos afines. No requiere seguir ninguna cuenta.

Las busquedas editables estan en `config\seguimiento-diario.json`. Para generar una lista manualmente:

```powershell
.\scripts\New-DailyFollowSuggestions.ps1 -Force
```
