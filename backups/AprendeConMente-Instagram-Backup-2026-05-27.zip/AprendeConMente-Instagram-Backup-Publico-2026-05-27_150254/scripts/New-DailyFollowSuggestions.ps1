[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),
    [string]$OutputDirectory = ([Environment]::GetFolderPath('Desktop')),
    [switch]$Force,
    [switch]$PassThru
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$brand = Get-Content -LiteralPath (Join-Path $root 'config\brand.json') -Raw | ConvertFrom-Json
$config = Get-Content -LiteralPath (Join-Path $root 'config\seguimiento-diario.json') -Raw | ConvertFrom-Json
$dateKey = $Date.ToString('yyyy-MM-dd')
$displayDate = $Date.ToString('dd/MM/yyyy')
$quantity = [int]$config.cantidadDiaria
$searches = @($config.busquedas)
$days = [int][Math]::Floor(($Date.Date - [datetime]$brand.startDate).TotalDays)
$start = (((($days * $quantity) % $searches.Count) + $searches.Count) % $searches.Count)
$fileName = "$($config.nombreArchivo)-$dateKey.txt"
$filePath = Join-Path $OutputDirectory $fileName

if ((Test-Path -LiteralPath $filePath) -and -not $Force) {
    if ($PassThru) { Write-Output $filePath }
    else { Write-Output "Lista diaria ya existente: $filePath" }
    exit 0
}

New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("APRENDE CON MENTE - CUENTAS PARA REVISAR MANUALMENTE - $displayDate")
$lines.Add('================================================================')
$lines.Add('')
$lines.Add('Objetivo: revisar hasta 10 perfiles pertinentes y decidir manualmente a quién seguir.')
$lines.Add('Este archivo NO realiza seguimientos automáticos ni garantiza que una cuenta deba seguirse.')
$lines.Add('')
$lines.Add('Criterios:')
foreach ($criterion in $config.criterios) {
    $lines.Add("- $criterion")
}
$lines.Add('')
$lines.Add('LISTA DEL DÍA')
$lines.Add('-------------')
for ($i = 0; $i -lt $quantity; $i++) {
    $search = $searches[($start + $i) % $searches.Count]
    $number = $i + 1
    $lines.Add('')
    $lines.Add("$number. Buscar en Instagram: $($search.texto)")
    $lines.Add("   Por qué: $($search.motivo)")
    $lines.Add('   Cuenta elegida (si corresponde): @____________________________')
    $lines.Add('   Acción realizada: [ ] Seguir  [ ] Interactuar  [ ] Descartar')
}
$lines.Add('')
$lines.Add('Recordatorio: la calidad de la relación importa más que la cantidad de seguidores.')

[System.IO.File]::WriteAllLines($filePath, $lines, [System.Text.UTF8Encoding]::new($false))
if ($PassThru) {
    Write-Output $filePath
}
else {
    Write-Output "Lista diaria creada: $filePath"
}
