[CmdletBinding()]
param(
    [ValidateSet('1100', '1500')]
    [string]$Slot = '1100',
    [string]$At = '11:00'
)

$ErrorActionPreference = 'Stop'
$taskName = "AprendeConMente-PublicacionDiaria-$Slot"
$runner = Join-Path $PSScriptRoot 'Invoke-DailyPublish.ps1'
$powerShell = (Get-Command 'pwsh.exe' -ErrorAction Stop).Source
$time = [datetime]::ParseExact($At, 'HH:mm', [System.Globalization.CultureInfo]::InvariantCulture)
$action = New-ScheduledTaskAction -Execute $powerShell -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$runner`" -Slot $Slot"
$trigger = New-ScheduledTaskTrigger -Daily -At $time
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable

Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings -Description "Genera y publica el flyer diario de Aprende con Mente en Instagram ($Slot)." -Force | Out-Null
Write-Output "Tarea '$taskName' registrada para todos los días a las $At."
