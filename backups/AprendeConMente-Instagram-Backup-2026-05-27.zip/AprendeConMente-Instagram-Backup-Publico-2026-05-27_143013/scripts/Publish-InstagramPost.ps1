[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)]
    [string]$PostDirectory,
    [Parameter(Mandatory)]
    [string]$PublicImageUrl,
    [string]$ApiBase = 'https://graph.instagram.com/v25.0'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$captionPath = Join-Path $PostDirectory 'caption.txt'
$metadataPath = Join-Path $PostDirectory 'metadata.json'
$credentialPath = Join-Path $root 'config\instagram.credential.xml'

if (-not (Test-Path -LiteralPath $captionPath)) {
    throw "No se encontró caption.txt en $PostDirectory."
}
if ($env:INSTAGRAM_USER_ID -and $env:INSTAGRAM_ACCESS_TOKEN) {
    $instagramUserId = $env:INSTAGRAM_USER_ID
    $instagramAccessToken = $env:INSTAGRAM_ACCESS_TOKEN
}
elseif (Test-Path -LiteralPath $credentialPath) {
    $stored = Import-Clixml -LiteralPath $credentialPath
    $instagramUserId = $stored.UserId
    $credential = New-Object System.Management.Automation.PSCredential('instagram', $stored.AccessToken)
    $instagramAccessToken = $credential.GetNetworkCredential().Password
}
else {
    throw 'No se encontró la credencial de Instagram. Debe autorizarse la cuenta primero.'
}
if ($PublicImageUrl -notmatch '^https://') {
    throw 'Meta necesita una URL pública HTTPS para tomar la imagen.'
}

$caption = Get-Content -LiteralPath $captionPath -Raw
$createBody = @{
    image_url = $PublicImageUrl
    caption = $caption
    access_token = $instagramAccessToken
}
$createUri = "$ApiBase/$instagramUserId/media"

if (-not $PSCmdlet.ShouldProcess($createUri, 'Crear y publicar el post en Instagram')) {
    return
}

$container = Invoke-RestMethod -Method Post -Uri $createUri -Body $createBody
if (-not $container.id) {
    throw 'Meta no devolvió un identificador de publicación.'
}

$publishBody = @{
    creation_id = $container.id
    access_token = $instagramAccessToken
}
$publishUri = "$ApiBase/$instagramUserId/media_publish"
$published = Invoke-RestMethod -Method Post -Uri $publishUri -Body $publishBody

if (Test-Path -LiteralPath $metadataPath) {
    $metadata = Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json
    $metadata.published = $true
    $metadata | Add-Member -NotePropertyName instagramMediaId -NotePropertyValue $published.id -Force
    $metadata | Add-Member -NotePropertyName publishedAt -NotePropertyValue (Get-Date).ToString('o') -Force
    $metadata | ConvertTo-Json | Set-Content -LiteralPath $metadataPath -Encoding UTF8
}

Write-Output "Publicado en Instagram. Media ID: $($published.id)"
