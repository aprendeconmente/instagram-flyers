[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),
    [ValidateSet('1100', '1500')]
    [string]$Slot = '1100',
    [Parameter(Mandatory)]
    [string]$FlyerKey,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$brand = Get-Content -LiteralPath (Join-Path $root 'config\brand.json') -Raw | ConvertFrom-Json
$campaign = Get-Content -LiteralPath (Join-Path $root 'config\flyers-detallados.json') -Raw | ConvertFrom-Json
$flyer = @($campaign.flyers | Where-Object { $_.key -eq $FlyerKey })[0]
if (-not $flyer) { throw "No se encontró el flyer '$FlyerKey'." }

$dateKey = $Date.ToString('yyyy-MM-dd')
$outputDir = Join-Path $root "output\$dateKey\$Slot"
$imagePath = Join-Path $outputDir 'post.png'
$captionPath = Join-Path $outputDir 'caption.txt'
$metadataPath = Join-Path $outputDir 'metadata.json'
if ((Test-Path -LiteralPath $imagePath) -and -not $Force) {
    Write-Output "La publicación del $dateKey ($Slot) ya existe: $imagePath"
    exit 0
}
New-Item -ItemType Directory -Path $outputDir -Force | Out-Null

Add-Type -AssemblyName System.Drawing
function C([string]$hex) { [System.Drawing.ColorTranslator]::FromHtml($hex) }
function Font([string]$family, [float]$size, [System.Drawing.FontStyle]$style = [System.Drawing.FontStyle]::Regular) {
    New-Object System.Drawing.Font($family, $size, $style, [System.Drawing.GraphicsUnit]::Pixel)
}
function Rounded([float]$x, [float]$y, [float]$w, [float]$h, [float]$r) {
    $p = New-Object System.Drawing.Drawing2D.GraphicsPath
    $d = $r * 2
    $p.AddArc($x, $y, $d, $d, 180, 90); $p.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
    $p.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90); $p.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
    $p.CloseFigure(); $p
}
function Text($g, [string]$value, $font, $brush, [float]$x, [float]$y, [float]$w, [float]$h, [string]$align = 'Center') {
    $f = New-Object System.Drawing.StringFormat
    $f.Alignment = if ($align -eq 'Left') { [System.Drawing.StringAlignment]::Near } else { [System.Drawing.StringAlignment]::Center }
    $f.LineAlignment = [System.Drawing.StringAlignment]::Center
    $g.DrawString($value, $font, $brush, [System.Drawing.RectangleF]::new($x, $y, $w, $h), $f)
    $f.Dispose()
}
function Panel($g, $brush, [float]$x, [float]$y, [float]$w, [float]$h, [float]$r = 22) {
    if ($r -le 0) {
        $g.FillRectangle($brush, $x, $y, $w, $h)
        return
    }
    $p = Rounded $x $y $w $h $r; $g.FillPath($brush, $p); $p.Dispose()
}

$navy = New-Object System.Drawing.SolidBrush (C '#173B78')
$teal = New-Object System.Drawing.SolidBrush (C '#06AABF')
$pink = New-Object System.Drawing.SolidBrush (C '#EE4E86')
$yellow = New-Object System.Drawing.SolidBrush (C '#FFC534')
$purple = New-Object System.Drawing.SolidBrush (C '#654296')
$cream = New-Object System.Drawing.SolidBrush (C '#FFFCF5')
$softPink = New-Object System.Drawing.SolidBrush (C '#FFF0F4')
$softTeal = New-Object System.Drawing.SolidBrush (C '#EAF9F7')
$softYellow = New-Object System.Drawing.SolidBrush (C '#FFF5DA')
$white = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::White)

$bmp = New-Object System.Drawing.Bitmap 1080, 1350
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$g.FillRectangle($cream, 0, 0, 1080, 1350)

$isNeuroPlay = $flyer.key -eq 'neuroplay'
$logoPath = Join-Path $root 'assets\logo.png'
$logo = [System.Drawing.Image]::FromFile($logoPath)
$g.DrawImage($logo, 45, 35, 120, 120)

$brandFont = Font 'Segoe UI Semibold' 44 ([System.Drawing.FontStyle]::Bold)
$smallCaps = Font 'Segoe UI Semibold' 19 ([System.Drawing.FontStyle]::Bold)
$titleFont = Font 'Segoe UI Semibold' 49 ([System.Drawing.FontStyle]::Bold)
$titleSecondFont = Font 'Segoe UI Semibold' 45 ([System.Drawing.FontStyle]::Bold)
$statementFont = Font 'Segoe UI Semibold' 25 ([System.Drawing.FontStyle]::Bold)
$bodyFont = Font 'Segoe UI' 19
$itemFont = Font 'Segoe UI Semibold' 18 ([System.Drawing.FontStyle]::Bold)
$pillarFont = Font 'Segoe UI Semibold' 13 ([System.Drawing.FontStyle]::Bold)
$contactFont = Font 'Segoe UI Semibold' 25 ([System.Drawing.FontStyle]::Bold)
$closingFont = Font 'Segoe UI Semibold' 20 ([System.Drawing.FontStyle]::Italic)

Text $g ([string]$flyer.brand) $brandFont ($(if ($isNeuroPlay) { $teal } else { $purple })) 178 36 850 53 'Left'
$descriptor = if ($isNeuroPlay) { 'JUGUETES EDUCATIVOS CON PROPÓSITO' } else { 'ELISABET ESCOBAR | PSICOPEDAGOGA | +15 AÑOS' }
Text $g $descriptor $smallCaps $pink 180 94 850 32 'Left'

Panel $g $softPink 35 172 1010 178 28
Text $g ([string]$flyer.title) $titleFont $navy 58 190 964 62
if ($flyer.titleSecond) {
    Text $g ([string]$flyer.titleSecond) $titleSecondFont $teal 58 249 964 58
}
else {
    Text $g ([string]$flyer.subtitle) $bodyFont $navy 58 260 964 45
}
if ($flyer.titleSecond) {
    Text $g ([string]$flyer.subtitle) $smallCaps $pink 58 308 964 33
}

Text $g ([string]$flyer.statement).ToUpperInvariant() $statementFont $purple 35 373 1010 44

$pillarW = 190; $pillarX = 45; $pillarY = 430
$circleColors = @($teal, $purple, $yellow, $pink, $teal)
for ($i = 0; $i -lt $flyer.pillars.Count; $i++) {
    $x = $pillarX + ($i * 199)
    $g.FillEllipse($circleColors[$i], $x + 66, $pillarY, 56, 56)
    Text $g ([string]($i + 1)) (Font 'Segoe UI Semibold' 25 ([System.Drawing.FontStyle]::Bold)) $white ($x + 66) $pillarY 56 56
    Text $g ([string]$flyer.pillars[$i]) $pillarFont $navy $x ($pillarY + 63) $pillarW 42
}

Panel $g $softTeal 35 565 496 402 26
Panel $g $softYellow 550 565 495 402 26
Text $g ([string]$flyer.sectionTitle).ToUpperInvariant() $statementFont $teal 60 585 445 38 'Left'
$itemsY = 640
for ($j = 0; $j -lt $flyer.items.Count; $j++) {
    $g.FillEllipse($pink, 65, $itemsY + 8, 18, 18)
    Text $g ([string]$flyer.items[$j]) $itemFont $navy 100 $itemsY 398 42 'Left'
    $itemsY += 56
}

$explanation = if ($isNeuroPlay) {
    "Una selección pensada para que el juego divierta, estimule habilidades y acompañe el desarrollo infantil."
} else {
    "Cada intervención se realiza a través de estrategias lúdicas, pedagógicas y personalizadas, respetando el ritmo y las necesidades de cada niño."
}
Text $g $explanation $bodyFont $navy 580 605 435 128 'Left'
Panel $g $white 578 756 438 144 18
Text $g ([string]$flyer.closing) $closingFont $purple 604 771 390 112 'Left'

Panel $g $softPink 35 993 1010 160 25
$website = if ($flyer.websiteDisplay) { [string]$flyer.websiteDisplay } else { [string]$brand.websiteDisplay }
if ($flyer.showWhatsApp) {
    Text $g 'VILLA MAIPÚ - SAN MARTÍN' $smallCaps $purple 62 1014 450 35 'Left'
    Text $g ([string]$flyer.cta).ToUpperInvariant() $smallCaps $pink 62 1054 450 30 'Left'
    Text $g ([string]$brand.whatsappDisplay) $contactFont $navy 62 1085 450 43 'Left'
    Text $g $website $bodyFont $teal 548 1060 460 38
}
else {
    Text $g 'VILLA MAIPÚ - SAN MARTÍN' $smallCaps $purple 62 1026 950 34
    Text $g ([string]$flyer.cta).ToUpperInvariant() $smallCaps $pink 62 1067 950 30
    Text $g $website $contactFont $teal 62 1100 950 38
}

if ($flyer.crossPromo) {
    Panel $g $purple 35 1170 1010 70 22
    Text $g ([string]$flyer.crossPromo) $itemFont $white 56 1181 970 48
}
$footerY = if ($flyer.crossPromo) { 1260 } else { 1182 }
$footerText = if ($flyer.footer) { [string]$flyer.footer } else { 'Acompañar es crear condiciones para que cada niño pueda aprender.' }
Panel $g $purple 0 $footerY 1080 70 0
Text $g $footerText $bodyFont $white 28 $footerY 1024 70

$bmp.Save($imagePath, [System.Drawing.Imaging.ImageFormat]::Png)
$websiteCaption = if ($flyer.websiteUrl) { [string]$flyer.websiteUrl } else { [string]$brand.websiteUrl }
$contactBlock = if ($flyer.showWhatsApp) { "📍 $($brand.location)`n📲 WhatsApp: $($brand.whatsappDisplay)`n🌐 $websiteCaption" } else { "📍 Villa Maipú, San Martín`n🌐 $websiteCaption" }
$hashtags = if ($isNeuroPlay) { '#NeuroPlay #JuguetesEducativos #AprenderJugando #DesarrolloInfantil' } else { $brand.hashtags }
$caption = "$($flyer.caption)`n`n$contactBlock`n`n$hashtags"
[System.IO.File]::WriteAllText($captionPath, $caption, [System.Text.UTF8Encoding]::new($false))
[ordered]@{ date = $dateKey; slot = $Slot; topic = $flyer.key; layout = 'detallado'; image = $imagePath; caption = $captionPath; published = $false } |
    ConvertTo-Json | Set-Content -LiteralPath $metadataPath -Encoding UTF8

$logo.Dispose(); $bmp.Dispose(); $g.Dispose()
@($navy, $teal, $pink, $yellow, $purple, $cream, $softPink, $softTeal, $softYellow, $white,
  $brandFont, $smallCaps, $titleFont, $titleSecondFont, $statementFont, $bodyFont, $itemFont,
  $pillarFont, $contactFont, $closingFont) | ForEach-Object { $_.Dispose() }
Write-Output "Flyer detallado creado: $imagePath"
Write-Output "Caption creado: $captionPath"
