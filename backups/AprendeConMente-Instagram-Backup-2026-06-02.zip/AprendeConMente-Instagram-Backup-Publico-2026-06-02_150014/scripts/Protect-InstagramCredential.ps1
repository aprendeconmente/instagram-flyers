[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$TokenFile,
    [Parameter(Mandatory)]
    [string]$UserId
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$credentialPath = Join-Path $root 'config\instagram.credential.xml'

if (-not (Test-Path -LiteralPath $TokenFile)) {
    throw 'No se encontró el token temporal para proteger.'
}

$token = (Get-Content -LiteralPath $TokenFile -Raw).Trim()
if (-not $token) {
    throw 'El token temporal está vacío.'
}

$protected = [pscustomobject]@{
    UserId = $UserId
    AccessToken = ConvertTo-SecureString -String $token -AsPlainText -Force
    ProtectedAt = (Get-Date).ToString('o')
}
$protected | Export-Clixml -LiteralPath $credentialPath
Remove-Item -LiteralPath $TokenFile -Force

Write-Output "Credencial cifrada guardada para el usuario de Windows actual."
