[CmdletBinding()]
param(
    [string]$DestinationDirectory,
    [switch]$WithoutOutput,
    [switch]$PublicGitHub,
    [switch]$PassThru
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
if (-not $DestinationDirectory) {
    $DestinationDirectory = Join-Path $root 'backups'
}

$stamp = Get-Date -Format 'yyyy-MM-dd_HHmmss'
$packagePrefix = if ($PublicGitHub) { 'AprendeConMente-Instagram-Backup-Publico' } else { 'AprendeConMente-Instagram-Backup' }
$packageName = "$packagePrefix-$stamp"
$workingDirectory = Join-Path $DestinationDirectory $packageName
$zipPath = Join-Path $DestinationDirectory "$packageName.zip"

New-Item -ItemType Directory -Path $workingDirectory -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $workingDirectory 'tareas-windows') -Force | Out-Null

$files = @(
    '.gitignore',
    'README.md',
    'BACKUP-Y-RESTAURACION.md'
)
$directories = @(
    'assets',
    'scripts'
)
foreach ($file in $files) {
    Copy-Item -LiteralPath (Join-Path $root $file) -Destination (Join-Path $workingDirectory $file)
}
foreach ($directory in $directories) {
    Copy-Item -LiteralPath (Join-Path $root $directory) -Destination $workingDirectory -Recurse
}

$configDirectory = Join-Path $workingDirectory 'config'
New-Item -ItemType Directory -Path $configDirectory -Force | Out-Null
Get-ChildItem -LiteralPath (Join-Path $root 'config') -File |
    Where-Object { $_.Name -notlike '*.credential.xml' -and $_.Name -notlike '*.tmp' } |
    Copy-Item -Destination $configDirectory

if (-not $WithoutOutput -and (Test-Path -LiteralPath (Join-Path $root 'output'))) {
    Copy-Item -LiteralPath (Join-Path $root 'output') -Destination $workingDirectory -Recurse
}

$taskNames = @(
    'AprendeConMente-PublicacionDiaria-1100',
    'AprendeConMente-PublicacionDiaria-1500'
)
if ($PublicGitHub) {
    @'
Tareas automaticas a recrear al restaurar:

.\scripts\Register-DailyGenerationTask.ps1 -Slot '1100' -At '11:00'
.\scripts\Register-DailyGenerationTask.ps1 -Slot '1500' -At '15:00'

No se exportan XML de Windows en el backup publico porque contienen rutas locales.
'@ | Set-Content -LiteralPath (Join-Path $workingDirectory 'tareas-windows\RECREAR-TAREAS.txt') -Encoding UTF8
}
else {
    $taskSummary = foreach ($taskName in $taskNames) {
        $task = Get-ScheduledTask -TaskName $taskName
        $taskInfo = Get-ScheduledTaskInfo -TaskName $taskName
        Export-ScheduledTask -TaskName $taskName |
            Set-Content -LiteralPath (Join-Path $workingDirectory "tareas-windows\$taskName.xml") -Encoding Unicode
        [ordered]@{
            taskName = $taskName
            state = [string]$task.State
            nextRunTime = $taskInfo.NextRunTime.ToString('o')
            lastRunTime = $taskInfo.LastRunTime.ToString('o')
            lastTaskResult = $taskInfo.LastTaskResult
        }
    }
    $taskSummary | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $workingDirectory 'tareas-windows\estado.json') -Encoding UTF8
}

$manifest = [ordered]@{
    createdAt = (Get-Date).ToString('o')
    visibility = if ($PublicGitHub) { 'public-github' } else { 'private-local' }
    includedOutput = (-not $WithoutOutput)
    excludedForSecurity = @('config\instagram.credential.xml', 'config\github.credential.xml')
    restoreGuide = 'BACKUP-Y-RESTAURACION.md'
}
if (-not $PublicGitHub) {
    $manifest['sourceComputer'] = $env:COMPUTERNAME
}
$manifest | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $workingDirectory 'backup-manifest.json') -Encoding UTF8

if (Test-Path -LiteralPath $zipPath) {
    Remove-Item -LiteralPath $zipPath -Force
}
Compress-Archive -LiteralPath $workingDirectory -DestinationPath $zipPath -CompressionLevel Optimal

if ($PassThru) {
    Write-Output $zipPath
}
else {
    Write-Output "Backup creado: $zipPath"
    Write-Output 'Las credenciales no se incluyeron: deben autorizarse nuevamente al restaurar.'
}
