[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),

    [ValidateSet('1200', '1600')]
    [string]$Slot = '1200'
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot

$dateKey = $Date.ToString('yyyy-MM-dd')
$instagramSlot = if ($Slot -eq '1200') { '1100' } else { '1500' }

$postDirectory = Join-Path $root "output\$dateKey\$instagramSlot"
$imagePath = Join-Path $postDirectory 'post.png'
$captionPath = Join-Path $postDirectory 'caption.txt'
$metadataPath = Join-Path $postDirectory 'metadata.json'

Write-Host ""
Write-Host "========================================"
Write-Host " TEST PUBLICACION APRENDE CON MENTE"
Write-Host "========================================"
Write-Host ""

Write-Host "Fecha.............: $dateKey"
Write-Host "Slot Facebook.....: $Slot"
Write-Host "Slot Instagram....: $instagramSlot"
Write-Host ""

Write-Host "Validando archivos..."
Write-Host ""

if (Test-Path $postDirectory) {
    Write-Host "[OK] Carpeta encontrada"
}
else {
    Write-Host "[ERROR] No existe carpeta:"
    Write-Host $postDirectory
    exit 1
}

if (Test-Path $imagePath) {
    $file = Get-Item $imagePath

    Write-Host "[OK] Imagen encontrada"
    Write-Host "     Tamaño: $([math]::Round($file.Length / 1KB,2)) KB"
}
else {
    Write-Host "[ERROR] Falta post.png"
}

if (Test-Path $captionPath) {
    Write-Host "[OK] Caption encontrado"
}
else {
    Write-Host "[ERROR] Falta caption.txt"
}

if (Test-Path $metadataPath) {
    Write-Host "[OK] Metadata encontrada"

    try {
        $metadata = Get-Content $metadataPath -Raw | ConvertFrom-Json

        Write-Host ""
        Write-Host "METADATA"

        $metadata | Format-List
    }
    catch {
        Write-Host "[ERROR] Metadata invalida"
    }
}
else {
    Write-Host "[ERROR] Falta metadata.json"
}

Write-Host ""
Write-Host "PRIMERAS LINEAS DEL CAPTION"
Write-Host "--------------------------------"

if (Test-Path $captionPath) {
    Get-Content $captionPath | Select-Object -First 10
}

Write-Host ""
Write-Host "========================================"
Write-Host " FIN TEST"
Write-Host "========================================"