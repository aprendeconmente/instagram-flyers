[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$TokenFile,
    [string]$Repository = 'aprendeconmente/instagram-flyers'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$credentialPath = Join-Path $root 'config\github.credential.xml'

if (-not (Test-Path -LiteralPath $TokenFile)) {
    throw 'No se encontro el token temporal de GitHub.'
}

$token = (Get-Content -LiteralPath $TokenFile -Raw).Trim()
if (-not $token) {
    throw 'El token temporal de GitHub esta vacio.'
}

$protected = [pscustomobject]@{
    Repository = $Repository
    AccessToken = ConvertTo-SecureString -String $token -AsPlainText -Force
    ProtectedAt = (Get-Date).ToString('o')
}
$protected | Export-Clixml -LiteralPath $credentialPath
Remove-Item -LiteralPath $TokenFile -Force

Write-Output "Credencial de GitHub cifrada para el usuario de Windows actual."
