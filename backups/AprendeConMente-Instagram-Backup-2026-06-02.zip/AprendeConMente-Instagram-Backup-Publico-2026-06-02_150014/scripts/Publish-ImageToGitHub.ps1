[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$ImagePath,

    [Parameter(Mandatory)]
    [string]$DateKey,

    [string]$Slot = '',

    [string]$Branch = 'main',

    [int]$TimeoutSec = 60,

    [int]$MaxRetries = 3
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$credentialPath = Join-Path $root 'config\github.credential.xml'

if (-not (Test-Path -LiteralPath $ImagePath)) {
    throw "No se encontro la imagen: $ImagePath"
}

if (-not (Test-Path -LiteralPath $credentialPath)) {
    throw 'No se encontro la credencial de GitHub. Debe autorizarse el repositorio primero.'
}

$stored = Import-Clixml -LiteralPath $credentialPath
$credential = New-Object System.Management.Automation.PSCredential('github', $stored.AccessToken)
$accessToken = $credential.GetNetworkCredential().Password
$repository = $stored.Repository

if (-not $accessToken) {
    throw 'La credencial de GitHub no contiene AccessToken.'
}

if (-not $repository) {
    throw 'La credencial de GitHub no contiene Repository.'
}

$fileName = if ($Slot) {
    "$DateKey-$Slot.png"
}
else {
    "$DateKey.png"
}

$path = "posts/$fileName"
$apiUri = "https://api.github.com/repos/$repository/contents/$path"

$headers = @{
    Authorization = "Bearer $accessToken"
    Accept = 'application/vnd.github+json'
    'X-GitHub-Api-Version' = '2022-11-28'
}

function Test-RetryableGitHubError {
    param(
        [Parameter(Mandatory)]
        [string]$Message
    )

    return ($Message -match '429|500|502|503|504|timeout|timed out|temporarily unavailable|secondary rate limit|abuse detection')
}

function Get-GitHubErrorMessage {
    param(
        [Parameter(Mandatory)]
        $ErrorRecord
    )

    $body = $ErrorRecord.ErrorDetails.Message

    if (-not $body -and $ErrorRecord.Exception.Response) {
        try {
            $reader = New-Object System.IO.StreamReader($ErrorRecord.Exception.Response.GetResponseStream())
            $body = $reader.ReadToEnd()
        }
        catch {
            $body = $null
        }
    }

    if ($body) {
        try {
            $parsed = $body | ConvertFrom-Json

            if ($parsed.message) {
                return "$($ErrorRecord.Exception.Message) GitHub: $($parsed.message)"
            }
        }
        catch {
            return "$($ErrorRecord.Exception.Message) GitHub: $body"
        }
    }

    return $ErrorRecord.Exception.Message
}

function Invoke-WithRetry {
    param(
        [Parameter(Mandatory)]
        [scriptblock]$ScriptBlock,

        [int]$Retries = 3,

        [int]$InitialDelaySeconds = 5
    )

    $lastError = $null

    for ($attemptNumber = 1; $attemptNumber -le $Retries; $attemptNumber++) {
        try {
            return & $ScriptBlock
        }
        catch {
            $lastError = Get-GitHubErrorMessage $_

            if (-not (Test-RetryableGitHubError -Message $lastError)) {
                throw $lastError
            }

            if ($attemptNumber -ge $Retries) {
                break
            }

            $delay = $InitialDelaySeconds * $attemptNumber
            Write-Warning "Intento $attemptNumber de $Retries fallo. Reintentando en $delay segundos. Error: $lastError"
            Start-Sleep -Seconds $delay
        }
    }

    throw $lastError
}

$existingSha = $null

try {
    $existing = Invoke-WithRetry -Retries $MaxRetries -ScriptBlock {
        Invoke-RestMethod `
            -Method Get `
            -Uri "${apiUri}?ref=$Branch" `
            -Headers $headers `
            -TimeoutSec $TimeoutSec
    }

    $existingSha = $existing.sha
}
catch {
    $message = $_.Exception.Message

    if ($message -notmatch '404|Not Found') {
        throw $message
    }
}

$imageBytes = [IO.File]::ReadAllBytes((Resolve-Path -LiteralPath $ImagePath))

$body = [ordered]@{
    message = if ($Slot) { "Publicacion Instagram $DateKey $Slot" } else { "Publicacion Instagram $DateKey" }
    content = [Convert]::ToBase64String($imageBytes)
    branch = $Branch
}

if ($existingSha) {
    $body.sha = $existingSha
}

$result = Invoke-WithRetry -Retries $MaxRetries -ScriptBlock {
    Invoke-RestMethod `
        -Method Put `
        -Uri $apiUri `
        -Headers $headers `
        -ContentType 'application/json' `
        -Body ($body | ConvertTo-Json) `
        -TimeoutSec $TimeoutSec
}

$publicUrl = "https://raw.githubusercontent.com/$repository/$Branch/$path"

Write-Output $publicUrl