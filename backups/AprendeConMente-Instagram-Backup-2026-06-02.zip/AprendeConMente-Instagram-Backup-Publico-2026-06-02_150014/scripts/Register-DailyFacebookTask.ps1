[CmdletBinding()]
param(
    [ValidateSet('1200', '1600')]
    [string]$Slot = '1200',
    [string]$At = '12:00'
)

$ErrorActionPreference = 'Stop'
$taskName = "AprendeConMente-FacebookDiario-$Slot"
$root = Split-Path -Parent $PSScriptRoot
$runner = Join-Path $PSScriptRoot 'Invoke-DailyFacebookPublish.ps1'
$powerShell = (Get-Command 'pwsh.exe' -ErrorAction Stop).Source
$time = [datetime]::ParseExact($At, 'HH:mm', [System.Globalization.CultureInfo]::InvariantCulture)
$action = New-ScheduledTaskAction -Execute $powerShell -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$runner`" -Slot $Slot" -WorkingDirectory $root
$trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday,Tuesday,Wednesday,Thursday,Friday -At $time
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable

Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings -Description "Publica en Facebook el flyer ya utilizado por Instagram ($Slot)." -Force | Out-Null
Write-Output "Tarea '$taskName' registrada de lunes a viernes a las $At."
