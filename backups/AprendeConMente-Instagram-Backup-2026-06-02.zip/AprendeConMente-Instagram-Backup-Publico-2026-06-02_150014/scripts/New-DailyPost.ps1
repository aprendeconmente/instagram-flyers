[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),
    [ValidateSet('1100', '1500')]
    [string]$Slot = '1100',
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$configPath = Join-Path $root 'config\brand.json'
$libraryPath = Join-Path $root 'config\biblioteca-contenidos.json'
$detailedPath = Join-Path $root 'config\flyers-detallados.json'
$config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
$library = if (Test-Path -LiteralPath $libraryPath) {
    Get-Content -LiteralPath $libraryPath -Raw | ConvertFrom-Json
} else {
    $null
}

$days = [int][Math]::Floor(($Date.Date - [datetime]$config.startDate).TotalDays)
$detailed = if (Test-Path -LiteralPath $detailedPath) { Get-Content -LiteralPath $detailedPath -Raw | ConvertFrom-Json } else { $null }
$topics = if ($detailed) { @($detailed.flyers) } elseif ($library) { @($library.topics) } else { @($config.topics) }
$slotOffset = if ($Slot -eq '1500') { 1 } else { 0 }
$index = (((($days * 2) + $slotOffset) % $topics.Count) + $topics.Count) % $topics.Count
$topic = $topics[$index]
if ($detailed) {
    & (Join-Path $PSScriptRoot 'New-DetailedFlyer.ps1') -Date $Date -Slot $Slot -FlyerKey $topic.key -Force:$Force
    exit $LASTEXITCODE
}
$logoAsset = if ($topic.logoAsset) { [string]$topic.logoAsset } else { 'assets\logo.png' }
$logoPath = Join-Path $root $logoAsset
$brandName = if ($topic.brandName) { [string]$topic.brandName } else { [string]$config.businessName }
$professional = if ($topic.professional) { [string]$topic.professional } else { [string]$config.professional }
$credentialText = if ($topic.credential) { [string]$topic.credential } else { [string]$config.credential }
$locationText = if ($topic.location) { [string]$topic.location } else { [string]$config.location }
$websiteText = if ($topic.websiteDisplay) { [string]$topic.websiteDisplay } else { [string]$config.websiteDisplay }
$ctaText = if ($topic.ctaText) { [string]$topic.ctaText } else { "WhatsApp: $($config.whatsappDisplay)" }
$footerText = if ($topic.footerText) { [string]$topic.footerText } else { 'Atención psicopedagógica personalizada' }
$hashtags = if ($topic.hashtags) { [string]$topic.hashtags } else { [string]$config.hashtags }
$dateKey = $Date.ToString('yyyy-MM-dd')
$outputDir = Join-Path $root "output\$dateKey\$Slot"
$imagePath = Join-Path $outputDir 'post.png'
$captionPath = Join-Path $outputDir 'caption.txt'
$metadataPath = Join-Path $outputDir 'metadata.json'

if ((Test-Path -LiteralPath $imagePath) -and -not $Force) {
    Write-Output "La publicación del $dateKey ($Slot) ya existe: $imagePath"
    exit 0
}

New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
Add-Type -AssemblyName System.Drawing

function Color([string]$hex) {
    return [System.Drawing.ColorTranslator]::FromHtml($hex)
}

function New-RoundedRectanglePath([float]$x, [float]$y, [float]$width, [float]$height, [float]$radius) {
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $diameter = $radius * 2
    $path.AddArc($x, $y, $diameter, $diameter, 180, 90)
    $path.AddArc($x + $width - $diameter, $y, $diameter, $diameter, 270, 90)
    $path.AddArc($x + $width - $diameter, $y + $height - $diameter, $diameter, $diameter, 0, 90)
    $path.AddArc($x, $y + $height - $diameter, $diameter, $diameter, 90, 90)
    $path.CloseFigure()
    return $path
}

function Draw-CenteredText($graphics, [string]$text, $font, $brush, [float]$y, [float]$height) {
    $format = New-Object System.Drawing.StringFormat
    $format.Alignment = [System.Drawing.StringAlignment]::Center
    $format.LineAlignment = [System.Drawing.StringAlignment]::Center
    $graphics.DrawString($text, $font, $brush, [System.Drawing.RectangleF]::new(64, $y, 952, $height), $format)
    $format.Dispose()
}

$bitmap = New-Object System.Drawing.Bitmap 1080, 1080
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
$graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$graphics.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$graphics.Clear((Color $config.colors.cream))

$softBlue = New-Object System.Drawing.SolidBrush (Color $config.colors.softBlue)
$softYellow = New-Object System.Drawing.SolidBrush (Color $config.colors.softYellow)
$yellow = New-Object System.Drawing.SolidBrush (Color $config.colors.yellow)
$navy = New-Object System.Drawing.SolidBrush (Color $config.colors.navy)
$blue = New-Object System.Drawing.SolidBrush (Color $config.colors.blue)
$coral = New-Object System.Drawing.SolidBrush (Color $config.colors.coral)

$graphics.FillEllipse($softBlue, -170, -140, 520, 350)
$graphics.FillEllipse($softYellow, 840, 20, 300, 300)
$graphics.FillEllipse($softBlue, 860, 820, 320, 320)
$graphics.FillEllipse($softYellow, -190, 850, 360, 300)

$logo = [System.Drawing.Image]::FromFile($logoPath)
$logoHeight = 118
$logoWidth = [int]($logo.Width * ($logoHeight / $logo.Height))
$graphics.DrawImage($logo, [int]((1080 - $logoWidth) / 2), 48, $logoWidth, $logoHeight)

$brandFont = New-Object System.Drawing.Font('Segoe UI Semibold', 25, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
Draw-CenteredText $graphics $brandName $brandFont $navy 170 42

$headlineFont = New-Object System.Drawing.Font('Segoe UI Semibold', 63, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
$lineY = 257
$lineHeight = 82
for ($line = 0; $line -lt $topic.headline.Count; $line++) {
    if ($line -eq [int]$topic.highlightLine) {
        $measure = $graphics.MeasureString([string]$topic.headline[$line], $headlineFont)
        $highlightWidth = [Math]::Min(900, $measure.Width + 48)
        $path = New-RoundedRectanglePath ((1080 - $highlightWidth) / 2) ($lineY + 12) $highlightWidth 68 22
        $graphics.FillPath($yellow, $path)
        $path.Dispose()
    }
    Draw-CenteredText $graphics ([string]$topic.headline[$line]) $headlineFont $navy $lineY $lineHeight
    $lineY += $lineHeight
}

$bodyFont = New-Object System.Drawing.Font('Segoe UI', 30, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Pixel)
$bodyY = 535
foreach ($line in $topic.body) {
    Draw-CenteredText $graphics ([string]$line) $bodyFont $navy $bodyY 45
    $bodyY += 44
}

$separatorPen = New-Object System.Drawing.Pen (Color $config.colors.blue), 3
$graphics.DrawLine($separatorPen, 384, 660, 696, 660)

$nameFont = New-Object System.Drawing.Font('Segoe UI Semibold', 31, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
$smallFont = New-Object System.Drawing.Font('Segoe UI', 24, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Pixel)
Draw-CenteredText $graphics $professional $nameFont $navy 691 43
Draw-CenteredText $graphics $credentialText $smallFont $navy 735 38
Draw-CenteredText $graphics $locationText $smallFont $navy 790 38

$buttonPath = New-RoundedRectanglePath 237 858 606 78 34
$graphics.FillPath($yellow, $buttonPath)
$buttonFont = New-Object System.Drawing.Font('Segoe UI Semibold', 28, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
Draw-CenteredText $graphics $ctaText $buttonFont $navy 858 78

$footerFont = New-Object System.Drawing.Font('Segoe UI', 18, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Pixel)
$websiteFont = New-Object System.Drawing.Font('Segoe UI Semibold', 19, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
Draw-CenteredText $graphics $footerText $footerFont $navy 964 28
Draw-CenteredText $graphics $websiteText $websiteFont $blue 999 30

$bitmap.Save($imagePath, [System.Drawing.Imaging.ImageFormat]::Png)

$captionFooter = if ($topic.captionFooter) {
    [string]$topic.captionFooter
} else {
    "$($config.professional)`n$($config.credential)`n`nUbicacion: $($config.location)`nWhatsApp: $($config.whatsappDisplay)"
}
$caption = "$($topic.caption)`n`n$captionFooter`n`n$hashtags"
[System.IO.File]::WriteAllText($captionPath, $caption, [System.Text.UTF8Encoding]::new($false))

$metadata = [ordered]@{
    date = $dateKey
    slot = $Slot
    topic = $topic.key
    keywords = @($topic.keywords)
    image = $imagePath
    caption = $captionPath
    published = $false
}
$metadata | ConvertTo-Json | Set-Content -LiteralPath $metadataPath -Encoding UTF8

$buttonPath.Dispose()
$logo.Dispose()
$brandFont.Dispose()
$headlineFont.Dispose()
$bodyFont.Dispose()
$nameFont.Dispose()
$smallFont.Dispose()
$buttonFont.Dispose()
$footerFont.Dispose()
$websiteFont.Dispose()
$separatorPen.Dispose()
$softBlue.Dispose()
$softYellow.Dispose()
$yellow.Dispose()
$navy.Dispose()
$blue.Dispose()
$coral.Dispose()
$graphics.Dispose()
$bitmap.Dispose()

Write-Output "Publicación creada: $imagePath"
Write-Output "Caption creado: $captionPath"
