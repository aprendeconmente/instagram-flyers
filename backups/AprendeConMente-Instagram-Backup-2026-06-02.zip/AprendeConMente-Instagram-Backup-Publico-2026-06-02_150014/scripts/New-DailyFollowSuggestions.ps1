[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),
    [string]$OutputDirectory = ([Environment]::GetFolderPath('Desktop')),
    [switch]$Force,
    [switch]$PassThru
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$config = Get-Content -LiteralPath (Join-Path $root 'config\seguimiento-diario.json') -Raw | ConvertFrom-Json
$dateKey = $Date.ToString('yyyy-MM-dd')
$displayDate = $Date.ToString('dd/MM/yyyy')
$quantity = [int]$config.cantidadDiaria
$searches = @($config.busquedas)
$fileName = "$($config.nombreArchivo)-$dateKey.txt"
$filePath = Join-Path $OutputDirectory $fileName

if ((Test-Path -LiteralPath $filePath) -and -not $Force) {
    if ($PassThru) { Write-Output $filePath }
    else { Write-Output "Lista diaria ya existente: $filePath" }
    exit 0
}

New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$random = [System.Random]::new([int]$Date.ToString('yyyyMMdd'))
$randomSearches = @($searches)
for ($i = $randomSearches.Count - 1; $i -gt 0; $i--) {
    $position = $random.Next($i + 1)
    $temporary = $randomSearches[$i]
    $randomSearches[$i] = $randomSearches[$position]
    $randomSearches[$position] = $temporary
}

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("APRENDE CON MENTE - QUE BUSCAR EN INSTAGRAM - $displayDate")
$lines.Add('=======================================================')
$lines.Add('')
$lines.Add('Busquedas del dia para descubrir cuentas reales e ideas afines.')
$lines.Add('No hace falta seguir ninguna cuenta.')
$lines.Add('')
for ($i = 0; $i -lt $quantity; $i++) {
    $search = $randomSearches[$i]
    $number = $i + 1
    $lines.Add("$number. $($search.texto)")
}

[System.IO.File]::WriteAllLines($filePath, $lines, [System.Text.UTF8Encoding]::new($false))
if ($PassThru) {
    Write-Output $filePath
}
else {
    Write-Output "Lista diaria creada: $filePath"
}
