[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),
    [ValidateSet('1100', '1500')]
    [string]$Slot = '1500',
    [string]$OutputDirectory = ([Environment]::GetFolderPath('Desktop')),
    [switch]$Force,
    [switch]$PassThru
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$brand = Get-Content -LiteralPath (Join-Path $root 'config\brand.json') -Raw | ConvertFrom-Json
$dateKey = $Date.ToString('yyyy-MM-dd')
$displayDate = $Date.ToString('dd/MM/yyyy')
$postDirectory = Join-Path $root "output\$dateKey\$Slot"
$captionPath = Join-Path $postDirectory 'caption.txt'
$imagePath = Join-Path $postDirectory 'post.png'
$filePath = Join-Path $OutputDirectory "AprendeConMente-WhatsApp-Comunidad-$dateKey.txt"

if ((Test-Path -LiteralPath $filePath) -and -not $Force) {
    if ($PassThru) { Write-Output $filePath }
    else { Write-Output "Mensaje de WhatsApp ya existente: $filePath" }
    exit 0
}

if (-not (Test-Path -LiteralPath $captionPath)) {
    & (Join-Path $PSScriptRoot 'New-DailyPost.ps1') -Date $Date -Slot $Slot | Out-Null
}
if (-not (Test-Path -LiteralPath $captionPath)) {
    throw "No se encontro el caption diario: $captionPath"
}

$caption = (Get-Content -LiteralPath $captionPath -Raw).Trim()
$captionWithoutHashtags = (($caption -split "`r?`n") | Where-Object { $_ -notmatch '^\s*#' }) -join "`r`n"
$captionWithoutHashtags = $captionWithoutHashtags.Trim()

$message = @"
Hola familias, ¿cómo están?

Les compartimos una nueva publicación de Aprende con Mente:

$captionWithoutHashtags

También pueden seguirnos en nuestras redes para ver más recursos y novedades:

Instagram: @aprendeconmente.ar
Facebook: https://www.facebook.com/profile.php?id=61590674870698
Web: $($brand.websiteUrl)

Cada niño aprende de manera diferente. Estamos para acompañarlos.
"@.Trim()

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("APRENDE CON MENTE - MENSAJE PARA COMUNIDAD DE WHATSAPP - $displayDate")
$lines.Add('=================================================================')
$lines.Add('')
$lines.Add('Copiar y pegar este mensaje en la comunidad. Adjuntar la imagen indicada abajo si corresponde.')
$lines.Add('')
$lines.Add("Imagen sugerida:")
$lines.Add($imagePath)
$lines.Add('')
$lines.Add('Mensaje:')
$lines.Add('--------')
$lines.Add($message)

New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
[System.IO.File]::WriteAllLines($filePath, $lines, [System.Text.UTF8Encoding]::new($false))

if ($PassThru) {
    Write-Output $filePath
}
else {
    Write-Output "Mensaje de WhatsApp creado: $filePath"
}
