[CmdletBinding()]
param(
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$brand = Get-Content -LiteralPath (Join-Path $root 'config\brand.json') -Raw | ConvertFrom-Json
$outputDir = Join-Path $root 'output\facebook-cover'
$imagePath = Join-Path $outputDir 'aprendeconmente-portada-facebook.png'

if ((Test-Path -LiteralPath $imagePath) -and -not $Force) {
    Write-Output $imagePath
    exit 0
}

New-Item -ItemType Directory -Path $outputDir -Force | Out-Null

Add-Type -AssemblyName System.Drawing

function C([string]$hex) { [System.Drawing.ColorTranslator]::FromHtml($hex) }
function Font([string]$family, [float]$size, [System.Drawing.FontStyle]$style = [System.Drawing.FontStyle]::Regular) {
    New-Object System.Drawing.Font($family, $size, $style, [System.Drawing.GraphicsUnit]::Pixel)
}
function Rounded([float]$x, [float]$y, [float]$w, [float]$h, [float]$r) {
    $p = New-Object System.Drawing.Drawing2D.GraphicsPath
    $d = $r * 2
    $p.AddArc($x, $y, $d, $d, 180, 90)
    $p.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
    $p.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
    $p.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
    $p.CloseFigure()
    $p
}
function FillRounded($g, $brush, [float]$x, [float]$y, [float]$w, [float]$h, [float]$r) {
    $path = Rounded $x $y $w $h $r
    $g.FillPath($brush, $path)
    $path.Dispose()
}
function DrawText($g, [string]$value, $font, $brush, [float]$x, [float]$y, [float]$w, [float]$h, [string]$align = 'Near') {
    $format = New-Object System.Drawing.StringFormat
    $format.Alignment = if ($align -eq 'Center') { [System.Drawing.StringAlignment]::Center } else { [System.Drawing.StringAlignment]::Near }
    $format.LineAlignment = [System.Drawing.StringAlignment]::Center
    $g.DrawString($value, $font, $brush, [System.Drawing.RectangleF]::new($x, $y, $w, $h), $format)
    $format.Dispose()
}

$width = 1640
$height = 624
$bmp = New-Object System.Drawing.Bitmap $width, $height
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit

$cream = New-Object System.Drawing.SolidBrush (C '#FFFDF7')
$navy = New-Object System.Drawing.SolidBrush (C '#123374')
$blue = New-Object System.Drawing.SolidBrush (C '#19A9D7')
$coral = New-Object System.Drawing.SolidBrush (C '#FC5A59')
$yellow = New-Object System.Drawing.SolidBrush (C '#FFC52E')
$softBlue = New-Object System.Drawing.SolidBrush (C '#E7F6FB')
$white = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::White)
$dark = New-Object System.Drawing.SolidBrush (C '#263044')

$g.FillRectangle($cream, 0, 0, $width, $height)

$gradRect = [System.Drawing.Rectangle]::new(0, 0, $width, $height)
$gradient = New-Object System.Drawing.Drawing2D.LinearGradientBrush($gradRect, (C '#E7F6FB'), (C '#FFF2BF'), 0)
$g.FillRectangle($gradient, $gradRect)

FillRounded $g $white 70 58 1500 500 44
FillRounded $g $softBlue 95 83 1450 450 34

$logoPath = Join-Path $root 'assets\logo.png'
$logo = [System.Drawing.Image]::FromFile($logoPath)
$g.DrawImage($logo, 115, 135, 250, 250)

$titleFont = Font 'Segoe UI Semibold' 76 ([System.Drawing.FontStyle]::Bold)
$scriptFont = Font 'Segoe Script' 52 ([System.Drawing.FontStyle]::Regular)
$credentialFont = Font 'Segoe UI Semibold' 30 ([System.Drawing.FontStyle]::Bold)
$bodyFont = Font 'Segoe UI' 31
$smallFont = Font 'Segoe UI Semibold' 29 ([System.Drawing.FontStyle]::Bold)

DrawText $g $brand.businessName $titleFont $navy 410 112 760 92
DrawText $g $brand.professional $scriptFont $coral 415 196 760 70
DrawText $g $brand.credential.ToUpperInvariant() $credentialFont $blue 418 278 820 54

FillRounded $g $white 410 365 790 85 28
DrawText $g 'Atencion psicopedagogica personalizada para ninos, adolescentes y familias' $bodyFont $dark 445 375 720 62

FillRounded $g $navy 1220 118 295 64 28
DrawText $g 'WhatsApp' $smallFont $white 1220 122 295 50 'Center'
DrawText $g $brand.whatsappDisplay (Font 'Segoe UI Semibold' 38 ([System.Drawing.FontStyle]::Bold)) $navy 1205 185 320 58 'Center'

FillRounded $g $yellow 1220 270 295 64 28
DrawText $g 'Villa Maipu' $smallFont $navy 1220 275 295 48 'Center'
DrawText $g 'San Martin' $smallFont $navy 1220 325 295 48 'Center'

FillRounded $g $coral 1220 427 295 64 28
DrawText $g 'Web' $smallFont $white 1220 431 295 50 'Center'
DrawText $g 'aprendeconmente.ar' (Font 'Segoe UI Semibold' 27 ([System.Drawing.FontStyle]::Bold)) $navy 1175 492 390 42 'Center'

$penBlue = New-Object System.Drawing.Pen((C '#19A9D7'), 6)
$penCoral = New-Object System.Drawing.Pen((C '#FC5A59'), 6)
$g.DrawLine($penBlue, 110, 505, 580, 505)
$g.DrawLine($penCoral, 590, 505, 1060, 505)
DrawText $g 'Cada nino aprende de manera diferente. Estamos para acompanarlos.' (Font 'Segoe UI Semibold' 28 ([System.Drawing.FontStyle]::Bold)) $navy 160 510 950 50 'Center'

$bmp.Save($imagePath, [System.Drawing.Imaging.ImageFormat]::Png)

$logo.Dispose()
$gradient.Dispose()
$penBlue.Dispose()
$penCoral.Dispose()
$g.Dispose()
$bmp.Dispose()
$cream.Dispose()
$navy.Dispose()
$blue.Dispose()
$coral.Dispose()
$yellow.Dispose()
$softBlue.Dispose()
$white.Dispose()
$dark.Dispose()

Write-Output $imagePath
