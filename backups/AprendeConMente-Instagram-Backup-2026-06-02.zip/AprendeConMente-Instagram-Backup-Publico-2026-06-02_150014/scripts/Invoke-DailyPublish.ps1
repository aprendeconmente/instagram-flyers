[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),
    [ValidateSet('1100', '1500')]
    [string]$Slot = '1100'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$dateKey = $Date.ToString('yyyy-MM-dd')
$postDirectory = Join-Path $root "output\$dateKey\$Slot"
$imagePath = Join-Path $postDirectory 'post.png'
$logPath = Join-Path $root 'logs\assistant.log'

try {
    & (Join-Path $PSScriptRoot 'New-DailyPost.ps1') -Date $Date -Slot $Slot
    $publicImageUrl = & (Join-Path $PSScriptRoot 'Publish-ImageToGitHub.ps1') -ImagePath $imagePath -DateKey "$dateKey-$Slot"
    $publishResult = & (Join-Path $PSScriptRoot 'Publish-InstagramPost.ps1') -PostDirectory $postDirectory -PublicImageUrl $publicImageUrl -Confirm:$false
    $logTag = if (($publishResult -join ' ') -match 'ya estaba publicado') { 'YA-PUBLICADO' } else { 'PUBLICADO' }
    "[$(Get-Date -Format s)] $logTag $dateKey $Slot $publicImageUrl" | Add-Content -LiteralPath $logPath -Encoding UTF8
}
catch {
    "[$(Get-Date -Format s)] ERROR-PUBLICAR $dateKey $Slot $($_.Exception.Message)" | Add-Content -LiteralPath $logPath -Encoding UTF8
    throw
}

if ($Slot -eq '1100') {
    try {
        $suggestionsPath = & (Join-Path $PSScriptRoot 'New-DailyFollowSuggestions.ps1') -Date $Date -PassThru
        "[$(Get-Date -Format s)] LISTA-SEGUIMIENTO $dateKey $suggestionsPath" | Add-Content -LiteralPath $logPath -Encoding UTF8
    }
    catch {
        "[$(Get-Date -Format s)] ERROR-LISTA-SEGUIMIENTO $dateKey $($_.Exception.Message)" | Add-Content -LiteralPath $logPath -Encoding UTF8
        throw
    }

    try {
        $whatsAppMessagePath = & (Join-Path $PSScriptRoot 'New-DailyWhatsAppCommunityMessage.ps1') -Date $Date -Slot $Slot -PassThru
        "[$(Get-Date -Format s)] MENSAJE-WHATSAPP $dateKey $whatsAppMessagePath" | Add-Content -LiteralPath $logPath -Encoding UTF8
    }
    catch {
        "[$(Get-Date -Format s)] ERROR-MENSAJE-WHATSAPP $dateKey $($_.Exception.Message)" | Add-Content -LiteralPath $logPath -Encoding UTF8
        throw
    }
}

if ($Slot -eq '1500') {
    try {
        $backupPath = & (Join-Path $PSScriptRoot 'New-PortableBackup.ps1') -PublicGitHub -PassThru
        $backupUrl = & (Join-Path $PSScriptRoot 'Publish-BackupToGitHub.ps1') -BackupPath $backupPath -DateKey $dateKey
        "[$(Get-Date -Format s)] BACKUP-GITHUB $dateKey $backupUrl" | Add-Content -LiteralPath $logPath -Encoding UTF8
    }
    catch {
        "[$(Get-Date -Format s)] ERROR-BACKUP-GITHUB $dateKey $($_.Exception.Message)" | Add-Content -LiteralPath $logPath -Encoding UTF8
        throw
    }
}
