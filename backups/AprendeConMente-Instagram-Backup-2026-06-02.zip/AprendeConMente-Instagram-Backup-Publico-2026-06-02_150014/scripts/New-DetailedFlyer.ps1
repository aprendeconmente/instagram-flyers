[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),
    [ValidateSet('1100', '1500')]
    [string]$Slot = '1100',
    [Parameter(Mandatory)]
    [string]$FlyerKey,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot

$brandPath = Join-Path $root 'config\brand.json'
$campaignPath = Join-Path $root 'config\flyers-detallados.json'

if (-not (Test-Path -LiteralPath $brandPath)) {
    throw "No se encontro brand.json en $brandPath."
}
if (-not (Test-Path -LiteralPath $campaignPath)) {
    throw "No se encontro flyers-detallados.json en $campaignPath."
}

$brand = Get-Content -LiteralPath $brandPath -Raw | ConvertFrom-Json
$campaign = Get-Content -LiteralPath $campaignPath -Raw | ConvertFrom-Json
$flyer = @($campaign.flyers | Where-Object { $_.key -eq $FlyerKey })[0]

if (-not $flyer) {
    throw "No se encontro el flyer '$FlyerKey'."
}

$dateKey = $Date.ToString('yyyy-MM-dd')
$outputDir = Join-Path $root "output\$dateKey\$Slot"
$imagePath = Join-Path $outputDir 'post.png'
$captionPath = Join-Path $outputDir 'caption.txt'
$metadataPath = Join-Path $outputDir 'metadata.json'

$visualVersion = 'theme-rotativo-v3'
$visualStyles = @(
    'institucional-claro',
    'tarjetas-educativas',
    'pregunta-familias',
    'minimal-profesional',
    'portal-destacado'
)

$daySeed = [int]$Date.ToString('yyyyMMdd')
$slotSeed = if ($Slot -eq '1500') { 1 } else { 0 }
$visualStyle = $visualStyles[($daySeed + $slotSeed) % $visualStyles.Count]
$sceneVariant = ($daySeed + $slotSeed) % 3

if ((Test-Path -LiteralPath $imagePath) -and -not $Force) {
    $existingMetadata = if (Test-Path -LiteralPath $metadataPath) {
        Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json
    }
    else {
        $null
    }

    $alreadyPublished = $existingMetadata -and $existingMetadata.published
    $alreadyCurrent = $existingMetadata -and $existingMetadata.visualVersion -eq $visualVersion -and $existingMetadata.visualStyle -eq $visualStyle

    if ($alreadyPublished -or $alreadyCurrent) {
        Write-Output "La publicacion del $dateKey ($Slot) ya existe: $imagePath"
        exit 0
    }

    $Force = $true
}

New-Item -ItemType Directory -Path $outputDir -Force | Out-Null

Add-Type -AssemblyName System.Drawing

function C([string]$hex) {
    [System.Drawing.ColorTranslator]::FromHtml($hex)
}

function Font(
    [string]$family,
    [float]$size,
    [System.Drawing.FontStyle]$style = [System.Drawing.FontStyle]::Regular
) {
    New-Object System.Drawing.Font($family, $size, $style, [System.Drawing.GraphicsUnit]::Pixel)
}

function Rounded([float]$x, [float]$y, [float]$w, [float]$h, [float]$r) {
    $p = New-Object System.Drawing.Drawing2D.GraphicsPath
    $d = $r * 2

    $p.AddArc($x, $y, $d, $d, 180, 90)
    $p.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
    $p.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
    $p.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
    $p.CloseFigure()

    return $p
}

function Text(
    $g,
    [string]$value,
    $font,
    $brush,
    [float]$x,
    [float]$y,
    [float]$w,
    [float]$h,
    [string]$align = 'Center'
) {
    $f = New-Object System.Drawing.StringFormat
    $f.Alignment = if ($align -eq 'Left') { [System.Drawing.StringAlignment]::Near } else { [System.Drawing.StringAlignment]::Center }
    $f.LineAlignment = [System.Drawing.StringAlignment]::Center
    $g.DrawString($value, $font, $brush, [System.Drawing.RectangleF]::new($x, $y, $w, $h), $f)
    $f.Dispose()
}

function Panel($g, $brush, [float]$x, [float]$y, [float]$w, [float]$h, [float]$r = 22) {
    if ($r -le 0) {
        $g.FillRectangle($brush, $x, $y, $w, $h)
        return
    }

    $p = Rounded $x $y $w $h $r
    $g.FillPath($brush, $p)
    $p.Dispose()
}

function SceneText($g, [string]$value, $font, $brush, [float]$x, [float]$y, [float]$w, [float]$h) {
    $format = New-Object System.Drawing.StringFormat
    $format.Alignment = [System.Drawing.StringAlignment]::Center
    $format.LineAlignment = [System.Drawing.StringAlignment]::Center
    $g.DrawString($value, $font, $brush, [System.Drawing.RectangleF]::new($x, $y, $w, $h), $format)
    $format.Dispose()
}

function DrawDecorations($g, [string]$style) {
    switch ($style) {
        'tarjetas-educativas' {
            $g.FillEllipse($softYellow, -95, 170, 260, 260)
            $g.FillEllipse($softTeal, 900, 80, 260, 260)
            $g.FillEllipse($softPink, 880, 1040, 290, 290)
        }
        'pregunta-familias' {
            $g.FillEllipse($softTeal, 850, 160, 310, 310)
            $g.FillEllipse($softYellow, -120, 1010, 300, 300)
        }
        'minimal-profesional' {
            $pen = New-Object System.Drawing.Pen((C '#E8E2F7'), 5)
            for ($i = 0; $i -lt 8; $i++) {
                $g.DrawLine($pen, 45, 220 + ($i * 115), 1035, 160 + ($i * 115))
            }
            $pen.Dispose()
        }
        'portal-destacado' {
            $g.FillRectangle($softTeal, 0, 0, 1080, 260)
            $g.FillEllipse($softYellow, 840, 55, 210, 210)
        }
        default {
            $g.FillEllipse($softPink, 860, -70, 260, 260)
            $g.FillEllipse($softTeal, -110, 960, 310, 310)
        }
    }
}

function DrawThemeScene($g, [string]$key, [int]$variant, [float]$x, [float]$y, [float]$w, [float]$h) {
    $penNavy = New-Object System.Drawing.Pen((C '#173B78'), 5)
    $penTeal = New-Object System.Drawing.Pen((C '#06AABF'), 4)
    $penPink = New-Object System.Drawing.Pen((C '#EE4E86'), 4)
    $sceneFont = Font 'Segoe UI Semibold' 17 ([System.Drawing.FontStyle]::Bold)

    if ($key -match 'alfabetizacion|lectoescritura') {
        Panel $g $softTeal $x $y $w $h 18
        $g.FillRectangle($yellow, $x + 28, $y + 26, 78, 62)
        $g.DrawRectangle($penNavy, $x + 28, $y + 26, 78, 62)
        $g.FillRectangle($white, $x + 109, $y + 26, 78, 62)
        $g.DrawRectangle($penNavy, $x + 109, $y + 26, 78, 62)
        SceneText $g 'A' (Font 'Segoe UI Semibold' 34 ([System.Drawing.FontStyle]::Bold)) $purple ($x + 28) ($y + 28) 78 58
        SceneText $g 'B' (Font 'Segoe UI Semibold' 34 ([System.Drawing.FontStyle]::Bold)) $teal ($x + 109) ($y + 28) 78 58
        $g.DrawLine($penPink, $x + 215, $y + 82, $x + 322, $y + 35)
        $g.FillEllipse($pink, $x + 305, $y + 25, 24, 24)
        SceneText $g 'leer y escribir' $sceneFont $navy ($x + 205) ($y + 86) 150 34
    }
    elseif ($key -match 'atencion|funciones|institucional') {
        Panel $g $softYellow $x $y $w $h 18
        $g.FillEllipse($teal, $x + 35, $y + 26, 86, 86)
        $g.FillEllipse($white, $x + 50, $y + 41, 56, 56)
        $g.DrawEllipse($penNavy, $x + 63, $y + 54, 30, 30)
        $g.DrawLine($penPink, $x + 78, $y + 69, $x + 78, $y + 15)

        for ($i = 0; $i -lt 4; $i++) {
            $g.FillEllipse(@($pink, $yellow, $purple, $teal)[$i], $x + 158 + ($i * 44), $y + 35 + (($i + $variant) % 2 * 28), 32, 32)
        }

        SceneText $g 'atencion + memoria' $sceneFont $navy ($x + 145) ($y + 88) 190 34
    }
    elseif ($key -match 'familias|inclusion') {
        Panel $g $softPink $x $y $w $h 18

        $centers = @(
            [pscustomobject]@{ X = $x + 75; Y = $y + 58 },
            [pscustomobject]@{ X = $x + 145; Y = $y + 50 },
            [pscustomobject]@{ X = $x + 215; Y = $y + 58 }
        )

        foreach ($c in $centers) {
            $g.FillEllipse($teal, $c.X - 18, $c.Y - 24, 36, 36)
            Panel $g $yellow ($c.X - 28) ($c.Y + 12) 56 48 18
        }

        $g.DrawBezier($penPink, $x + 258, $y + 72, $x + 272, $y + 35, $x + 318, $y + 35, $x + 330, $y + 72)
        $g.DrawBezier($penPink, $x + 258, $y + 72, $x + 270, $y + 105, $x + 318, $y + 105, $x + 330, $y + 72)
        SceneText $g 'familia y escuela' $sceneFont $navy ($x + 55) ($y + 96) 245 34
    }
    elseif ($key -match 'portal') {
        Panel $g $softTeal $x $y $w $h 18
        Panel $g $navy ($x + 45) ($y + 26) 138 84 12
        Panel $g $white ($x + 58) ($y + 39) 112 52 8
        SceneText $g 'SGT' (Font 'Segoe UI Semibold' 23 ([System.Drawing.FontStyle]::Bold)) $teal ($x + 58) ($y + 42) 112 42

        for ($i = 0; $i -lt 3; $i++) {
            $g.FillEllipse(@($yellow, $pink, $teal)[$i], $x + 220 + ($i * 42), $y + 38, 28, 28)
            $g.DrawLine($penNavy, $x + 234 + ($i * 42), $y + 72, $x + 234 + ($i * 42), $y + 105)
        }

        SceneText $g 'seguimiento claro' $sceneFont $navy ($x + 205) ($y + 92) 155 34
    }
    elseif ($key -match 'neuroplay') {
        Panel $g $softYellow $x $y $w $h 18

        $blocks = @(
            [pscustomobject]@{ X = $x + 52; Y = $y + 56; Brush = $teal },
            [pscustomobject]@{ X = $x + 110; Y = $y + 32; Brush = $pink },
            [pscustomobject]@{ X = $x + 168; Y = $y + 56; Brush = $yellow },
            [pscustomobject]@{ X = $x + 226; Y = $y + 32; Brush = $purple }
        )

        foreach ($b in $blocks) {
            Panel $g $b.Brush $b.X $b.Y 52 52 10
        }

        SceneText $g 'jugar tambien aprende' $sceneFont $navy ($x + 45) ($y + 94) 285 34
    }
    else {
        Panel $g $softTeal $x $y $w $h 18
        $g.FillEllipse($yellow, $x + 55, $y + 34, 82, 82)
        $g.DrawEllipse($penNavy, $x + 55, $y + 34, 82, 82)
        $g.DrawArc($penPink, $x + 78, $y + 58, 35, 30, 10, 160)
        $g.FillEllipse($teal, $x + 180, $y + 38, 46, 46)
        $g.FillEllipse($pink, $x + 235, $y + 58, 38, 38)
        SceneText $g 'acompanar procesos' $sceneFont $navy ($x + 145) ($y + 92) 195 34
    }

    $penNavy.Dispose()
    $penTeal.Dispose()
    $penPink.Dispose()
    $sceneFont.Dispose()
}

$navy = New-Object System.Drawing.SolidBrush (C '#173B78')
$teal = New-Object System.Drawing.SolidBrush (C '#06AABF')
$pink = New-Object System.Drawing.SolidBrush (C '#EE4E86')
$yellow = New-Object System.Drawing.SolidBrush (C '#FFC534')
$purple = New-Object System.Drawing.SolidBrush (C '#654296')
$cream = New-Object System.Drawing.SolidBrush (C '#FFFCF5')
$softPink = New-Object System.Drawing.SolidBrush (C '#FFF0F4')
$softTeal = New-Object System.Drawing.SolidBrush (C '#EAF9F7')
$softYellow = New-Object System.Drawing.SolidBrush (C '#FFF5DA')
$white = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::White)

$bmp = New-Object System.Drawing.Bitmap 1080, 1350
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$g.FillRectangle($cream, 0, 0, 1080, 1350)

DrawDecorations $g $visualStyle

$isNeuroPlay = $flyer.key -eq 'neuroplay'
$isPortal = $flyer.key -eq 'portal-sgt'

$logoPath = if ($isNeuroPlay -and (Test-Path -LiteralPath (Join-Path $root 'assets\neuro-play-logo.png'))) {
    Join-Path $root 'assets\neuro-play-logo.png'
}
else {
    Join-Path $root 'assets\logo.png'
}

if (-not (Test-Path -LiteralPath $logoPath)) {
    throw "No se encontro el logo en $logoPath."
}

$logo = [System.Drawing.Image]::FromFile($logoPath)

$brandFont = Font 'Segoe UI Semibold' 44 ([System.Drawing.FontStyle]::Bold)
$smallCaps = Font 'Segoe UI Semibold' 19 ([System.Drawing.FontStyle]::Bold)
$titleFont = Font 'Segoe UI Semibold' 49 ([System.Drawing.FontStyle]::Bold)
$titleSecondFont = Font 'Segoe UI Semibold' 45 ([System.Drawing.FontStyle]::Bold)
$statementFont = Font 'Segoe UI Semibold' 25 ([System.Drawing.FontStyle]::Bold)
$bodyFont = Font 'Segoe UI' 19
$itemFont = Font 'Segoe UI Semibold' 18 ([System.Drawing.FontStyle]::Bold)
$pillarFont = Font 'Segoe UI Semibold' 13 ([System.Drawing.FontStyle]::Bold)
$contactFont = Font 'Segoe UI Semibold' 25 ([System.Drawing.FontStyle]::Bold)
$closingFont = Font 'Segoe UI Semibold' 20 ([System.Drawing.FontStyle]::Italic)

switch ($visualStyle) {
    'tarjetas-educativas' {
        $headerY = 34
        $heroY = 178
        $pillarY = 430
        $mainY = 565
        $contactY = 993
    }
    'pregunta-familias' {
        $headerY = 42
        $heroY = 190
        $pillarY = 448
        $mainY = 575
        $contactY = 1005
    }
    'minimal-profesional' {
        $headerY = 48
        $heroY = 185
        $pillarY = 425
        $mainY = 560
        $contactY = 990
    }
    'portal-destacado' {
        $headerY = 30
        $heroY = 172
        $pillarY = 425
        $mainY = 558
        $contactY = 990
    }
    default {
        $headerY = 35
        $heroY = 172
        $pillarY = 430
        $mainY = 565
        $contactY = 993
    }
}

$g.DrawImage($logo, 45, $headerY, 120, 120)

$brandBrush = if ($isNeuroPlay) { $teal } else { $purple }
Text $g ([string]$flyer.brand) $brandFont $brandBrush 178 ($headerY + 1) 850 53 'Left'

$descriptor = if ($isNeuroPlay) {
    'JUGUETES EDUCATIVOS CON PROPOSITO'
}
elseif ($isPortal) {
    'PORTAL-SGT | SISTEMA DE GESTION TERAPEUTICA'
}
else {
    'ELISABET ESCOBAR | PSICOPEDAGOGA | +15 ANIOS'
}

Text $g $descriptor $smallCaps $pink 180 ($headerY + 59) 850 32 'Left'

$heroBrush = switch ($visualStyle) {
    'tarjetas-educativas' { $softTeal }
    'pregunta-familias' { $softYellow }
    'minimal-profesional' { $white }
    'portal-destacado' { $softPink }
    default { $softPink }
}

Panel $g $heroBrush 35 $heroY 1010 178 28
Text $g ([string]$flyer.title) $titleFont $navy 58 ($heroY + 18) 964 62

if ($flyer.titleSecond) {
    Text $g ([string]$flyer.titleSecond) $titleSecondFont $teal 58 ($heroY + 77) 964 58
    Text $g ([string]$flyer.subtitle) $smallCaps $pink 58 ($heroY + 136) 964 33
}
else {
    Text $g ([string]$flyer.subtitle) $bodyFont $navy 58 ($heroY + 88) 964 45
}

Text $g ([string]$flyer.statement).ToUpperInvariant() $statementFont $purple 35 ($heroY + 201) 1010 44

$pillarW = 190
$pillarX = 45
$circleColors = @($teal, $purple, $yellow, $pink, $teal)

for ($i = 0; $i -lt $flyer.pillars.Count; $i++) {
    $x = $pillarX + ($i * 199)

    if ($visualStyle -eq 'minimal-profesional') {
        Panel $g $white ($x + 8) ($pillarY - 8) 172 116 18
    }

    $g.FillEllipse($circleColors[$i], $x + 66, $pillarY, 56, 56)
    Text $g ([string]($i + 1)) (Font 'Segoe UI Semibold' 25 ([System.Drawing.FontStyle]::Bold)) $white ($x + 66) $pillarY 56 56
    Text $g ([string]$flyer.pillars[$i]) $pillarFont $navy $x ($pillarY + 63) $pillarW 42
}

$leftPanelBrush = switch ($visualStyle) {
    'tarjetas-educativas' { $white }
    'pregunta-familias' { $softPink }
    'minimal-profesional' { $softTeal }
    'portal-destacado' { $softTeal }
    default { $softTeal }
}

$rightPanelBrush = switch ($visualStyle) {
    'tarjetas-educativas' { $softYellow }
    'pregunta-familias' { $white }
    'minimal-profesional' { $white }
    'portal-destacado' { $softYellow }
    default { $softYellow }
}

Panel $g $leftPanelBrush 35 $mainY 496 402 26
Panel $g $rightPanelBrush 550 $mainY 495 402 26

Text $g ([string]$flyer.sectionTitle).ToUpperInvariant() $statementFont $teal 60 ($mainY + 20) 445 38 'Left'

$itemsY = $mainY + 75

for ($j = 0; $j -lt $flyer.items.Count; $j++) {
    $g.FillEllipse($pink, 65, $itemsY + 8, 18, 18)
    Text $g ([string]$flyer.items[$j]) $itemFont $navy 100 $itemsY 398 42 'Left'
    $itemsY += 56
}

$explanation = if ($isNeuroPlay) {
    "Una seleccion pensada para que el juego divierta, estimule habilidades y acompane el desarrollo infantil."
}
elseif ($isPortal) {
    "Una herramienta digital pensada para fortalecer la comunicacion, organizar informacion y acercar a las familias al proceso."
}
else {
    "Cada intervencion se realiza a traves de estrategias ludicas, pedagogicas y personalizadas, respetando el ritmo y las necesidades de cada nino."
}

Text $g $explanation $bodyFont $navy 580 ($mainY + 40) 435 128 'Left'

Panel $g $white 578 ($mainY + 191) 438 144 18
DrawThemeScene $g ([string]$flyer.key) $sceneVariant 598 ($mainY + 205) 150 110

$contactBrush = switch ($visualStyle) {
    'tarjetas-educativas' { $softTeal }
    'pregunta-familias' { $softPink }
    'minimal-profesional' { $white }
    'portal-destacado' { $softPink }
    default { $softPink }
}

Panel $g $contactBrush 35 $contactY 1010 160 25

$website = if ($flyer.websiteDisplay) {
    [string]$flyer.websiteDisplay
}
else {
    [string]$brand.websiteDisplay
}

if ($flyer.showWhatsApp) {
    Text $g 'VILLA MAIPU - SAN MARTIN' $smallCaps $purple 62 ($contactY + 21) 450 35 'Left'
    Text $g ([string]$flyer.cta).ToUpperInvariant() $smallCaps $pink 62 ($contactY + 61) 450 30 'Left'
    Text $g ([string]$brand.whatsappDisplay) $contactFont $navy 62 ($contactY + 92) 450 43 'Left'
    Text $g $website $bodyFont $teal 548 ($contactY + 67) 460 38
}
else {
    Text $g 'VILLA MAIPU - SAN MARTIN' $smallCaps $purple 62 ($contactY + 33) 950 34
    Text $g ([string]$flyer.cta).ToUpperInvariant() $smallCaps $pink 62 ($contactY + 74) 950 30
    Text $g $website $contactFont $teal 62 ($contactY + 107) 950 38
}

if ($flyer.crossPromo) {
    Panel $g $purple 35 1170 1010 70 22
    Text $g ([string]$flyer.crossPromo) $itemFont $white 56 1181 970 48
}

$footerY = if ($flyer.crossPromo) { 1260 } else { 1182 }

$footerText = if ($flyer.footer) {
    [string]$flyer.footer
}
elseif ($flyer.crossPromo) {
    'Acompanar es crear condiciones para que cada nino pueda aprender.'
}
elseif (-not $isNeuroPlay) {
    'Portal-SGT | Seguimiento claro y comunicacion segura para las familias.'
}
else {
    'Juguetes educativos con proposito'
}

Panel $g $purple 0 $footerY 1080 70 0
Text $g $footerText $bodyFont $white 28 $footerY 1024 70

$bmp.Save($imagePath, [System.Drawing.Imaging.ImageFormat]::Png)

$websiteCaption = if ($flyer.websiteUrl) {
    [string]$flyer.websiteUrl
}
else {
    [string]$brand.websiteUrl
}

$contactBlock = if ($flyer.showWhatsApp) {
    "Ubicacion: $($brand.location)`nWhatsApp: $($brand.whatsappDisplay)`nWeb: $websiteCaption"
}
else {
    "Ubicacion: Villa Maipu, San Martin`nWeb: $websiteCaption"
}

$hashtags = if ($isNeuroPlay) {
    '#NeuroPlay #JuguetesEducativos #AprenderJugando #DesarrolloInfantil'
}
else {
    $brand.hashtags
}

$caption = "$($flyer.caption)`n`n$contactBlock`n`n$hashtags"

[System.IO.File]::WriteAllText($captionPath, $caption, [System.Text.UTF8Encoding]::new($false))

[ordered]@{
    date = $dateKey
    slot = $Slot
    topic = $flyer.key
    layout = 'detallado'
    visualVersion = $visualVersion
    visualStyle = $visualStyle
    image = $imagePath
    caption = $captionPath
    published = $false
} | ConvertTo-Json | Set-Content -LiteralPath $metadataPath -Encoding UTF8

$logo.Dispose()
$bmp.Dispose()
$g.Dispose()

@(
    $navy,
    $teal,
    $pink,
    $yellow,
    $purple,
    $cream,
    $softPink,
    $softTeal,
    $softYellow,
    $white,
    $brandFont,
    $smallCaps,
    $titleFont,
    $titleSecondFont,
    $statementFont,
    $bodyFont,
    $itemFont,
    $pillarFont,
    $contactFont,
    $closingFont
) | ForEach-Object {
    if ($_ -ne $null) {
        $_.Dispose()
    }
}

Write-Output "Flyer detallado creado: $imagePath"
Write-Output "Caption creado: $captionPath"
Write-Output "Estilo visual usado: $visualStyle"