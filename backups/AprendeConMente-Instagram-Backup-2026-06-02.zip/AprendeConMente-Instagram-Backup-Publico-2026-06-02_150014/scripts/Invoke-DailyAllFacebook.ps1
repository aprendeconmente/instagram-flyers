[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),

    [switch]$Force
)

$ErrorActionPreference = 'Stop'

Write-Host ""
Write-Host "========================================="
Write-Host " PUBLICACION FACEBOOK - TODOS LOS HORARIOS"
Write-Host "========================================="
Write-Host ""

$slots = @(
    '1200',
    '1600'
)

foreach ($slot in $slots) {

    Write-Host ""
    Write-Host "-----------------------------------------"
    Write-Host " Ejecutando slot $slot"
    Write-Host "-----------------------------------------"
    Write-Host ""

    try {

        & (Join-Path $PSScriptRoot 'Invoke-DailyFacebookPublish.ps1') `
            -Date $Date `
            -Slot $slot `
            -Force:$Force

        Write-Host ""
        Write-Host "[OK] Slot $slot finalizado."
        Write-Host ""

    }
    catch {

        Write-Host ""
        Write-Host "[ERROR] Slot $slot fallo:"
        Write-Host $_.Exception.Message
        Write-Host ""

    }
}

Write-Host ""
Write-Host "========================================="
Write-Host " PROCESO FINALIZADO"
Write-Host "========================================="
Write-Host ""