[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$TokenFile,
    [Parameter(Mandatory)]
    [string]$PageId,
    [string]$PageName = 'Aprende con Mente'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$credentialPath = Join-Path $root 'config\facebook.credential.xml'

if (-not (Test-Path -LiteralPath $TokenFile)) {
    throw 'No se encontro el token temporal de Facebook.'
}

$token = (Get-Content -LiteralPath $TokenFile -Raw).Trim()
if (-not $token) {
    throw 'El token temporal de Facebook esta vacio.'
}

$protected = [pscustomobject]@{
    PageId = $PageId
    PageName = $PageName
    AccessToken = ConvertTo-SecureString -String $token -AsPlainText -Force
    ProtectedAt = (Get-Date).ToString('o')
}
$protected | Export-Clixml -LiteralPath $credentialPath
Remove-Item -LiteralPath $TokenFile -Force

Write-Output "Credencial de Facebook cifrada para la pagina '$PageName'."
