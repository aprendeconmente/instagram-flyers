[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [Parameter(Mandatory = $true)]
    [string]$PostDirectory,

    [Parameter(Mandatory = $true)]
    [string]$PublicImageUrl
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$configPath = Join-Path $root 'config\facebook.json'
$captionPath = Join-Path $PostDirectory 'caption.txt'
$metadataPath = Join-Path $PostDirectory 'metadata.json'

function Convert-SecureStringToPlainText {
    param(
        [Parameter(Mandatory = $true)]
        [System.Security.SecureString]$SecureString
    )

    $ptr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString)

    try {
        return [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    }
    finally {
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
    }
}

if (-not (Test-Path -LiteralPath $configPath)) {
    throw "No se encontro facebook.json en $configPath"
}

if (-not (Test-Path -LiteralPath $captionPath)) {
    throw "No se encontro caption.txt en $captionPath"
}

if (-not (Test-Path -LiteralPath $metadataPath)) {
    throw "No se encontro metadata.json en $metadataPath"
}

$config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
$metadata = Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json
$caption = Get-Content -LiteralPath $captionPath -Raw

$pageId = $config.graphPageId

if ([string]::IsNullOrWhiteSpace($pageId)) {
    throw "Falta graphPageId en config\facebook.json"
}

$credentialPath = Join-Path $root $config.credentialPath

if (-not (Test-Path -LiteralPath $credentialPath)) {
    throw "No se encontro la credencial de Facebook en $credentialPath"
}

$credential = Import-Clixml -LiteralPath $credentialPath

if (-not $credential.AccessToken) {
    throw "La credencial no tiene AccessToken"
}

$accessToken = Convert-SecureStringToPlainText -SecureString $credential.AccessToken

if ([string]::IsNullOrWhiteSpace($accessToken)) {
    throw "No se pudo leer el token desde facebook.credential.xml"
}

if ($metadata.facebookPublished -eq $true -or $metadata.publishedFacebook -eq $true) {
    Write-Output "Facebook: la publicacion ya estaba publicada."
    exit 0
}

$url = "https://graph.facebook.com/v19.0/$pageId/photos"

$body = @{
    url = $PublicImageUrl
    caption = $caption
    access_token = $accessToken
    published = 'true'
}

try {
    $response = Invoke-RestMethod `
        -Method Post `
        -Uri $url `
        -Body $body

    $metadata | Add-Member -NotePropertyName facebookPublished -NotePropertyValue $true -Force
    $metadata | Add-Member -NotePropertyName facebookPublishedAt -NotePropertyValue (Get-Date).ToString('s') -Force
    $metadata | Add-Member -NotePropertyName facebookPostId -NotePropertyValue $response.post_id -Force
    $metadata | Add-Member -NotePropertyName facebookPhotoId -NotePropertyValue $response.id -Force
    $metadata | Add-Member -NotePropertyName facebookImageUrl -NotePropertyValue $PublicImageUrl -Force

    $metadata |
        ConvertTo-Json -Depth 10 |
        Set-Content -LiteralPath $metadataPath -Encoding UTF8

    Write-Output "Facebook publicado correctamente."
    Write-Output "PhotoId: $($response.id)"

    if ($response.post_id) {
        Write-Output "PostId: $($response.post_id)"
    }
}
catch {
    throw $_.Exception.Message
}