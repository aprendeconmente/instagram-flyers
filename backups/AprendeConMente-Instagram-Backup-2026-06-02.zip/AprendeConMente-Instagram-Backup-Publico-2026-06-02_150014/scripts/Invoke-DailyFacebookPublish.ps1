[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),

    [ValidateSet('1200', '1600')]
    [string]$Slot = '1200',

    [switch]$Force
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$dateKey = $Date.ToString('yyyy-MM-dd')

$instagramSlot = if ($Slot -eq '1200') { '1100' } else { '1500' }

$postDirectory = Join-Path $root "output\$dateKey\$instagramSlot"
$imagePath = Join-Path $postDirectory 'post.png'

$logDir = Join-Path $root 'logs'
$logPath = Join-Path $logDir 'assistant.log'

New-Item -ItemType Directory -Path $logDir -Force | Out-Null

function Write-PublishLog {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tag,

        [Parameter(Mandatory = $true)]
        [string]$Message
    )

    $line = "[$(Get-Date -Format s)] $Tag $Message"
    $line | Add-Content -LiteralPath $logPath -Encoding UTF8
    Write-Host $line
}

try {
    $forceText = if ($Force) { ' Force=SI' } else { ' Force=NO' }

    Write-PublishLog `
        -Tag 'FACEBOOK-INICIO' `
        -Message "$dateKey slot-$Slot desde-IG-$instagramSlot$forceText"

    Write-PublishLog `
        -Tag 'FACEBOOK-GENERANDO-POST' `
        -Message "Ejecutando New-DailyPost.ps1"

    & (Join-Path $PSScriptRoot 'New-DailyPost.ps1') `
        -Date $Date `
        -Slot $instagramSlot `
        -Force:$Force

    if (-not (Test-Path -LiteralPath $imagePath)) {
        throw "No se encontro la imagen generada: $imagePath"
    }

    Write-PublishLog `
        -Tag 'FACEBOOK-IMAGEN-OK' `
        -Message $imagePath

    Write-PublishLog `
        -Tag 'FACEBOOK-SUBIENDO-GITHUB' `
        -Message "Ejecutando Publish-ImageToGitHub.ps1"

    $githubOutput = & (Join-Path $PSScriptRoot 'Publish-ImageToGitHub.ps1') `
        -ImagePath $imagePath `
        -DateKey $dateKey `
        -Slot $instagramSlot

    $publicImageUrl = @($githubOutput | Where-Object { $_ -match '^https://' })[-1]

    if ([string]::IsNullOrWhiteSpace($publicImageUrl)) {
        throw 'No se pudo obtener la URL publica HTTPS desde GitHub.'
    }

    Write-PublishLog `
        -Tag 'FACEBOOK-GITHUB-OK' `
        -Message $publicImageUrl

    Write-PublishLog `
        -Tag 'FACEBOOK-PUBLICANDO' `
        -Message "Ejecutando Publish-FacebookPost.ps1"

    $publishResult = & (Join-Path $PSScriptRoot 'Publish-FacebookPost.ps1') `
        -PostDirectory $postDirectory `
        -PublicImageUrl $publicImageUrl `
        -Confirm:$false

    $publishText = ($publishResult -join ' ')

    $logTag = if ($publishText -match 'ya estaba publicado') {
        'FACEBOOK-YA-PUBLICADO'
    }
    else {
        'FACEBOOK-PUBLICADO'
    }

    Write-PublishLog `
        -Tag $logTag `
        -Message "$dateKey slot-$Slot desde-IG-$instagramSlot $publicImageUrl"

    Write-PublishLog `
        -Tag 'FACEBOOK-FIN' `
        -Message "Proceso finalizado correctamente"
}
catch {
    Write-PublishLog `
        -Tag 'ERROR-FACEBOOK' `
        -Message "$dateKey slot-$Slot $($_.Exception.Message)"

    throw
}