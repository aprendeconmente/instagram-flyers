[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date)
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$dateKey = $Date.ToString('yyyy-MM-dd')

$slots = @(
    [pscustomobject]@{
        FacebookSlot = '1200'
        InstagramSlot = '1100'
    },
    [pscustomobject]@{
        FacebookSlot = '1600'
        InstagramSlot = '1500'
    }
)

Write-Host ""
Write-Host "========================================="
Write-Host " ESTADO DE PUBLICACIONES"
Write-Host "========================================="
Write-Host ""
Write-Host "Fecha: $dateKey"
Write-Host ""

foreach ($slot in $slots) {
    $postDirectory = Join-Path $root "output\$dateKey\$($slot.InstagramSlot)"
    $imagePath = Join-Path $postDirectory 'post.png'
    $captionPath = Join-Path $postDirectory 'caption.txt'
    $metadataPath = Join-Path $postDirectory 'metadata.json'

    Write-Host "-----------------------------------------"
    Write-Host "Facebook: $($slot.FacebookSlot) | Instagram fuente: $($slot.InstagramSlot)"
    Write-Host "-----------------------------------------"

    if (-not (Test-Path -LiteralPath $postDirectory)) {
        Write-Host "[PENDIENTE] No existe carpeta de salida"
        Write-Host ""
        continue
    }

    if (Test-Path -LiteralPath $imagePath) {
        Write-Host "[OK] Imagen generada"
    }
    else {
        Write-Host "[ERROR] Falta post.png"
    }

    if (Test-Path -LiteralPath $captionPath) {
        Write-Host "[OK] Caption generado"
    }
    else {
        Write-Host "[ERROR] Falta caption.txt"
    }

    if (Test-Path -LiteralPath $metadataPath) {
        Write-Host "[OK] Metadata encontrada"

        try {
            $metadata = Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json

            $instagramStatus = if ($metadata.published -eq $true) { 'Publicado' } else { 'No publicado' }
            $facebookStatus = if ($metadata.facebookPublished -eq $true) { 'Publicado' } else { 'No publicado' }

            Write-Host "Instagram.......: $instagramStatus"
            Write-Host "Facebook........: $facebookStatus"

            if ($metadata.instagramMediaId) {
                Write-Host "InstagramMediaId: $($metadata.instagramMediaId)"
            }

            if ($metadata.facebookPostId) {
                Write-Host "FacebookPostId..: $($metadata.facebookPostId)"
            }

            if ($metadata.facebookPhotoId) {
                Write-Host "FacebookPhotoId.: $($metadata.facebookPhotoId)"
            }

            if ($metadata.facebookImageUrl) {
                Write-Host "GitHub URL......: $($metadata.facebookImageUrl)"
            }

            if ($metadata.topic) {
                Write-Host "Tema............: $($metadata.topic)"
            }

            if ($metadata.visualStyle) {
                Write-Host "Estilo visual...: $($metadata.visualStyle)"
            }
        }
        catch {
            Write-Host "[ERROR] metadata.json invalido"
        }
    }
    else {
        Write-Host "[ERROR] Falta metadata.json"
    }

    Write-Host ""
}

Write-Host "========================================="
Write-Host " FIN ESTADO"
Write-Host "========================================="
Write-Host ""