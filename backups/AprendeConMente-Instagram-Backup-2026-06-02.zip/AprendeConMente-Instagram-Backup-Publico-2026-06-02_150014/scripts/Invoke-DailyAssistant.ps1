[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),
    [ValidateSet('1100', '1500')]
    [string]$Slot = '1100',
    [string]$PublicImageUrl,
    [switch]$Publish
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$dateKey = $Date.ToString('yyyy-MM-dd')
$postDirectory = Join-Path $root "output\$dateKey\$Slot"
$logPath = Join-Path $root 'logs\assistant.log'

try {
    & (Join-Path $PSScriptRoot 'New-DailyPost.ps1') -Date $Date -Slot $Slot

    if ($Publish) {
        if (-not $PublicImageUrl) {
            throw 'Para publicar falta la URL HTTPS pública de la imagen generada.'
        }
        & (Join-Path $PSScriptRoot 'Publish-InstagramPost.ps1') -PostDirectory $postDirectory -PublicImageUrl $PublicImageUrl -Confirm:$false
    }

    "[$(Get-Date -Format s)] OK $dateKey slot=$Slot publish=$Publish" | Add-Content -LiteralPath $logPath -Encoding UTF8
}
catch {
    "[$(Get-Date -Format s)] ERROR $dateKey slot=$Slot $($_.Exception.Message)" | Add-Content -LiteralPath $logPath -Encoding UTF8
    throw
}
