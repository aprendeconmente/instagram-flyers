# Backup y restauracion - Aprende con Mente

Este respaldo contiene los flyers, logos, textos y scripts. El backup privado
creado manualmente tambien incluye una copia de las tareas programadas de Windows.
El backup automatico que se guarda en GitHub incluye los comandos para recrearlas,
pero no exporta los XML porque el repositorio es publico.

## Importante sobre las credenciales

Los archivos `instagram.credential.xml` y `github.credential.xml` no se incluyen.
Estan cifrados para el usuario de Windows de esta computadora y no funcionarian en
otra PC. Despues de restaurar, se deben volver a autorizar Instagram y GitHub.

## Crear un respaldo nuevo

Abrir PowerShell en la carpeta del proyecto y ejecutar:

```powershell
.\scripts\New-PortableBackup.ps1
```

El archivo comprimido queda en `backups\`. Para protegerse si la computadora deja
de funcionar, ese `.zip` debe guardarse tambien en un pendrive o almacenamiento en
la nube.

Despues de la publicacion automatica de las `15:00`, el asistente crea ademas un
backup seguro y lo sube al repositorio publico de GitHub en la carpeta `backups/`.
Ese paquete nunca incluye credenciales ni XML de las tareas de Windows.

## Restaurar en otra computadora

1. Descomprimir el `.zip` en una carpeta local.
2. Volver a generar y proteger la credencial de Instagram:

```powershell
.\scripts\Protect-InstagramCredential.ps1 -TokenFile '.\config\.instagram-token.tmp' -UserId 'ID_DE_INSTAGRAM'
```

3. Volver a generar y proteger la credencial de GitHub:

```powershell
.\scripts\Protect-GitHubCredential.ps1 -TokenFile '.\config\.github-token.tmp'
```

4. Registrar nuevamente las tareas usando las rutas de la nueva computadora:

```powershell
.\scripts\Register-DailyGenerationTask.ps1 -Slot '1100' -At '11:00'
.\scripts\Register-DailyGenerationTask.ps1 -Slot '1500' -At '15:00'
```

5. Generar un flyer de prueba antes de dejar activada la publicacion:

```powershell
.\scripts\New-DailyPost.ps1 -Slot '1100' -Force
```

En el backup privado, los XML en `tareas-windows\` sirven como copia documental de
la configuracion actual. Para restaurar cualquier backup, conviene utilizar el
script de registro porque adapta la ruta a la nueva carpeta.
