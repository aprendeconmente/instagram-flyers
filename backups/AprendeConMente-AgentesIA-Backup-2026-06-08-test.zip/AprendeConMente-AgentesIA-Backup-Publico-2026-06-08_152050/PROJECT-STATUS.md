# Estado del Proyecto - Agentes IA

## Ruta raiz

C:\Users\dcavalcante\Documents\Agentes IA

## Objetivo

1 clic:
- Generar contenido
- Generar caption
- Seleccionar imagen base desde biblioteca visual
- Generar flyer profesional
- Publicar en Instagram
- Publicar en Facebook

## Flujo oficial actual

Contenido
- modules\Get-NextContentV2.ps1

Caption
- modules\New-Caption.ps1

Prompt visual de referencia
- modules\Get-ImagePrompt.ps1

Flyer
- modules\New-FlyerV2.ps1

Publicacion
- Pendiente integrar Instagram
- Pendiente integrar Facebook

## Modulos oficiales actuales

- modules\Get-NextContentV2.ps1
- modules\New-Caption.ps1
- modules\Get-ImagePrompt.ps1
- modules\New-FlyerV2.ps1

## Modulos obsoletos

- modules\Get-NextContent.ps1
- modules\Initialize-ContentBank.ps1
- modules\Initialize-ContentBankV2.ps1
- modules\Initialize-ContentBankV3.ps1
- modules\Initialize-ContentBankV4.ps1
- modules\New-Flyer.ps1

Motivo:
No son la version oficial o fueron reemplazados.

## Configuracion valida

- config\brand.json
- config\meta.json
- config\content-generators.json
- config\image-prompts.json
- config\caption-templates.json
- config\history.json
- config\neuroplay-products.json

## Configuracion obsoleta

- config\content-bank.json
- config\content-categories.json

Motivo:
Ya no usamos banco estatico de publicaciones.
El sistema oficial usa contenido dinamico mediante:
- config\content-generators.json
- modules\Get-NextContentV2.ps1

## Decisiones cerradas

- 60% Aprende con Mente
- 25% Neuro Play
- 15% Portal SGT
- Publico: padres
- Estilo visual: ilustracion semi-realista editorial
- No usar diagnosticos especificos
- Usar lenguaje: problemas de atencion, lectura, escritura, memoria, dificultades escolares
- Codigo PowerShell siempre completo
- No usar acentos directos dentro de scripts PowerShell
- Usar Unicode dentro de scripts PowerShell
- New-Flyer.ps1 V1 queda descartado
- No usar generacion local con Stable Diffusion
- No generar imagenes desde PowerShell
- Las imagenes maestras se crean manualmente con ChatGPT
- Los scripts PowerShell reutilizan automaticamente la biblioteca visual

## Biblioteca visual validada

### Aprende con Mente

Carpeta:
assets\templates\aprendeconmente

Imagenes:
- Atencion 01
- Atencion 02
- Lectura 01
- Lectura 02
- Escritura 01
- Escritura 02
- Dificultades escolares 01
- Dificultades escolares 02
- Memoria 01
- Memoria 02
- Tecnicas de estudio 01
- Tecnicas de estudio 02

Total:
12 imagenes

### Neuro Play

Carpeta:
assets\templates\neuroplay

Imagenes:
- Atencion 01
- Atencion 02
- Juego en Familia 01
- Juego en Familia 02
- Lenguaje 01
- Lenguaje 02
- Logica 01
- Logica 02
- Memoria 01
- Memoria 02

Total:
10 imagenes

### Portal SGT

Carpeta:
assets\templates\portal-sgt

Imagenes:
- Seguimiento 01
- Seguimiento 02
- Acceso Familiar 01
- Acceso Familiar 02
- Informes 01
- Informes 02
- Comunicacion 01
- Comunicacion 02

Total:
8 imagenes

## New-FlyerV2.ps1

Estado:
Creado como modulo oficial de flyer.

Objetivo:
- Leer output\last-content.json
- Leer config\brand.json
- Seleccionar imagen base desde assets\templates
- Agregar logo principal
- Agregar logo Portal SGT cuando corresponda
- Agregar titulo
- Agregar subtitulo
- Agregar beneficios
- Agregar WhatsApp
- Generar output\flyers\last-flyer.png
- Generar output\flyers\last-flyer.json

Criterio de seleccion visual:
- Aprende con Mente: atencion, lectura, escritura, memoria, tecnicas de estudio, dificultades escolares
- Neuro Play: atencion, juego en familia, lenguaje, logica, memoria
- Portal SGT: seguimiento, acceso familiar, informes, comunicacion

## Proximo foco

Validar New-FlyerV2.ps1 con publicaciones reales generadas por:
- Get-NextContentV2.ps1
- New-Caption.ps1
- Get-ImagePrompt.ps1

Despues de validar:
- Integrar publicacion Instagram
- Integrar publicacion Facebook
- Crear flujo unico Publicar.ps1
- Reemplazar New-Flyer.ps1 por New-FlyerV2.ps1 en el flujo oficial
- Eliminar obsoletos solo cuando el flujo completo quede validado
## Fase 1 aplicada - 2026-06-08

Mejoras incorporadas:
- Rutas principales portables mediante parametro Root.
- Salida UTF-8 validada en modulos PowerShell principales.
- Archivo .gitignore para proteger credenciales, logs, backups y output.
- Historial distingue generacion mediante status generated y lastGeneratedAt.
- New-FlyerLocal.ps1 puede copiar la salida a output\yyyy-MM-dd\slot con post.png, caption.txt, caption.json y metadata.json.
- flyer_engine.py selecciona layout seguro para texto segun zonas visualmente cargadas y, si OpenCV esta disponible, deteccion de caras.
- Metadata del flyer guarda layoutSafety con detectedFaces, faceBoxes, safeLayoutScore, placementStrategy y layoutScores.

Validacion:
- PowerShell parse OK.
- JSON config OK.
- Python AST OK.
- Prueba local generada en output\2026-06-08\fase1-test.

Pendiente para Fase 2:
- Integrar publicacion Instagram/Facebook usando scripts probados de C:\Users\dcavalcante\Documents\IG.
- Migrar credenciales con cuidado y mantenerlas fuera de Git.
- Probar publicacion manual antes de mover tareas programadas.
## Fase 2 aplicada - 2026-06-08

Mejoras incorporadas:
- Se copiaron publicadores probados desde C:\Users\dcavalcante\Documents\IG:
  - scripts\Publish-InstagramPost.ps1
  - scripts\Publish-FacebookPost.ps1
  - scripts\Publish-ImageToGitHub.ps1
- Se copiaron credenciales cifradas locales:
  - config\instagram.credential.xml
  - config\facebook.credential.xml
  - config\github.credential.xml
  - config\facebook.json
- Se creo scripts\New-DailyPost.ps1 para generar post.png, caption.txt, caption.json y metadata.json usando el motor nuevo.
- Se creo scripts\Invoke-DailyPublish.ps1 para flujo Instagram manual.
- Se creo scripts\Invoke-DailyFacebookPublish.ps1 para flujo Facebook manual usando la misma imagen fuente.
- Se creo scripts\Get-PublishStatus.ps1 para revisar estado por fecha.
- Se reforzo flyer_engine.py con deteccion local de zonas de piel/persona y proteccion expandida para evitar tapar cara, ojos y cabello.

Pruebas realizadas:
- GenerateOnly Instagram 1100 OK.
- GenerateOnly Facebook 1200 OK.
- Prueba Aprende con Mente 1500 OK.
- PowerShell parse OK.
- JSON config OK.
- Python AST OK.
- Imagen 1080x1080 RGB OK.
- Sin publicacion real en Instagram/Facebook durante la prueba.

Pendiente antes de Fase 3:
- Ejecutar una publicacion manual real en Instagram desde Agentes IA.
- Ejecutar una publicacion manual real en Facebook desde Agentes IA.
- Verificar ambas publicaciones en redes.
- Recién despues mover tareas de Windows desde C:\Users\dcavalcante\Documents\IG hacia C:\Users\dcavalcante\Documents\Agentes IA.
## Fase 3 aplicada - 2026-06-08

Automatizacion migrada a Agentes IA:
- AprendeConMente-PublicacionDiaria-1100 -> scripts\Invoke-DailyPublish.ps1 -Slot 1100
- AprendeConMente-PublicacionDiaria-1500 -> scripts\Invoke-DailyPublish.ps1 -Slot 1500
- AprendeConMente-FacebookDiario-1200 -> scripts\Invoke-DailyFacebookPublish.ps1 -Slot 1200
- AprendeConMente-FacebookDiario-1600 -> scripts\Invoke-DailyFacebookPublish.ps1 -Slot 1600

Calendario:
- Lunes a viernes solamente.
- IG 11:00 y 15:00.
- Facebook 12:00 y 16:00.
- StartWhenAvailable activado para correr cuando la notebook vuelva a estar disponible si estaba apagada.

Auxiliares migrados:
- New-DailyFollowSuggestions.ps1 crea TXT diario en escritorio.
- New-DailyWhatsAppCommunityMessage.ps1 crea TXT diario para comunidad de WhatsApp en escritorio.
- New-PortableBackup.ps1 crea backup local sin credenciales.
- Publish-BackupToGitHub.ps1 sube backup publico a GitHub.

Validacion:
- TXT de busquedas creado en escritorio para 2026-06-08.
- TXT de WhatsApp creado en escritorio para 2026-06-08.
- Backup local probado OK.
- Tareas Windows apuntan a C:\Users\dcavalcante\Documents\Agentes IA y Days=62 (lunes a viernes).
- Instagram/Facebook slot 1500/1600 publicado OK desde Agentes IA.

Nota:
- El slot 1100 de 2026-06-08 figura no publicado en metadata de Agentes IA porque se uso en modo GenerateOnly durante pruebas. Desde el proximo dia habil corre automaticamente.
