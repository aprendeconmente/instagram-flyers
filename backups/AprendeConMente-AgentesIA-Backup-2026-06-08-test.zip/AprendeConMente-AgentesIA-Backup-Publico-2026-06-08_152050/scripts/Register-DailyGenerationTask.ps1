[CmdletBinding()]
param(
    [ValidateSet('1100', '1500')]
    [string]$Slot = '1100',
    [string]$At = '11:00'
)

$ErrorActionPreference = 'Stop'
$taskName = "AprendeConMente-PublicacionDiaria-$Slot"
$root = Split-Path -Parent $PSScriptRoot
$runner = Join-Path $PSScriptRoot 'Invoke-DailyPublish.ps1'
$powerShell = (Get-Command 'pwsh.exe' -ErrorAction Stop).Source
$time = [datetime]::ParseExact($At, 'HH:mm', [System.Globalization.CultureInfo]::InvariantCulture)
$action = New-ScheduledTaskAction -Execute $powerShell -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$runner`" -Slot $Slot" -WorkingDirectory $root
$trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday,Tuesday,Wednesday,Thursday,Friday -At $time
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings -Description "Agentes IA: genera y publica en Instagram ($Slot), lunes a viernes." -Force | Out-Null
Write-Output "Tarea '$taskName' registrada de lunes a viernes a las $At apuntando a $runner."