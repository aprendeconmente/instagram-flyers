param(
    [string]$Root = "",
    [switch]$AlsoUpdateLastFlyer,
    [datetime]$Date = (Get-Date),
    [string]$Slot = "",
    [switch]$CopyToDatedOutput
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)

try {
    if ([string]::IsNullOrWhiteSpace($Root)) {
        if (-not [string]::IsNullOrWhiteSpace($PSScriptRoot)) {
            $scriptDir = $PSScriptRoot
        }
        elseif ($PSCommandPath) {
            $scriptDir = Split-Path -Parent $PSCommandPath
        }
        else {
            $scriptDir = (Get-Location).Path
        }

        # scripts\New-FlyerLocal.ps1 -> project root is parent of scripts
        if ((Split-Path -Leaf $scriptDir) -ieq "scripts") {
            $Root = Split-Path -Parent $scriptDir
        }
        else {
            $Root = (Get-Location).Path
        }
    }

    $Root = (Resolve-Path $Root).Path

    $engine = Join-Path $Root "tools\flyer_engine.py"
    if (-not (Test-Path $engine)) {
        throw "No se encontro el motor Python: $engine"
    }

    $contentJson = Join-Path $Root "output\last-content.json"
    $captionJson = Join-Path $Root "output\last-caption.json"
    $promptJson  = Join-Path $Root "output\last-image-prompt.json"

    if (-not (Test-Path $contentJson)) {
        throw "Falta output\last-content.json. Ejecuta primero Get-NextContentV2.ps1"
    }
    if (-not (Test-Path $captionJson)) {
        throw "Falta output\last-caption.json. Ejecuta primero New-Caption.ps1"
    }
    if (-not (Test-Path $promptJson)) {
        throw "Falta output\last-image-prompt.json. Ejecuta primero Get-ImagePrompt.ps1"
    }

    $outDir = Join-Path $Root "output\flyers"
    if (-not (Test-Path $outDir)) {
        New-Item -ItemType Directory -Force -Path $outDir | Out-Null
    }

    $output = Join-Path $outDir "last-flyer-local.png"
    Write-Host "Motor local Python + Pillow"
    Write-Host "Raiz: $Root"
    Write-Host "Salida: $output"

    $argsList = @(
        $engine,
        "--root",
        $Root
    )

    if ($AlsoUpdateLastFlyer) {
        $argsList += "--also-update-last-flyer"
    }

    & py @argsList

    if ($LASTEXITCODE -ne 0) {
        throw "El motor Python fallo con codigo $LASTEXITCODE"
    }

    if (-not (Test-Path $output)) {
        throw "El motor termino, pero no se encontro la salida: $output"
    }

    
    if ($CopyToDatedOutput -or -not [string]::IsNullOrWhiteSpace($Slot)) {
        $safeSlot = if ([string]::IsNullOrWhiteSpace($Slot)) { "manual" } else { $Slot }
        $datedDir = Join-Path $Root ("output\{0}\{1}" -f $Date.ToString("yyyy-MM-dd"), $safeSlot)
        New-Item -ItemType Directory -Force -Path $datedDir | Out-Null
        Copy-Item -LiteralPath $output -Destination (Join-Path $datedDir "post.png") -Force
        Copy-Item -LiteralPath $captionJson -Destination (Join-Path $datedDir "caption.json") -Force
        Copy-Item -LiteralPath (Join-Path $Root "output\captions\last-caption.txt") -Destination (Join-Path $datedDir "caption.txt") -Force
        Copy-Item -LiteralPath (Join-Path $outDir "last-flyer-local.json") -Destination (Join-Path $datedDir "metadata.json") -Force
        Write-Host "Salida por fecha y horario:"
        Write-Host $datedDir
    }
    Write-Host "Flyer local generado correctamente."
    Write-Host $output
}
catch {
    Write-Error $_
    exit 1
}
