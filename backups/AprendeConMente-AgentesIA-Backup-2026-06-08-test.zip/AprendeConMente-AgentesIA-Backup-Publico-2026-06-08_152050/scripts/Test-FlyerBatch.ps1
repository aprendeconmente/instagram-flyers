param(
    [string]$RootPath = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "..")).Path,
    [int]$PerBrand = 5,
    [int]$MaxAttempts = 120
)

$ErrorActionPreference = "Stop"

function Read-JsonFile {
    param([string]$Path)

    if (-not (Test-Path $Path)) {
        throw "Archivo no encontrado: $Path"
    }

    return Get-Content $Path -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Invoke-ProjectScript {
    param(
        [string]$Path,
        [hashtable]$NamedParameters = @{}
    )

    if (-not (Test-Path $Path)) {
        throw "Script no encontrado: $Path"
    }

    if ($NamedParameters.Count -gt 0) {
        & $Path @NamedParameters
    }
    else {
        & $Path
    }

    if ($LASTEXITCODE -ne 0 -and $null -ne $LASTEXITCODE) {
        throw "El script fallo: $Path"
    }
}

function Get-BrandFolderName {
    param([string]$BrandFocus)

    switch ($BrandFocus) {
        "aprendeConMente" { return "aprendeconmente" }
        "neuroPlay" { return "neuroplay" }
        "portalSgt" { return "portal-sgt" }
        "portalSGT" { return "portal-sgt" }
        default { return ($BrandFocus -replace "[^a-zA-Z0-9\-]", "").ToLowerInvariant() }
    }
}

function Get-NextPendingBrand {
    param(
        [string[]]$OfficialBrands,
        [hashtable]$Targets,
        [int]$PerBrand
    )

    foreach ($brand in $OfficialBrands) {
        if ($Targets[$brand] -lt $PerBrand) {
            return $brand
        }
    }

    return $null
}

Set-Location $RootPath

$modulesPath = Join-Path $RootPath "modules"
$outputPath = Join-Path $RootPath "output"
$flyerPath = Join-Path $outputPath "flyers"
$testRoot = Join-Path $outputPath ("flyer-tests\" + (Get-Date -Format "yyyyMMdd-HHmmss"))

New-Item -ItemType Directory -Force -Path $testRoot | Out-Null

$officialBrands = @(
    "aprendeConMente",
    "neuroPlay",
    "portalSgt"
)

$targets = @{}
foreach ($brand in $officialBrands) {
    $targets[$brand] = 0
}

$rows = New-Object System.Collections.Generic.List[object]
$attempt = 0

Write-Host "Iniciando prueba de flyers..."
Write-Host "Modo optimizado: se fuerza la marca pendiente con -BrandOverride."
Write-Host "Carpeta de salida: $testRoot"
Write-Host ""

while ($attempt -lt $MaxAttempts) {
    $brandToGenerate = Get-NextPendingBrand -OfficialBrands $officialBrands -Targets $targets -PerBrand $PerBrand

    if ([string]::IsNullOrWhiteSpace($brandToGenerate)) {
        break
    }

    $attempt++

    Write-Host "Intento $attempt de $MaxAttempts"
    Write-Host "Marca solicitada: $brandToGenerate"

    Invoke-ProjectScript `
        -Path (Join-Path $modulesPath "Get-NextContentV2.ps1") `
        -NamedParameters @{ BrandOverride = $brandToGenerate }

    Invoke-ProjectScript (Join-Path $modulesPath "New-Caption.ps1")
    Invoke-ProjectScript (Join-Path $modulesPath "Get-ImagePrompt.ps1")
    Invoke-ProjectScript (Join-Path $modulesPath "New-FlyerV2.ps1")

    $contentFile = Join-Path $outputPath "last-content.json"
    $flyerJsonFile = Join-Path $flyerPath "last-flyer.json"
    $flyerImageFile = Join-Path $flyerPath "last-flyer.png"

    $content = Read-JsonFile $contentFile

    $brand = [string]$content.brandFocus
    if ($brand -eq "portalSGT") {
        $brand = "portalSgt"
    }

    if (-not $targets.ContainsKey($brand)) {
        Write-Host "Marca no esperada, se omite: $brand"
        continue
    }

    if ($brand -ne $brandToGenerate) {
        throw "La marca generada no coincide con la solicitada. Solicitada: $brandToGenerate. Generada: $brand."
    }

    if ($targets[$brand] -ge $PerBrand) {
        Write-Host "Marca ya completa, se omite copia: $brand"
        continue
    }

    if (-not (Test-Path $flyerImageFile)) {
        throw "No se genero flyer PNG: $flyerImageFile"
    }

    if (-not (Test-Path $flyerJsonFile)) {
        throw "No se genero flyer JSON: $flyerJsonFile"
    }

    $targets[$brand]++

    $brandFolder = Get-BrandFolderName $brand
    $brandOutput = Join-Path $testRoot $brandFolder
    New-Item -ItemType Directory -Force -Path $brandOutput | Out-Null

    $index = "{0:00}" -f $targets[$brand]
    $baseName = "$brandFolder-$index"

    Copy-Item $flyerImageFile (Join-Path $brandOutput "$baseName.png") -Force
    Copy-Item $flyerJsonFile (Join-Path $brandOutput "$baseName.flyer.json") -Force
    Copy-Item $contentFile (Join-Path $brandOutput "$baseName.content.json") -Force

    $captionJson = Join-Path $outputPath "last-caption.json"
    if (Test-Path $captionJson) {
        Copy-Item $captionJson (Join-Path $brandOutput "$baseName.caption.json") -Force
    }

    $captionTxt = Join-Path $outputPath "captions\last-caption.txt"
    if (Test-Path $captionTxt) {
        Copy-Item $captionTxt (Join-Path $brandOutput "$baseName.caption.txt") -Force
    }

    $imagePromptJson = Join-Path $outputPath "last-image-prompt.json"
    if (Test-Path $imagePromptJson) {
        Copy-Item $imagePromptJson (Join-Path $brandOutput "$baseName.image-prompt.json") -Force
    }

    $imagePromptTxt = Join-Path $outputPath "last-image-prompt.txt"
    if (Test-Path $imagePromptTxt) {
        Copy-Item $imagePromptTxt (Join-Path $brandOutput "$baseName.image-prompt.txt") -Force
    }

    $flyerMeta = Read-JsonFile $flyerJsonFile

    $rows.Add([pscustomobject]@{
        Attempt = $attempt
        RequestedBrand = $brandToGenerate
        Brand = $brand
        Number = $targets[$brand]
        Category = $content.category
        Topic = $content.topic
        Title = $flyerMeta.panel.Title
        Layout = $flyerMeta.layout
        VisualMode = $flyerMeta.visualMode
        TemplateImage = $flyerMeta.templateImage
        ImageFile = Join-Path $brandOutput "$baseName.png"
    }) | Out-Null

    Write-Host "Guardado: $brand $index"
    Write-Host ""
}

$summaryFile = Join-Path $testRoot "summary.csv"
$rows | Export-Csv -Path $summaryFile -NoTypeInformation -Encoding UTF8

Write-Host ""
Write-Host "Resultado final:"
foreach ($brand in $officialBrands) {
    Write-Host "$brand = $($targets[$brand]) / $PerBrand"
}

Write-Host ""
Write-Host "Resumen:"
Write-Host $summaryFile
Write-Host ""
Write-Host "Carpeta:"
Write-Host $testRoot

if ($rows.Count -eq 0) {
    throw "No se guardo ningun flyer de prueba."
}

$missing = @()
foreach ($brand in $officialBrands) {
    if ($targets[$brand] -lt $PerBrand) {
        $missing += "$brand ($($targets[$brand])/$PerBrand)"
    }
}

if ($missing.Count -gt 0) {
    Write-Host ""
    Write-Host "No se completo el lote. Faltan:"
    $missing | ForEach-Object { Write-Host $_ }
    Write-Host "Subi MaxAttempts si hace falta."
}
