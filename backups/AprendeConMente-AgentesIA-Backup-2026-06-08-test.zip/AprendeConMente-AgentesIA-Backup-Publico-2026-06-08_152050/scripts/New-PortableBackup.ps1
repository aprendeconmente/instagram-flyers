[CmdletBinding()]
param(
    [string]$DestinationDirectory,
    [switch]$WithoutOutput,
    [switch]$PublicGitHub,
    [switch]$PassThru
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
if (-not $DestinationDirectory) { $DestinationDirectory = Join-Path $root 'backups' }

$stamp = Get-Date -Format 'yyyy-MM-dd_HHmmss'
$packagePrefix = if ($PublicGitHub) { 'AprendeConMente-AgentesIA-Backup-Publico' } else { 'AprendeConMente-AgentesIA-Backup' }
$packageName = "$packagePrefix-$stamp"
$workingDirectory = Join-Path $DestinationDirectory $packageName
$zipPath = Join-Path $DestinationDirectory "$packageName.zip"

New-Item -ItemType Directory -Path $workingDirectory -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $workingDirectory 'tareas-windows') -Force | Out-Null

foreach ($file in @('.gitignore', 'PROJECT-RULES.md', 'PROJECT-STATUS.md', 'requirements-local.txt')) {
    $fileSource = Join-Path $root $file
    if (Test-Path -LiteralPath $fileSource) { Copy-Item -LiteralPath $fileSource -Destination (Join-Path $workingDirectory $file) -Force }
}
$directoriesToCopy = if ($PublicGitHub) { @('scripts', 'modules', 'tools') } else { @('assets', 'scripts', 'modules', 'tools') }
foreach ($directory in $directoriesToCopy) {
    $directorySource = Join-Path $root $directory
    if (Test-Path -LiteralPath $directorySource) { Copy-Item -LiteralPath $directorySource -Destination $workingDirectory -Recurse -Force }
}

if ($PublicGitHub) {
    $logosSource = Join-Path $root 'assets\logos'
    if (Test-Path -LiteralPath $logosSource) {
        $logosDestination = Join-Path $workingDirectory 'assets\logos'
        New-Item -ItemType Directory -Path (Split-Path $logosDestination -Parent) -Force | Out-Null
        Copy-Item -LiteralPath $logosSource -Destination (Split-Path $logosDestination -Parent) -Recurse -Force
    }
    $assetsNote = @(
        'Backup publico liviano:',
        '- Incluye codigo, modulos, tools, config sin credenciales y logos.',
        '- No incluye assets/templates ni output para no superar limites de GitHub.',
        '- Las imagenes publicadas quedan en el repo dentro de posts/.',
        '- Para respaldo completo local usar New-PortableBackup.ps1 sin -PublicGitHub.'
    ) -join "`r`n"
    [System.IO.File]::WriteAllText((Join-Path $workingDirectory 'ASSETS-NOTA.txt'), $assetsNote, [System.Text.UTF8Encoding]::new($false))
}

$configDirectory = Join-Path $workingDirectory 'config'
New-Item -ItemType Directory -Path $configDirectory -Force | Out-Null
Get-ChildItem -LiteralPath (Join-Path $root 'config') -File |
    Where-Object { $_.Name -notlike '*.credential.xml' -and $_.Name -notlike '*.tmp' } |
    Copy-Item -Destination $configDirectory -Force

if (-not $WithoutOutput -and (Test-Path -LiteralPath (Join-Path $root 'output'))) {
    Copy-Item -LiteralPath (Join-Path $root 'output') -Destination $workingDirectory -Recurse -Force
}

$taskText = @(
    'Tareas automaticas a recrear al restaurar:',
    '',
    ".\scripts\Register-DailyGenerationTask.ps1 -Slot '1100' -At '11:00'",
    ".\scripts\Register-DailyGenerationTask.ps1 -Slot '1500' -At '15:00'",
    ".\scripts\Register-DailyFacebookTask.ps1 -Slot '1200' -At '12:00'",
    ".\scripts\Register-DailyFacebookTask.ps1 -Slot '1600' -At '16:00'",
    '',
    'No se exportan XML de Windows en el backup publico porque contienen rutas locales.',
    'Las credenciales cifradas no se incluyen por seguridad.'
) -join "`r`n"
[System.IO.File]::WriteAllText((Join-Path $workingDirectory 'tareas-windows\RECREAR-TAREAS.txt'), $taskText, [System.Text.UTF8Encoding]::new($false))

$manifest = [ordered]@{
    createdAt = (Get-Date).ToString('o')
    visibility = if ($PublicGitHub) { 'public-github' } else { 'private-local' }
    includedOutput = (-not $WithoutOutput)
    excludedForSecurity = @('config\instagram.credential.xml', 'config\facebook.credential.xml', 'config\github.credential.xml')
    restoreGuide = 'PROJECT-STATUS.md'
    sourceProject = 'Agentes IA'
}
$manifest | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $workingDirectory 'backup-manifest.json') -Encoding UTF8

if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
Compress-Archive -LiteralPath $workingDirectory -DestinationPath $zipPath -CompressionLevel Optimal

if ($PassThru) { Write-Output $zipPath }
else {
    Write-Output "Backup creado: $zipPath"
    Write-Output 'Las credenciales no se incluyeron: deben autorizarse nuevamente al restaurar.'
}