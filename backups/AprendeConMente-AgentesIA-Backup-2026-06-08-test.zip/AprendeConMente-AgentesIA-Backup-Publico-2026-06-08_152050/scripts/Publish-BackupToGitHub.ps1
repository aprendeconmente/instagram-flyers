[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$BackupPath,
    [Parameter(Mandatory)]
    [string]$DateKey,
    [string]$Branch = 'main'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$credentialPath = Join-Path $root 'config\github.credential.xml'

if (-not (Test-Path -LiteralPath $BackupPath)) {
    throw "No se encontro el backup: $BackupPath"
}
if (-not (Test-Path -LiteralPath $credentialPath)) {
    throw 'No se encontro la credencial de GitHub. Debe autorizarse el repositorio primero.'
}

$stored = Import-Clixml -LiteralPath $credentialPath
$credential = New-Object System.Management.Automation.PSCredential('github', $stored.AccessToken)
$accessToken = $credential.GetNetworkCredential().Password
$repository = $stored.Repository
$path = "backups/AprendeConMente-AgentesIA-Backup-$DateKey.zip"
$apiUri = "https://api.github.com/repos/$repository/contents/$path"
$headers = @{
    Authorization = "Bearer $accessToken"
    Accept = 'application/vnd.github+json'
    'X-GitHub-Api-Version' = '2022-11-28'
}

$existingSha = $null
try {
    $existing = Invoke-RestMethod -Method Get -Uri "${apiUri}?ref=$Branch" -Headers $headers
    $existingSha = $existing.sha
}
catch {
    if ($_.Exception.Response.StatusCode.value__ -ne 404) {
        throw
    }
}

$body = [ordered]@{
    message = "Backup automatico Aprende con Mente Agentes IA $DateKey"
    content = [Convert]::ToBase64String([IO.File]::ReadAllBytes((Resolve-Path -LiteralPath $BackupPath)))
    branch = $Branch
}
if ($existingSha) {
    $body.sha = $existingSha
}

Invoke-RestMethod -Method Put -Uri $apiUri -Headers $headers -ContentType 'application/json' -Body ($body | ConvertTo-Json) | Out-Null
Write-Output "https://raw.githubusercontent.com/$repository/$Branch/$path"
