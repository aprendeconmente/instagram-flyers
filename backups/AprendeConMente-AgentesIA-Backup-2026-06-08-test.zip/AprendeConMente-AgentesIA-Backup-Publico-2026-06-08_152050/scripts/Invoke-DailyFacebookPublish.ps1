[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),

    [ValidateSet('1200', '1600')]
    [string]$Slot = '1200',

    [switch]$Force,

    [switch]$GenerateOnly
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)

$root = Split-Path -Parent $PSScriptRoot
$dateKey = $Date.ToString('yyyy-MM-dd')
$instagramSlot = if ($Slot -eq '1200') { '1100' } else { '1500' }
$postDirectory = Join-Path $root "output\$dateKey\$instagramSlot"
$imagePath = Join-Path $postDirectory 'post.png'
$logDir = Join-Path $root 'logs'
$logPath = Join-Path $logDir 'assistant.log'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null

function Write-LogLine {
    param([string]$Tag, [string]$Message)
    $line = "[$(Get-Date -Format s)] $Tag $Message"
    $line | Add-Content -LiteralPath $logPath -Encoding UTF8
    Write-Host $line
}

try {
    & (Join-Path $PSScriptRoot 'New-DailyPost.ps1') -Date $Date -Slot $instagramSlot -Force:$Force

    if ($GenerateOnly) {
        Write-LogLine -Tag 'FACEBOOK-GENERADO-SIN-PUBLICAR' -Message "$dateKey fb-$Slot desde-$instagramSlot $imagePath"
        return
    }

    $githubOutput = & (Join-Path $PSScriptRoot 'Publish-ImageToGitHub.ps1') -ImagePath $imagePath -DateKey $dateKey -Slot $instagramSlot
    $publicImageUrl = @($githubOutput | Where-Object { $_ -match '^https://' })[-1]

    if ([string]::IsNullOrWhiteSpace($publicImageUrl)) {
        throw 'No se pudo obtener URL publica HTTPS desde GitHub.'
    }

    $publishResult = & (Join-Path $PSScriptRoot 'Publish-FacebookPost.ps1') -PostDirectory $postDirectory -PublicImageUrl $publicImageUrl -Confirm:$false
    $publishText = ($publishResult -join ' ')
    $tag = if ($publishText -match 'ya estaba publicada|ya estaba publicado') { 'FACEBOOK-YA-PUBLICADO' } else { 'FACEBOOK-PUBLICADO' }
    Write-LogLine -Tag $tag -Message "$dateKey fb-$Slot desde-$instagramSlot $publicImageUrl"
}
catch {
    Write-LogLine -Tag 'ERROR-FACEBOOK' -Message "$dateKey fb-$Slot $($_.Exception.Message)"
    throw
}