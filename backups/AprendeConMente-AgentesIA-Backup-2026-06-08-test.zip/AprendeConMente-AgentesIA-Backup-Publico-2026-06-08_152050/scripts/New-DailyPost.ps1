[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),

    [ValidateSet('1100', '1500')]
    [string]$Slot = '1100',

    [ValidateSet('', 'aprendeConMente', 'neuroPlay', 'portalSgt')]
    [string]$BrandOverride = '',

    [switch]$Force
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)

$root = Split-Path -Parent $PSScriptRoot
$dateKey = $Date.ToString('yyyy-MM-dd')
$postDirectory = Join-Path $root "output\$dateKey\$Slot"
$imagePath = Join-Path $postDirectory 'post.png'
$captionPath = Join-Path $postDirectory 'caption.txt'
$metadataPath = Join-Path $postDirectory 'metadata.json'

if ((Test-Path -LiteralPath $imagePath) -and (Test-Path -LiteralPath $captionPath) -and (Test-Path -LiteralPath $metadataPath) -and -not $Force) {
    Write-Output "La publicacion del $dateKey ($Slot) ya existe: $imagePath"
    exit 0
}

$contentArgs = @{
    Root = $root
}

if (-not [string]::IsNullOrWhiteSpace($BrandOverride)) {
    $contentArgs.BrandOverride = $BrandOverride
}

& (Join-Path $root 'modules\Get-NextContentV2.ps1') @contentArgs
& (Join-Path $root 'modules\New-Caption.ps1') -Root $root
& (Join-Path $root 'modules\Get-ImagePrompt.ps1') -Root $root
& (Join-Path $PSScriptRoot 'New-FlyerLocal.ps1') -Root $root -AlsoUpdateLastFlyer -Date $Date -Slot $Slot -CopyToDatedOutput

if (-not (Test-Path -LiteralPath $imagePath)) {
    throw "No se genero post.png en $postDirectory"
}

if (-not (Test-Path -LiteralPath $captionPath)) {
    throw "No se genero caption.txt en $postDirectory"
}

if (-not (Test-Path -LiteralPath $metadataPath)) {
    throw "No se genero metadata.json en $postDirectory"
}

$metadata = Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json
$metadata | Add-Member -NotePropertyName date -NotePropertyValue $dateKey -Force
$metadata | Add-Member -NotePropertyName slot -NotePropertyValue $Slot -Force
$metadata | Add-Member -NotePropertyName generatedBy -NotePropertyValue 'Agentes IA Fase 2' -Force
$metadata | Add-Member -NotePropertyName published -NotePropertyValue $false -Force
$metadata | Add-Member -NotePropertyName facebookPublished -NotePropertyValue $false -Force
$metadata | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $metadataPath -Encoding UTF8

Write-Output "Post generado: $imagePath"
Write-Output "Caption generado: $captionPath"
Write-Output "Metadata: $metadataPath"