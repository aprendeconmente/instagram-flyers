[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)]
    [string]$PostDirectory,

    [Parameter(Mandatory)]
    [string]$PublicImageUrl,

    [string]$ApiBase = 'https://graph.instagram.com/v25.0',

    [int]$TimeoutSec = 60,

    [int]$MaxRetries = 3,

    [int]$ProcessingAttempts = 40,

    [int]$ProcessingDelaySeconds = 3
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$captionPath = Join-Path $PostDirectory 'caption.txt'
$metadataPath = Join-Path $PostDirectory 'metadata.json'
$credentialPath = Join-Path $root 'config\instagram.credential.xml'

if (-not (Test-Path -LiteralPath $captionPath)) {
    throw "No se encontro caption.txt en $PostDirectory."
}

if (Test-Path -LiteralPath $metadataPath) {
    $existingMetadata = Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json

    if ($existingMetadata.published -and $existingMetadata.instagramMediaId) {
        Write-Output "Instagram ya estaba publicado. Media ID: $($existingMetadata.instagramMediaId)"
        exit 0
    }
}

if ($env:INSTAGRAM_USER_ID -and $env:INSTAGRAM_ACCESS_TOKEN) {
    $instagramUserId = $env:INSTAGRAM_USER_ID
    $instagramAccessToken = $env:INSTAGRAM_ACCESS_TOKEN
}
elseif (Test-Path -LiteralPath $credentialPath) {
    $stored = Import-Clixml -LiteralPath $credentialPath
    $instagramUserId = $stored.UserId
    $credential = New-Object System.Management.Automation.PSCredential('instagram', $stored.AccessToken)
    $instagramAccessToken = $credential.GetNetworkCredential().Password
}
else {
    throw 'No se encontro la credencial de Instagram. Debe autorizarse la cuenta primero.'
}

if (-not $instagramUserId) {
    throw 'La credencial de Instagram no contiene UserId.'
}

if (-not $instagramAccessToken) {
    throw 'La credencial de Instagram no contiene AccessToken.'
}

if ($PublicImageUrl -notmatch '^https://') {
    throw 'Meta necesita una URL pública HTTPS para tomar la imagen.'
}

$caption = [System.IO.File]::ReadAllText($captionPath, [System.Text.Encoding]::UTF8)

function Get-MetaErrorMessage {
    param(
        [Parameter(Mandatory)]
        $ErrorRecord
    )

    $body = $ErrorRecord.ErrorDetails.Message

    if (-not $body -and $ErrorRecord.Exception.Response) {
        try {
            $reader = New-Object System.IO.StreamReader($ErrorRecord.Exception.Response.GetResponseStream())
            $body = $reader.ReadToEnd()
        }
        catch {
            $body = $null
        }
    }

    if ($body) {
        try {
            $parsed = $body | ConvertFrom-Json

            if ($parsed.error.message) {
                return "$($ErrorRecord.Exception.Message) Meta: $($parsed.error.message) (code $($parsed.error.code), type $($parsed.error.type))"
            }
        }
        catch {
            return "$($ErrorRecord.Exception.Message) Meta: $body"
        }
    }

    return $ErrorRecord.Exception.Message
}

function Test-RetryableMetaError {
    param(
        [Parameter(Mandatory)]
        [string]$Message
    )

    return ($Message -match '429|500|502|503|504|Internal Server Error|temporarily unavailable|timeout|timed out|try again later|rate limit')
}

function Invoke-WithRetry {
    param(
        [Parameter(Mandatory)]
        [scriptblock]$ScriptBlock,

        [int]$Retries = 3,

        [int]$InitialDelaySeconds = 5
    )

    $lastError = $null

    for ($attemptNumber = 1; $attemptNumber -le $Retries; $attemptNumber++) {
        try {
            return & $ScriptBlock
        }
        catch {
            $lastError = Get-MetaErrorMessage $_

            if (-not (Test-RetryableMetaError -Message $lastError)) {
                throw $lastError
            }

            if ($attemptNumber -ge $Retries) {
                break
            }

            $delay = $InitialDelaySeconds * $attemptNumber
            Write-Warning "Intento $attemptNumber de $Retries fallo. Reintentando en $delay segundos. Error: $lastError"
            Start-Sleep -Seconds $delay
        }
    }

    throw $lastError
}

$createBody = @{
    image_url = $PublicImageUrl
    caption = $caption
    access_token = $instagramAccessToken
}

$createUri = "$ApiBase/$instagramUserId/media"

if (-not $PSCmdlet.ShouldProcess($createUri, 'Crear y publicar el post en Instagram')) {
    return
}

$container = Invoke-WithRetry -Retries $MaxRetries -ScriptBlock {
    Invoke-RestMethod `
        -Method Post `
        -Uri $createUri `
        -Body $createBody `
        -TimeoutSec $TimeoutSec
}

if (-not $container.id) {
    throw 'Meta no devolvio un identificador de publicacion.'
}

$statusUri = "$ApiBase/$($container.id)"
$ready = $false
$lastStatus = $null

for ($attempt = 1; $attempt -le $ProcessingAttempts; $attempt++) {
    $status = Invoke-WithRetry -Retries $MaxRetries -ScriptBlock {
        Invoke-RestMethod `
            -Method Get `
            -Uri $statusUri `
            -Body @{
                fields = 'status_code'
                access_token = $instagramAccessToken
            } `
            -TimeoutSec $TimeoutSec
    }

    $lastStatus = $status.status_code

    if ($status.status_code -eq 'FINISHED') {
        $ready = $true
        break
    }

    if ($status.status_code -in @('ERROR', 'EXPIRED')) {
        throw "Meta no pudo preparar la imagen para publicar. Estado: $($status.status_code)."
    }

    Start-Sleep -Seconds $ProcessingDelaySeconds
}

if (-not $ready) {
    $totalSeconds = $ProcessingAttempts * $ProcessingDelaySeconds
    throw "La imagen no quedo lista para publicar despues de $totalSeconds segundos. Ultimo estado: $lastStatus."
}

$publishBody = @{
    creation_id = $container.id
    access_token = $instagramAccessToken
}

$publishUri = "$ApiBase/$instagramUserId/media_publish"

$published = Invoke-WithRetry -Retries $MaxRetries -ScriptBlock {
    Invoke-RestMethod `
        -Method Post `
        -Uri $publishUri `
        -Body $publishBody `
        -TimeoutSec $TimeoutSec
}

if (-not $published.id) {
    throw 'Meta no devolvio Media ID despues de publicar.'
}

if (Test-Path -LiteralPath $metadataPath) {
    $metadata = Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json
}
else {
    $metadata = [pscustomobject]@{}
}

$metadata | Add-Member -NotePropertyName published -NotePropertyValue $true -Force
$metadata | Add-Member -NotePropertyName instagramMediaId -NotePropertyValue $published.id -Force
$metadata | Add-Member -NotePropertyName publishedAt -NotePropertyValue (Get-Date).ToString('o') -Force
$metadata | Add-Member -NotePropertyName publicImageUrl -NotePropertyValue $PublicImageUrl -Force
$metadata | Add-Member -NotePropertyName instagramContainerId -NotePropertyValue $container.id -Force
$metadata | Add-Member -NotePropertyName processingAttemptsUsed -NotePropertyValue $attempt -Force

$metadata | ConvertTo-Json | Set-Content -LiteralPath $metadataPath -Encoding UTF8

Write-Output "Publicado en Instagram. Media ID: $($published.id)"