[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),
    [ValidateSet('1100', '1500')]
    [string]$Slot = '1100',
    [switch]$Force,
    [switch]$GenerateOnly
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)

$root = Split-Path -Parent $PSScriptRoot
$dateKey = $Date.ToString('yyyy-MM-dd')
$postDirectory = Join-Path $root "output\$dateKey\$Slot"
$imagePath = Join-Path $postDirectory 'post.png'
$logDir = Join-Path $root 'logs'
$logPath = Join-Path $logDir 'assistant.log'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null

function Write-LogLine {
    param([string]$Tag, [string]$Message)
    $line = "[$(Get-Date -Format s)] $Tag $Message"
    $line | Add-Content -LiteralPath $logPath -Encoding UTF8
    Write-Host $line
}

try {
    & (Join-Path $PSScriptRoot 'New-DailyPost.ps1') -Date $Date -Slot $Slot -Force:$Force

    if ($GenerateOnly) {
        Write-LogLine -Tag 'GENERADO-SIN-PUBLICAR' -Message "$dateKey $Slot $imagePath"
    }
    else {
        $githubOutput = & (Join-Path $PSScriptRoot 'Publish-ImageToGitHub.ps1') -ImagePath $imagePath -DateKey $dateKey -Slot $Slot
        $publicImageUrl = @($githubOutput | Where-Object { $_ -match '^https://' })[-1]
        if ([string]::IsNullOrWhiteSpace($publicImageUrl)) { throw 'No se pudo obtener URL publica HTTPS desde GitHub.' }

        $publishResult = & (Join-Path $PSScriptRoot 'Publish-InstagramPost.ps1') -PostDirectory $postDirectory -PublicImageUrl $publicImageUrl -Confirm:$false
        $publishText = ($publishResult -join ' ')
        $tag = if ($publishText -match 'ya estaba publicado') { 'INSTAGRAM-YA-PUBLICADO' } else { 'INSTAGRAM-PUBLICADO' }
        Write-LogLine -Tag $tag -Message "$dateKey $Slot $publicImageUrl"
    }

    if ($Slot -eq '1100') {
        $suggestionsPath = & (Join-Path $PSScriptRoot 'New-DailyFollowSuggestions.ps1') -Date $Date -PassThru
        Write-LogLine -Tag 'LISTA-SEGUIMIENTO' -Message "$dateKey $suggestionsPath"

        $whatsAppMessagePath = & (Join-Path $PSScriptRoot 'New-DailyWhatsAppCommunityMessage.ps1') -Date $Date -Slot $Slot -PassThru
        Write-LogLine -Tag 'MENSAJE-WHATSAPP' -Message "$dateKey $whatsAppMessagePath"
    }

    if ($Slot -eq '1500' -and -not $GenerateOnly) {
        try {
            $backupPath = & (Join-Path $PSScriptRoot 'New-PortableBackup.ps1') -PublicGitHub -PassThru
            $backupUrl = & (Join-Path $PSScriptRoot 'Publish-BackupToGitHub.ps1') -BackupPath $backupPath -DateKey $dateKey
            Write-LogLine -Tag 'BACKUP-GITHUB' -Message "$dateKey $backupUrl"
        }
        catch {
            Write-LogLine -Tag 'WARN-BACKUP-GITHUB' -Message "$dateKey publicacion-ok backup-fallo $($_.Exception.Message)"
        }
    }
}
catch {
    Write-LogLine -Tag 'ERROR-INSTAGRAM' -Message "$dateKey $Slot $($_.Exception.Message)"
    throw
}