[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date)
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$dateKey = $Date.ToString('yyyy-MM-dd')
$slots = @(
    [pscustomobject]@{ InstagramSlot = '1100'; FacebookSlot = '1200' },
    [pscustomobject]@{ InstagramSlot = '1500'; FacebookSlot = '1600' }
)

Write-Host ''
Write-Host '========================================='
Write-Host ' ESTADO AGENTES IA'
Write-Host '========================================='
Write-Host "Fecha: $dateKey"
Write-Host ''

foreach ($slot in $slots) {
    $postDirectory = Join-Path $root "output\$dateKey\$($slot.InstagramSlot)"
    $imagePath = Join-Path $postDirectory 'post.png'
    $captionPath = Join-Path $postDirectory 'caption.txt'
    $metadataPath = Join-Path $postDirectory 'metadata.json'

    Write-Host '-----------------------------------------'
    Write-Host "IG $($slot.InstagramSlot) | Facebook $($slot.FacebookSlot)"
    Write-Host '-----------------------------------------'

    if (-not (Test-Path -LiteralPath $postDirectory)) {
        Write-Host '[PENDIENTE] No existe carpeta de salida'
        Write-Host ''
        continue
    }

    Write-Host ($(if (Test-Path -LiteralPath $imagePath) { '[OK] Imagen generada' } else { '[ERROR] Falta post.png' }))
    Write-Host ($(if (Test-Path -LiteralPath $captionPath) { '[OK] Caption generado' } else { '[ERROR] Falta caption.txt' }))

    if (Test-Path -LiteralPath $metadataPath) {
        try {
            $metadata = Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json
            Write-Host '[OK] Metadata encontrada'
            Write-Host "Tema............: $($metadata.topic)"
            Write-Host "Layout..........: $($metadata.layout)"
            if ($metadata.layoutSafety) {
                Write-Host "Caras detectadas: $($metadata.layoutSafety.detectedFaces)"
                Write-Host "Estrategia......: $($metadata.layoutSafety.placementStrategy)"
            }
            Write-Host "Instagram.......: $(if ($metadata.published -eq $true) { 'Publicado' } else { 'No publicado' })"
            Write-Host "Facebook........: $(if ($metadata.facebookPublished -eq $true) { 'Publicado' } else { 'No publicado' })"
            if ($metadata.instagramMediaId) { Write-Host "InstagramMediaId: $($metadata.instagramMediaId)" }
            if ($metadata.facebookPostId) { Write-Host "FacebookPostId..: $($metadata.facebookPostId)" }
            if ($metadata.publicImageUrl) { Write-Host "GitHub URL IG...: $($metadata.publicImageUrl)" }
            if ($metadata.facebookImageUrl) { Write-Host "GitHub URL FB...: $($metadata.facebookImageUrl)" }
        }
        catch {
            Write-Host '[ERROR] metadata.json invalido'
        }
    }
    else {
        Write-Host '[ERROR] Falta metadata.json'
    }

    Write-Host ''
}