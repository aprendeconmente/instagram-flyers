#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Motor local de flyers para Agentes IA - V2.
CPU-friendly, sin GPU.
Corrige:
- Branding por marca.
- Footer sin datos cruzados entre marcas.
- CTA adaptable.
- Texto que no se sale.
- Logo centrado en contenedor.
- Sombra más suave.
- Elementos decorativos segun paleta de marca.
- Layout seguro: evita tapar caras y zonas visualmente cargadas.
"""

from __future__ import annotations

import argparse
import json
import math
import random
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps
except Exception as exc:
    raise SystemExit(
        "Falta Pillow. Instalalo con: py -m pip install pillow\n"
        f"Detalle: {exc}"
    )

CANVAS = 1080
FOOTER_H = 124

BRAND_DIRS = {
    "aprendeConMente": "aprendeconmente",
    "neuroPlay": "neuroplay",
    "portalSgt": "portal-sgt",
}

LOGO_FILES = {
    "aprendeConMente": ["aprendeconmente.png"],
    "neuroPlay": ["neuroplay.png", "aprendeconmente.png"],
    "portalSgt": ["portal-sgt.png", "portal-sgt.jpg"],
}

CATEGORY_NAMES = {
    "attention": ["Atención"],
    "reading": ["Lectura"],
    "writing": ["Escritura"],
    "memory": ["Memoria"],
    "literacy": ["Lectura", "Escritura"],
    "studyTechniques": ["Técnicas de estudio"],
    "parentTips": ["Juego en Familia", "Atención"],
    "schoolDifficulties": ["Dificultades escolares"],
    "memoryGames": ["Memoria"],
    "languageGames": ["Lenguaje"],
    "logicGames": ["Logica", "Lógica"],
    "familyPlay": ["Juego en Familia"],
    "tracking": ["Seguimiento"],
    "reports": ["Informes"],
    "familyAccess": ["Acceso Familiar"],
    "communication": ["Comunicacion", "Comunicación"],
}

PALETTES = {
    "aprendeConMente": {
        "primary": "#0B2D6B",
        "accent": "#20BFE8",
        "warm": "#FFC928",
        "panel": "#FFFFFF",
        "text": "#102033",
        "muted": "#516070",
        "footer": "#0B2D6B",
    },
    "neuroPlay": {
        "primary": "#FF4F87",
        "accent": "#FFC928",
        "warm": "#20BFE8",
        "panel": "#FFFFFF",
        "text": "#201428",
        "muted": "#66556C",
        "footer": "#E83E76",
    },
    "portalSgt": {
        "primary": "#0B2D6B",
        "accent": "#21A970",
        "warm": "#20BFE8",
        "panel": "#FFFFFF",
        "text": "#112235",
        "muted": "#536170",
        "footer": "#08204C",
    },
}

LAYOUTS = ["card-left", "card-right", "card-center", "card-bottom", "card-top"]


def read_json(path: Path) -> Any:
    if not path.exists():
        raise FileNotFoundError(f"No existe: {path}")
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def hex_to_rgb(hex_color: str) -> Tuple[int, int, int]:
    h = str(hex_color).strip().lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgba(hex_color: str, alpha: int) -> Tuple[int, int, int, int]:
    r, g, b = hex_to_rgb(hex_color)
    return r, g, b, alpha


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates: List[str] = []
    if bold:
        candidates += [
            "C:/Windows/Fonts/segoeuib.ttf",
            "C:/Windows/Fonts/arialbd.ttf",
            "C:/Windows/Fonts/calibrib.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        ]
    candidates += [
        "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/calibri.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for item in candidates:
        p = Path(item)
        if p.exists():
            return ImageFont.truetype(str(p), size=size)
    return ImageFont.load_default()


def text_width(draw: ImageDraw.ImageDraw, text: str, fnt: ImageFont.ImageFont) -> int:
    box = draw.textbbox((0, 0), text, font=fnt)
    return box[2] - box[0]


def text_height(draw: ImageDraw.ImageDraw, text: str, fnt: ImageFont.ImageFont) -> int:
    box = draw.textbbox((0, 0), text, font=fnt)
    return box[3] - box[1]


def clean_text(text: Any) -> str:
    return " ".join(str(text or "").replace("\n", " ").split())


def truncate_text(text: str, max_chars: int) -> str:
    text = clean_text(text)
    if len(text) <= max_chars:
        return text
    shortened = text[: max_chars - 1].rsplit(" ", 1)[0].strip()
    return (shortened or text[: max_chars - 1]).strip() + "…"


def wrap_lines(draw: ImageDraw.ImageDraw, text: str, fnt: ImageFont.ImageFont, max_width: int, max_lines: int) -> List[str]:
    words = clean_text(text).split()
    if not words:
        return []
    lines: List[str] = []
    current = ""
    for word in words:
        test = f"{current} {word}".strip()
        if text_width(draw, test, fnt) <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
                current = word
            else:
                lines.append(truncate_text(word, 18))
                current = ""
            if len(lines) >= max_lines:
                break
    if current and len(lines) < max_lines:
        lines.append(current)

    full = " ".join(words)
    shown = " ".join(lines)
    if len(lines) == max_lines and len(shown) < len(full):
        while lines[-1] and text_width(draw, lines[-1] + "…", fnt) > max_width:
            lines[-1] = lines[-1].rsplit(" ", 1)[0] if " " in lines[-1] else lines[-1][:-1]
        lines[-1] = lines[-1].rstrip(" .,-") + "…"
    return lines


def fit_font_for_box(draw: ImageDraw.ImageDraw, text: str, max_width: int, max_lines: int, start_size: int, min_size: int, bold: bool) -> Tuple[ImageFont.ImageFont, List[str]]:
    for size in range(start_size, min_size - 1, -2):
        fnt = font(size, bold=bold)
        lines = wrap_lines(draw, text, fnt, max_width, max_lines)
        if lines and all(text_width(draw, line, fnt) <= max_width for line in lines):
            return fnt, lines
    fnt = font(min_size, bold=bold)
    return fnt, wrap_lines(draw, text, fnt, max_width, max_lines)


def draw_lines(draw: ImageDraw.ImageDraw, x: int, y: int, lines: List[str], fnt: ImageFont.ImageFont, fill: Tuple[int, int, int, int], gap: int) -> int:
    for line in lines:
        draw.text((x, y), line, font=fnt, fill=fill)
        y += text_height(draw, line, fnt) + gap
    return y


def cover_image(img: Image.Image, size: Tuple[int, int]) -> Image.Image:
    return ImageOps.fit(img.convert("RGB"), size, method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))


def choose_template(root: Path, brand: str, category: str) -> Optional[Path]:
    templates_root = root / "assets" / "templates" / BRAND_DIRS.get(brand, "")
    if not templates_root.exists():
        return None
    files = [p for p in templates_root.iterdir() if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}]
    if not files:
        return None
    preferred_names = CATEGORY_NAMES.get(category, [])
    preferred: List[Path] = []
    for name in preferred_names:
        preferred.extend([p for p in files if name.lower() in p.stem.lower()])
    return random.choice(preferred or files)


def make_gradient(palette: Dict[str, str]) -> Image.Image:
    img = Image.new("RGB", (CANVAS, CANVAS), hex_to_rgb(palette["primary"]))
    px = img.load()
    c1 = hex_to_rgb(palette["primary"])
    c2 = hex_to_rgb(palette["accent"])
    c3 = hex_to_rgb(palette["warm"])
    for y in range(CANVAS):
        for x in range(CANVAS):
            t = (x * 0.55 + y * 0.45) / CANVAS
            wave = (math.sin((x + y) / 150.0) + 1) * 0.05
            a = min(1, max(0, t + wave))
            if a < 0.62:
                k = a / 0.62
                col = tuple(int(c1[i] * (1 - k) + c2[i] * k) for i in range(3))
            else:
                k = (a - 0.62) / 0.38
                col = tuple(int(c2[i] * (1 - k) + c3[i] * k) for i in range(3))
            px[x, y] = col
    return img


def enhance_background(img: Image.Image, palette: Dict[str, str]) -> Image.Image:
    bg = cover_image(img, (CANVAS, CANVAS)).convert("RGBA")
    # Blur suave, no destruye la imagen.
    blurred = bg.filter(ImageFilter.GaussianBlur(radius=1.0))
    bg = Image.blend(bg, blurred, 0.25)
    # Capa azul/marca para unificar.
    bg = Image.alpha_composite(bg, Image.new("RGBA", (CANVAS, CANVAS), rgba(palette["primary"], 38)))
    # Degradado lateral para mejorar contraste.
    grad = Image.new("L", (CANVAS, CANVAS), 0)
    gd = ImageDraw.Draw(grad)
    for x in range(CANVAS):
        alpha = int(90 * (x / CANVAS))
        gd.line((x, 0, x, CANVAS), fill=alpha)
    shade = Image.new("RGBA", (CANVAS, CANVAS), (255, 255, 255, 70))
    bg = Image.composite(shade, bg, grad)
    return bg


def rounded_rect_image(size: Tuple[int, int], radius: int, fill: Tuple[int, int, int, int]) -> Image.Image:
    panel = Image.new("RGBA", size, (0, 0, 0, 0))
    d = ImageDraw.Draw(panel)
    d.rounded_rectangle((0, 0, size[0] - 1, size[1] - 1), radius=radius, fill=fill)
    return panel


def paste_panel_with_shadow(base: Image.Image, panel: Image.Image, xy: Tuple[int, int]) -> None:
    # Sombra redondeada: usa la mascara alfa del panel y evita el bloque cuadrado.
    alpha = panel.getchannel("A")
    shadow = Image.new("RGBA", (panel.width + 56, panel.height + 56), (0, 0, 0, 0))
    shadow_color = Image.new("RGBA", panel.size, (0, 0, 0, 76))
    shadow_color.putalpha(alpha)
    shadow.alpha_composite(shadow_color, (20, 20))
    shadow = shadow.filter(ImageFilter.GaussianBlur(18))
    base.alpha_composite(shadow, (xy[0] - 14, xy[1] - 10))
    base.alpha_composite(panel, xy)


def load_logo(root: Path, brand: str, max_size: Tuple[int, int]) -> Optional[Image.Image]:
    logos_dir = root / "assets" / "logos"
    for filename in LOGO_FILES.get(brand, []):
        p = logos_dir / filename
        if p.exists():
            try:
                logo = Image.open(p).convert("RGBA")
                logo.thumbnail(max_size, Image.Resampling.LANCZOS)
                return logo
            except Exception:
                continue
    return None


def layout_box(layout: str) -> Tuple[int, int, int, int]:
    if layout == "card-left":
        return 70, 170, 620, 560
    if layout == "card-right":
        return 390, 170, 620, 560
    if layout == "card-bottom":
        return 74, 520, 932, 370
    if layout == "card-top":
        return 74, 82, 932, 370
    return 150, 220, 780, 560


def rect_area(rect: Tuple[int, int, int, int]) -> int:
    return max(0, rect[2]) * max(0, rect[3])


def intersect_area(a: Tuple[int, int, int, int], b: Tuple[int, int, int, int]) -> int:
    ax1, ay1, aw, ah = a
    bx1, by1, bw, bh = b
    ax2, ay2 = ax1 + aw, ay1 + ah
    bx2, by2 = bx1 + bw, by1 + bh
    w = max(0, min(ax2, bx2) - max(ax1, bx1))
    h = max(0, min(ay2, by2) - max(ay1, by1))
    return w * h


def detect_faces_optional(img: Image.Image) -> List[Tuple[int, int, int, int]]:
    """Usa OpenCV si esta instalado. Si no, vuelve vacio sin romper el flujo."""
    try:
        import cv2  # type: ignore
        import numpy as np  # type: ignore

        gray = cv2.cvtColor(np.array(img.convert("RGB")), cv2.COLOR_RGB2GRAY)
        cascade_path = Path(cv2.data.haarcascades) / "haarcascade_frontalface_default.xml"
        cascade = cv2.CascadeClassifier(str(cascade_path))
        if cascade.empty():
            return []
        faces = cascade.detectMultiScale(gray, scaleFactor=1.08, minNeighbors=5, minSize=(55, 55))
        return [(int(x), int(y), int(w), int(h)) for (x, y, w, h) in faces]
    except Exception:
        return []


def detect_skin_regions(img: Image.Image) -> List[Tuple[int, int, int, int]]:
    """Fallback liviano: detecta regiones probables de piel para no tapar caras/manos.

    No intenta identificar personas perfecto; solo crea zonas protegidas cuando hay
    bloques de piel suficientemente grandes en la imagen.
    """
    small_w = 160
    small_h = 160
    small = img.convert("RGB").resize((small_w, small_h), Image.Resampling.BILINEAR)
    rgb_px = small.load()
    ycbcr = small.convert("YCbCr")
    px = ycbcr.load()
    visited = [[False for _ in range(small_w)] for _ in range(small_h)]
    regions: List[Tuple[int, int, int, int]] = []

    def is_skin(x: int, y: int) -> bool:
        r, g, b = rgb_px[x, y]
        yy, cb, cr = px[x, y]
        ycbcr_skin = yy > 45 and 78 <= cb <= 128 and 132 <= cr <= 182
        rgb_skin = r > 72 and g > 42 and b > 25 and r >= g - 4 and r > b + 10 and max(r, g, b) - min(r, g, b) > 14
        return ycbcr_skin and rgb_skin

    for sy in range(small_h):
        for sx in range(small_w):
            if visited[sy][sx] or not is_skin(sx, sy):
                continue
            stack = [(sx, sy)]
            visited[sy][sx] = True
            min_x = max_x = sx
            min_y = max_y = sy
            count = 0
            while stack:
                x, y = stack.pop()
                count += 1
                min_x, max_x = min(min_x, x), max(max_x, x)
                min_y, max_y = min(min_y, y), max(max_y, y)
                for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                    if 0 <= nx < small_w and 0 <= ny < small_h and not visited[ny][nx] and is_skin(nx, ny):
                        visited[ny][nx] = True
                        stack.append((nx, ny))

            bw = max_x - min_x + 1
            bh = max_y - min_y + 1
            if count < 45 or bw < 7 or bh < 7:
                continue

            scale_x = CANVAS / small_w
            scale_y = CANVAS / small_h
            pad = 34
            x1 = max(0, int(min_x * scale_x) - pad)
            y1 = max(0, int(min_y * scale_y) - pad)
            x2 = min(CANVAS, int((max_x + 1) * scale_x) + pad)
            y2 = min(CANVAS, int((max_y + 1) * scale_y) + pad)
            regions.append((x1, y1, x2 - x1, y2 - y1))

    # Mantener solo regiones grandes y no redundantes.
    regions.sort(key=rect_area, reverse=True)
    filtered: List[Tuple[int, int, int, int]] = []
    for region in regions:
        area = rect_area(region)
        if area < 8500:
            continue
        if area > int(CANVAS * CANVAS * 0.35):
            continue
        if any(intersect_area(region, kept) / max(1, min(area, rect_area(kept))) > 0.62 for kept in filtered):
            continue
        filtered.append(region)
        if len(filtered) >= 8:
            break
    return filtered


def busy_score(img: Image.Image, box: Tuple[int, int, int, int]) -> float:
    x, y, w, h = box
    crop = img.crop((x, y, x + w, y + h)).convert("L").resize((96, 96), Image.Resampling.BILINEAR)
    edges = crop.filter(ImageFilter.FIND_EDGES)
    hist = edges.histogram()
    pixels = max(1, crop.width * crop.height)
    edge_mean = sum(i * count for i, count in enumerate(hist)) / pixels
    return edge_mean


def expand_person_protection(boxes: List[Tuple[int, int, int, int]]) -> List[Tuple[int, int, int, int]]:
    expanded: List[Tuple[int, int, int, int]] = []
    for x, y, w, h in boxes:
        if y > int(CANVAS * 0.82):
            continue
        pad_x = max(70, int(w * 0.9))
        up = max(170, int(h * 1.25))
        down = min(90, max(45, int(h * 0.22)))
        x1 = max(0, x - pad_x)
        y1 = max(0, y - up)
        x2 = min(CANVAS, x + w + pad_x)
        y2 = min(CANVAS, y + h + down)
        expanded.append((x1, y1, x2 - x1, y2 - y1))
    return expanded


def layout_safety_score(img: Image.Image, layout: str, protected_boxes: List[Tuple[int, int, int, int]]) -> float:
    box = layout_box(layout)
    score = busy_score(img, box)
    card_area = max(1, rect_area(box))

    for protected in protected_boxes:
        overlap = intersect_area(box, protected) / card_area
        px, py, pw, ph = protected
        protected_center_x = px + pw / 2
        protected_center_y = py + ph / 2
        center_inside = box[0] <= protected_center_x <= box[0] + box[2] and box[1] <= protected_center_y <= box[1] + box[3]
        score += overlap * 760.0
        if center_inside:
            score += 280.0

        # Si la region protegida sugiere cabeza/rostro en zona central-superior,
        # evitar tarjetas arriba o centradas aunque parezcan limpias por contraste.
        likely_head_zone = py < CANVAS * 0.62 and protected_center_y < CANVAS * 0.68
        if likely_head_zone and overlap > 0.08:
            if layout == "card-top":
                score += 900.0
            elif layout == "card-center":
                score += 520.0
            elif layout in ("card-left", "card-right"):
                score += 240.0

    # El footer siempre ocupa abajo; no conviene elegir tarjetas que compitan demasiado con el pie,
    # pero es preferible tapar mesa/manos antes que ojos/cara.
    if layout == "card-bottom":
        score += 4.0
    return score


def choose_safe_layout(img: Image.Image, preferred: Optional[str]) -> Tuple[str, Dict[str, Any]]:
    faces = detect_faces_optional(img)
    skin_regions = detect_skin_regions(img)
    expandedSkinRegions = expand_person_protection(skin_regions)
    protected_boxes = faces + skin_regions + expandedSkinRegions
    candidates = list(LAYOUTS)
    if preferred in candidates:
        candidates = [preferred] + [item for item in candidates if item != preferred]

    scored = [(layout_safety_score(img, item, protected_boxes), item) for item in candidates]
    scored.sort(key=lambda item: item[0])
    best_score, best_layout = scored[0]

    strategy = "preferred-layout" if preferred == best_layout else "safe-layout"
    if best_score > 82:
        strategy = "safe-card-over-busy-image"

    return best_layout, {
        "detectedFaces": len(faces),
        "faceBoxes": [{"x": x, "y": y, "w": w, "h": h} for x, y, w, h in faces],
        "skinRegions": len(skin_regions),
        "skinBoxes": [{"x": x, "y": y, "w": w, "h": h} for x, y, w, h in skin_regions],
        "expandedSkinRegions": len(expandedSkinRegions),
        "expandedSkinBoxes": [{"x": x, "y": y, "w": w, "h": h} for x, y, w, h in expandedSkinRegions],
        "safeLayoutScore": round(float(best_score), 2),
        "placementStrategy": strategy,
        "layoutScores": [{"layout": item, "score": round(float(score), 2)} for score, item in scored],
    }


def preferred_layout(image_prompt: Any) -> Optional[str]:
    if not isinstance(image_prompt, dict):
        return None
    mapping = {
        "left-card": "card-left",
        "right-card": "card-right",
        "bottom-card": "card-bottom",
        "top-card": "card-top",
        "center-card": "card-center",
    }
    return mapping.get(str(image_prompt.get("preferredLayout", "")))


def brand_footer_text(brand: str, contact: Dict[str, Any]) -> str:
    whatsapp = contact.get("whatsappDisplay", "11 2732-5400")
    location = contact.get("location", "")
    instagram = contact.get("instagram", "")

    # Portal SGT no debe heredar Instagram de Aprende con Mente.
    if brand == "aprendeConMente" and instagram:
        return f"WhatsApp {whatsapp} · {instagram}"

    if location:
        return f"WhatsApp {whatsapp} · {location}"

    return f"WhatsApp {whatsapp}"


def draw_fitted_text(draw: ImageDraw.ImageDraw, pos: Tuple[int, int], text: str, max_width: int, start_size: int, min_size: int, fill: Tuple[int, int, int, int], bold: bool = True) -> ImageFont.ImageFont:
    for size in range(start_size, min_size - 1, -1):
        fnt = font(size, bold=bold)
        if text_width(draw, text, fnt) <= max_width:
            draw.text(pos, text, font=fnt, fill=fill)
            return fnt
    fnt = font(min_size, bold=bold)
    t = clean_text(text)
    while len(t) > 4 and text_width(draw, t + "…", fnt) > max_width:
        t = t[:-1].rstrip()
    draw.text(pos, t + "…", font=fnt, fill=fill)
    return fnt


def draw_footer(base: Image.Image, root: Path, brand: str, brand_data: Dict[str, Any], palette: Dict[str, str]) -> None:
    d = ImageDraw.Draw(base)
    footer_y = CANVAS - FOOTER_H
    bar_x1, bar_y1 = 44, footer_y + 14
    bar_x2, bar_y2 = CANVAS - 44, CANVAS - 28
    d.rounded_rectangle((bar_x1, bar_y1, bar_x2, bar_y2), radius=32, fill=rgba(palette["footer"], 238))

    contact = brand_data.get("contact", {})
    text = brand_footer_text(brand, contact)

    logo_box_w = 146
    logo_box_h = 62
    logo_box_x = bar_x2 - logo_box_w - 22
    logo_box_y = bar_y1 + ((bar_y2 - bar_y1) - logo_box_h) // 2
    d.rounded_rectangle((logo_box_x, logo_box_y, logo_box_x + logo_box_w, logo_box_y + logo_box_h), radius=0, fill=(255, 255, 255, 245))

    logo = load_logo(root, brand, (logo_box_w - 22, logo_box_h - 16))
    if logo:
        lx = logo_box_x + (logo_box_w - logo.width) // 2
        ly = logo_box_y + (logo_box_h - logo.height) // 2
        base.alpha_composite(logo, (lx, ly))

    text_x = bar_x1 + 38
    text_y = bar_y1 + 26
    max_text_w = logo_box_x - text_x - 26
    draw_fitted_text(d, (text_x, text_y), text, max_text_w, 30, 22, (255, 255, 255, 255), bold=True)


def draw_brand_decor(base: Image.Image, brand: str, palette: Dict[str, str], layout: str) -> None:
    d = ImageDraw.Draw(base)

    # Elementos más sobrios para Portal SGT; más lúdicos para NeuroPlay.
    if brand == "portalSgt":
        d.rounded_rectangle((64, 56, 238, 64), radius=4, fill=rgba(palette["accent"], 175))
        d.polygon([(720, 0), (1080, 0), (1080, 1080), (900, 1080)], fill=rgba(palette["primary"], 32))
        d.ellipse((CANVAS - 150, 70, CANVAS - 82, 138), fill=rgba(palette["accent"], 120))
    elif brand == "neuroPlay":
        d.ellipse((-90, CANVAS - 240, 210, CANVAS + 60), fill=rgba(palette["warm"], 145))
        d.ellipse((CANVAS - 180, -90, CANVAS + 70, 160), fill=rgba(palette["primary"], 125))
        d.rounded_rectangle((66, 52, 250, 60), radius=4, fill=rgba(palette["accent"], 180))
    else:
        d.ellipse((-85, CANVAS - 245, 215, CANVAS + 55), fill=rgba(palette["accent"], 130))
        d.ellipse((CANVAS - 175, -80, CANVAS + 55, 150), fill=rgba(palette["warm"], 120))
        d.rounded_rectangle((66, 52, 250, 60), radius=4, fill=rgba(palette["accent"], 180))


def text_block_height(draw: ImageDraw.ImageDraw, lines: List[str], fnt: ImageFont.ImageFont, gap: int) -> int:
    if not lines:
        return 0
    return sum(text_height(draw, line, fnt) for line in lines) + gap * max(0, len(lines) - 1)


def fit_card_text(draw: ImageDraw.ImageDraw, title: str, subtitle: str, width: int, height: int, pad: int, layout: str) -> Tuple[ImageFont.ImageFont, List[str], ImageFont.ImageFont, List[str]]:
    max_title_lines = 2 if layout in ("card-top", "card-bottom") else 3
    max_subtitle_lines = 2
    title_start = 48 if width >= 760 else 44
    title_min = 30
    subtitle_start = 30 if width >= 760 else 28
    subtitle_min = 21
    available_h = height - 118 - pad - 8

    for title_size in range(title_start, title_min - 1, -2):
        title_font = font(title_size, bold=True)
        title_lines = wrap_lines(draw, title, title_font, width - pad * 2, max_title_lines)
        title_h = text_block_height(draw, title_lines, title_font, 8)
        for subtitle_size in range(subtitle_start, subtitle_min - 1, -2):
            subtitle_font = font(subtitle_size, bold=False)
            subtitle_lines = wrap_lines(draw, subtitle, subtitle_font, width - pad * 2, max_subtitle_lines)
            subtitle_h = text_block_height(draw, subtitle_lines, subtitle_font, 7)
            cta_h = 58
            total = title_h + 16 + subtitle_h + 24 + cta_h
            if total <= available_h:
                return title_font, title_lines, subtitle_font, subtitle_lines

    title_font = font(title_min, bold=True)
    subtitle_font = font(subtitle_min, bold=False)
    return (
        title_font,
        wrap_lines(draw, truncate_text(title, 54), title_font, width - pad * 2, max_title_lines),
        subtitle_font,
        wrap_lines(draw, truncate_text(subtitle, 72), subtitle_font, width - pad * 2, 1),
    )


def draw_card(base: Image.Image, root: Path, brand: str, brand_data: Dict[str, Any], palette: Dict[str, str], content: Dict[str, Any], layout: str) -> None:
    x, y, w, h = layout_box(layout)
    panel = rounded_rect_image((w, h), 38, rgba(palette["panel"], 242))
    pd = ImageDraw.Draw(panel)

    primary = rgba(palette["primary"], 255)
    accent = rgba(palette["accent"], 255)
    text_color = rgba(palette["text"], 255)
    muted = rgba(palette["muted"], 255)

    pad = 36

    brand_label = brand_data.get("brands", {}).get(brand, brand)
    small = font(24, bold=True)
    pd.rounded_rectangle((pad, 28, pad + 118, 42), radius=7, fill=accent)
    pd.text((pad, 62), brand_label.upper(), font=small, fill=primary)

    title = truncate_text(content.get("title", ""), 58)
    subtitle = truncate_text(content.get("flyerText", content.get("topic", "")), 78)
    title_font, title_lines, subtitle_font, subtitle_lines = fit_card_text(pd, title, subtitle, w, h, pad, layout)

    ty = 118
    ty = draw_lines(pd, pad, ty, title_lines, title_font, text_color, 8)
    ty += 16
    ty = draw_lines(pd, pad, ty, subtitle_lines, subtitle_font, muted, 7)

    cta_text = "Consultanos por WhatsApp"
    cta_font = font(24, bold=True)
    cta_w = min(w - pad * 2, text_width(pd, cta_text, cta_font) + 46)
    cta_h = 52
    cta_y = min(h - pad - cta_h, ty + 24)
    cta_y = max(cta_y, ty + 12)
    if cta_y + cta_h <= h - 18:
        pd.rounded_rectangle((pad, cta_y, pad + cta_w, cta_y + cta_h), radius=24, fill=rgba(palette["primary"], 245))
        pd.text((pad + 23, cta_y + 12), cta_text, font=cta_font, fill=(255, 255, 255, 255))

    paste_panel_with_shadow(base, panel, (x, y))


def generate(root: Path, also_update_last_flyer: bool = False) -> Dict[str, Any]:
    output_dir = root / "output" / "flyers"
    output_dir.mkdir(parents=True, exist_ok=True)

    content = read_json(root / "output" / "last-content.json")
    brand_data = read_json(root / "config" / "brand.json")

    image_prompt = None
    image_prompt_path = root / "output" / "last-image-prompt.json"
    if image_prompt_path.exists():
        try:
            image_prompt = read_json(image_prompt_path)
        except Exception:
            image_prompt = None

    brand = content.get("brandFocus", "aprendeConMente")
    category = content.get("category", "")
    palette = PALETTES.get(brand, PALETTES["aprendeConMente"])

    template = choose_template(root, brand, category)
    if template:
        template_img = Image.open(template)
        analysis_img = cover_image(template_img, (CANVAS, CANVAS))
        bg = enhance_background(template_img, palette)
    else:
        bg = make_gradient(palette).convert("RGBA")
        analysis_img = bg.convert("RGB")

    requested_layout = preferred_layout(image_prompt)
    layout, safety = choose_safe_layout(analysis_img, requested_layout)

    draw_brand_decor(bg, brand, palette, layout)
    draw_card(bg, root, brand, brand_data, palette, content, layout)
    draw_footer(bg, root, brand, brand_data, palette)

    output_path = output_dir / "last-flyer-local.png"
    bg.convert("RGB").save(output_path, "PNG", optimize=True)

    if also_update_last_flyer:
        bg.convert("RGB").save(output_dir / "last-flyer.png", "PNG", optimize=True)

    metadata = {
        "createdAt": datetime.now().isoformat(timespec="seconds"),
        "engine": "flyer_engine.py local-pillow-v2",
        "contentId": content.get("id"),
        "brandFocus": brand,
        "category": category,
        "topic": content.get("topic"),
        "title": content.get("title"),
        "layout": layout,
        "requestedLayout": requested_layout,
        "layoutSafety": safety,
        "templateImage": str(template) if template else None,
        "outputImage": str(output_path),
        "alsoUpdatedLastFlyer": also_update_last_flyer,
        "visualMode": image_prompt.get("visualMode") if isinstance(image_prompt, dict) else None,
    }
    write_json(output_dir / "last-flyer-local.json", metadata)
    return metadata


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, help="Raiz del proyecto Agentes IA")
    parser.add_argument("--also-update-last-flyer", action="store_true", help="Tambien escribe output/flyers/last-flyer.png")
    args = parser.parse_args()

    metadata = generate(Path(args.root), also_update_last_flyer=args.also_update_last_flyer)
    print("Flyer local generado:")
    print(metadata["outputImage"])
    print("Metadata:")
    print(str(Path(args.root) / "output" / "flyers" / "last-flyer-local.json"))


if __name__ == "__main__":
    main()
