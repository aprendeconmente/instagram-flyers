# Reglas del Proyecto Agentes IA

## Regla 1 - Código completo

Nunca modificar scripts mediante fragmentos.

Siempre entregar:

* Ruta completa del archivo.
* Código completo del archivo.
* Nunca parches parciales.

---

## Regla 2 - UTF8

Nunca utilizar:

* á
* é
* í
* ó
* ú
* ñ

directamente dentro de scripts PowerShell.

Siempre utilizar Unicode:

* \u00e1
* \u00e9
* \u00ed
* \u00f3
* \u00fa
* \u00f1

y convertir mediante la función U().

---

## Regla 3 - No eliminar versiones activas

Los archivos antiguos se mantienen únicamente hasta validar la versión nueva.

Una vez validada una versión:

* eliminar versiones obsoletas
* eliminar scripts no utilizados
* eliminar archivos de prueba

---

## Regla 4 - Un solo flujo productivo

Objetivo final:

Get-NextContentV2.ps1

↓

New-Caption.ps1

↓

New-Flyer.ps1

↓

Publish-Instagram.ps1

↓

Publish-Facebook.ps1

---

## Regla 5 - Contenido

Distribución:

* 60% Aprende con Mente
* 25% Neuro Play
* 15% Portal SGT

No utilizar diagnósticos.

Utilizar:

* problemas de atención
* problemas de lectura
* problemas de escritura
* dificultades escolares
* memoria
* organización
* aprendizaje

---

## Regla 6 - Diseño visual

Prioridad:

1. Composición gráfica profesional.
2. Elementos ilustrados.
3. Fotos reales solo ocasionalmente.

Nunca depender de una fotografía para comunicar el mensaje.

---

## Regla 7 - Publicaciones

Objetivo:

1 clic = generar y publicar.

La publicación debe generarse automáticamente sin edición manual.

---

## Regla 8 - Historial

Nunca repetir contenido reciente.

El historial debe impedir reutilizar temas recientes y permitir rotación inteligente.
