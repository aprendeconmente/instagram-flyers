param(
    [ValidateSet("aprendeConMente", "neuroPlay", "portalSgt")]
    [string]$BrandOverride,
    [string]$Root = ""
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)

function Get-ProjectRoot {
    param([string]$RequestedRoot)
    if (-not [string]::IsNullOrWhiteSpace($RequestedRoot)) {
        return (Resolve-Path -LiteralPath $RequestedRoot).Path
    }
    if (-not [string]::IsNullOrWhiteSpace($PSScriptRoot)) {
        return (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot ".." )).Path
    }
    return (Get-Location).Path
}

$Root = Get-ProjectRoot -RequestedRoot $Root

$GeneratorsPath = Join-Path $Root "config\content-generators.json"
$HistoryPath = Join-Path $Root "config\history.json"

function U([string]$Text) {
    return [regex]::Replace($Text, '\\u([0-9a-fA-F]{4})', {
        param($m)
        [char][convert]::ToInt32($m.Groups[1].Value, 16)
    })
}

function Read-JsonUtf8 {
    param([string]$Path)
    $json = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
    return $json | ConvertFrom-Json
}

function Write-JsonUtf8 {
    param([string]$Path, [object]$Data)
    $json = $Data | ConvertTo-Json -Depth 30
    [System.IO.File]::WriteAllText($Path, $json, [System.Text.UTF8Encoding]::new($false))
}

function Get-WeightedBrand {
    $n = Get-Random -Minimum 1 -Maximum 101
    if ($n -le 60) { return "aprendeConMente" }
    if ($n -le 85) { return "neuroPlay" }
    return "portalSgt"
}

function Get-SelectedBrand {
    param([string]$Override)

    if (-not [string]::IsNullOrWhiteSpace($Override)) {
        return $Override
    }

    return Get-WeightedBrand
}

function Get-RandomProperty {
    param([object]$Object)

    $names = @($Object.PSObject.Properties | ForEach-Object { $_.Name })
    $selectedName = Get-Random $names

    return [pscustomobject]@{
        Name = $selectedName
        Value = $Object.$selectedName
    }
}

function Get-RecentKeys {
    param([object]$History, [int]$Take = 30)

    if (-not $History.publications) { return @() }

    return @(
        $History.publications |
        Select-Object -Last $Take |
        ForEach-Object {
            if ($_.topicKey) { $_.topicKey }
        }
    )
}

function New-Title {
    param([string]$Brand, [string]$Topic)

    $templatesAprende = @(
        "Cuando aparecen {topic}, acompa\u00f1ar hace la diferencia",
        "{topicCapital}: una habilidad que puede trabajarse",
        "Peque\u00f1as estrategias para acompa\u00f1ar {topic}",
        "El aprendizaje mejora cuando entendemos {topic}",
        "{topicCapital} tambi\u00e9n necesita tiempo y acompa\u00f1amiento",
        "Cada ni\u00f1o puede avanzar con el apoyo adecuado"
    )

    $templatesNeuro = @(
        "{topicCapital} tambi\u00e9n puede estimularse jugando",
        "Jugar en casa para acompa\u00f1ar {topic}",
        "El juego como puente para trabajar {topic}",
        "Aprender jugando tambi\u00e9n es aprender",
        "M\u00e1s juego, m\u00e1s oportunidades de aprendizaje"
    )

    $templatesPortal = @(
        "{topicCapital} para acompa\u00f1ar mejor",
        "M\u00e1s claridad para seguir cada proceso",
        "El seguimiento tambi\u00e9n forma parte del acompa\u00f1amiento",
        "Informaci\u00f3n disponible para las familias",
        "Cada sesi\u00f3n puede estar m\u00e1s cerca de casa"
    )

    switch ($Brand) {
        "neuroPlay" { $template = Get-Random $templatesNeuro }
        "portalSgt" { $template = Get-Random $templatesPortal }
        default { $template = Get-Random $templatesAprende }
    }

    $template = U $template
    $topicCapital = (Get-Culture).TextInfo.ToTitleCase($Topic)

    return $template.Replace("{topic}", $Topic).Replace("{topicCapital}", $topicCapital)
}

function New-FlyerText {
    param([string]$Brand)

    $aprendeTexts = @(
        "En Aprende con Mente acompa\u00f1amos cada proceso con estrategias pensadas para cada ni\u00f1o.",
        "Observar c\u00f3mo aprende un ni\u00f1o ayuda a elegir mejores herramientas.",
        "La psicopedagog\u00eda permite acompa\u00f1ar el aprendizaje con una mirada profesional y cercana.",
        "Cada avance necesita tiempo, confianza y orientaci\u00f3n adecuada.",
        "Cuando familia y profesional trabajan juntos, el proceso se vuelve m\u00e1s claro."
    )

    $neuroTexts = @(
        "El juego puede continuar en casa como parte del acompa\u00f1amiento.",
        "Neuro Play acerca recursos para estimular habilidades mientras los chicos juegan.",
        "Compartir juegos en familia tambi\u00e9n puede fortalecer el aprendizaje.",
        "Algunos juegos permiten trabajar memoria, atenci\u00f3n, lenguaje, l\u00f3gica y motricidad.",
        "Jugar no es perder tiempo: tambi\u00e9n puede ser una forma de aprender."
    )

    $portalTexts = @(
        "Portal SGT permite que las familias consulten sesiones, materiales y avances desde cualquier dispositivo.",
        "El seguimiento digital ayuda a que las familias est\u00e9n m\u00e1s cerca del proceso.",
        "Cada sesi\u00f3n puede quedar registrada para acompa\u00f1ar mejor la evoluci\u00f3n.",
        "Acceder a la informaci\u00f3n ayuda a dar continuidad al trabajo terap\u00e9utico.",
        "Las familias pueden consultar el proceso de manera simple, clara y organizada."
    )

    switch ($Brand) {
        "neuroPlay" { return U (Get-Random $neuroTexts) }
        "portalSgt" { return U (Get-Random $portalTexts) }
        default { return U (Get-Random $aprendeTexts) }
    }
}

function Get-Benefits {
    param([string]$Brand)

    switch ($Brand) {
        "neuroPlay" {
            return @(
                "Juego compartido",
                "Estimulaci\u00f3n en casa",
                "Recursos para familias"
            ) | ForEach-Object { U $_ }
        }
        "portalSgt" {
            return @(
                "Sesiones registradas",
                "Acceso 24x7",
                "Materiales y adjuntos"
            )
        }
        default {
            return @(
                "Acompa\u00f1amiento psicopedag\u00f3gico",
                "Estrategias personalizadas",
                "Orientaci\u00f3n a familias"
            ) | ForEach-Object { U $_ }
        }
    }
}

function Get-CaptionTemplate {
    param([string]$Brand)

    switch ($Brand) {
        "neuroPlay" { return "neuroPlay" }
        "portalSgt" { return "portalSgt" }
        default { return "educational" }
    }
}

function Get-CategoryForBrand {
    param([object]$Generators, [string]$Brand)

    return Get-RandomProperty $Generators.$Brand.categories
}

function Get-NextId {
    param([object]$History)

    if (-not $History.publications -or $History.publications.Count -eq 0) {
        return 1
    }

    $ids = @(
        $History.publications |
        ForEach-Object {
            if ($_.id) { [int]$_.id }
        }
    )

    if ($ids.Count -eq 0) { return 1 }

    return ([int](($ids | Measure-Object -Maximum).Maximum) + 1)
}

$generators = Read-JsonUtf8 $GeneratorsPath
$history = Read-JsonUtf8 $HistoryPath

if (-not ($history.PSObject.Properties.Name -contains "publications")) {
    $history | Add-Member -NotePropertyName publications -NotePropertyValue @() -Force
}

$recentKeys = @(Get-RecentKeys -History $history -Take 30)

$selectedBrand = $null
$selectedCategoryName = $null
$selectedTopic = $null
$topicKey = $null

for ($i = 0; $i -lt 50; $i++) {
    $brand = Get-SelectedBrand -Override $BrandOverride
    $category = Get-CategoryForBrand -Generators $generators -Brand $brand
    $topic = Get-Random @($category.Value.topics)

    $candidateKey = "$brand|$($category.Name)|$topic"

    if ($recentKeys -notcontains $candidateKey) {
        $selectedBrand = $brand
        $selectedCategoryName = $category.Name
        $selectedTopic = $topic
        $topicKey = $candidateKey
        break
    }
}

if (-not $selectedBrand) {
    $selectedBrand = Get-SelectedBrand -Override $BrandOverride
    $category = Get-CategoryForBrand -Generators $generators -Brand $selectedBrand
    $selectedCategoryName = $category.Name
    $selectedTopic = Get-Random @($category.Value.topics)
    $topicKey = "$selectedBrand|$selectedCategoryName|$selectedTopic"
}

$type = Get-CaptionTemplate $selectedBrand
$nextId = Get-NextId -History $history

$content = [pscustomobject]@{
    id = $nextId
    category = $selectedCategoryName
    topic = $selectedTopic
    topicKey = $topicKey
    brandFocus = $selectedBrand
    brandOverride = (-not [string]::IsNullOrWhiteSpace($BrandOverride))
    type = $type
    title = New-Title -Brand $selectedBrand -Topic $selectedTopic
    flyerText = New-FlyerText -Brand $selectedBrand
    benefits = Get-Benefits -Brand $selectedBrand
    captionTemplate = $type
    layoutType = "dynamic"
    useNeuroPlayProduct = ($selectedBrand -eq "neuroPlay")
    usePortalSgt = ($selectedBrand -eq "portalSgt")
    cta = "Consultanos por WhatsApp al 11 2732-5400."
    createdAt = (Get-Date).ToString("s")
}

if ($history.PSObject.Properties.Name -contains "lastGeneratedAt") {
    $history.lastGeneratedAt = (Get-Date).ToString("s")
}
else {
    $history | Add-Member -NotePropertyName lastGeneratedAt -NotePropertyValue (Get-Date).ToString("s") -Force
}

$history.publications = @($history.publications) + [pscustomobject]@{
    id = $content.id
    title = $content.title
    category = $content.category
    topic = $content.topic
    topicKey = $content.topicKey
    brandFocus = $content.brandFocus
    status = "generated"
    generatedAt = (Get-Date).ToString("s")
}

Write-JsonUtf8 -Path $HistoryPath -Data $history

$out = $content | ConvertTo-Json -Depth 30
[System.IO.File]::WriteAllText((Join-Path $Root "output\last-content.json"), $out, [System.Text.UTF8Encoding]::new($false))

Write-Host "Contenido generado correctamente."
Write-Host "Ver archivo:"
Write-Host (Join-Path $Root "output\last-content.json")