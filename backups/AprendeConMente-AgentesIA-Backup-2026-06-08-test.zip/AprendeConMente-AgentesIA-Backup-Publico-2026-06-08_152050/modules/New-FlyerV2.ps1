param(
    [string]$Root = ""
)
$ErrorActionPreference = "Stop"

[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)

function Get-ProjectRoot {
    param([string]$RequestedRoot)
    if (-not [string]::IsNullOrWhiteSpace($RequestedRoot)) {
        return (Resolve-Path -LiteralPath $RequestedRoot).Path
    }
    if (-not [string]::IsNullOrWhiteSpace($PSScriptRoot)) {
        return (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot ".." )).Path
    }
    return (Get-Location).Path
}

$Root = Get-ProjectRoot -RequestedRoot $Root

$ContentPath = Join-Path $Root "output\last-content.json"
$CaptionPath = Join-Path $Root "output\last-caption.json"
$BrandPath = Join-Path $Root "config\brand.json"

$TemplatesRoot = Join-Path $Root "assets\templates"
$LogosRoot = Join-Path $Root "assets\logos"

$OutputDir = Join-Path $Root "output\flyers"
$OutputPath = Join-Path $OutputDir "last-flyer.png"
$MetadataPath = Join-Path $OutputDir "last-flyer.json"
$ImagePromptPath = Join-Path $Root "output\last-image-prompt.json"
$LayoutHistoryPath = Join-Path $Root "config\layout-history.json"

function U([string]$Text) {
    return [regex]::Replace($Text, '\\u([0-9a-fA-F]{4})', {
        param($m)
        [char][convert]::ToInt32($m.Groups[1].Value, 16)
    })
}

function Read-JsonUtf8 {
    param([string]$Path)

    if (-not (Test-Path $Path)) {
        throw "No existe el archivo: $Path"
    }

    $json = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
    return $json | ConvertFrom-Json
}

function Write-TextUtf8 {
    param(
        [string]$Path,
        [string]$Text
    )

    $dir = Split-Path $Path -Parent
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    [System.IO.File]::WriteAllText($Path, $Text, [System.Text.UTF8Encoding]::new($false))
}

function Write-JsonUtf8 {
    param(
        [string]$Path,
        [object]$Data
    )

    $json = $Data | ConvertTo-Json -Depth 30
    Write-TextUtf8 -Path $Path -Text $json
}

function Get-Color {
    param([string]$Hex)

    $hexClean = $Hex.Replace("#", "")
    $r = [Convert]::ToInt32($hexClean.Substring(0, 2), 16)
    $g = [Convert]::ToInt32($hexClean.Substring(2, 2), 16)
    $b = [Convert]::ToInt32($hexClean.Substring(4, 2), 16)

    return [System.Drawing.Color]::FromArgb($r, $g, $b)
}

function New-Font {
    param(
        [string]$Name,
        [float]$Size,
        [System.Drawing.FontStyle]$Style = [System.Drawing.FontStyle]::Regular
    )

    return New-Object System.Drawing.Font($Name, $Size, $Style, [System.Drawing.GraphicsUnit]::Pixel)
}

function New-Rect {
    param(
        [int]$X,
        [int]$Y,
        [int]$W,
        [int]$H
    )

    return New-Object System.Drawing.RectangleF([float]$X, [float]$Y, [float]$W, [float]$H)
}

function New-StringFormat {
    param(
        [System.Drawing.StringAlignment]$Align = [System.Drawing.StringAlignment]::Near
    )

    $format = New-Object System.Drawing.StringFormat
    $format.Alignment = $Align
    $format.LineAlignment = [System.Drawing.StringAlignment]::Near
    $format.Trimming = [System.Drawing.StringTrimming]::EllipsisWord
    $format.FormatFlags = [System.Drawing.StringFormatFlags]::LineLimit

    return $format
}

function Draw-RoundedRectangle {
    param(
        [System.Drawing.Graphics]$Graphics,
        [System.Drawing.Brush]$Brush,
        [int]$X,
        [int]$Y,
        [int]$W,
        [int]$H,
        [int]$R
    )

    if ($W -le 0 -or $H -le 0) {
        return
    }

    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    try {
        $d = [Math]::Min($R * 2, [Math]::Min($W, $H))
        $path.AddArc($X, $Y, $d, $d, 180, 90)
        $path.AddArc($X + $W - $d, $Y, $d, $d, 270, 90)
        $path.AddArc($X + $W - $d, $Y + $H - $d, $d, $d, 0, 90)
        $path.AddArc($X, $Y + $H - $d, $d, $d, 90, 90)
        $path.CloseFigure()
        $Graphics.FillPath($Brush, $path)
    }
    finally {
        $path.Dispose()
    }
}

function Draw-WrappedText {
    param(
        [System.Drawing.Graphics]$Graphics,
        [string]$Text,
        [System.Drawing.Font]$Font,
        [System.Drawing.Brush]$Brush,
        [int]$X,
        [int]$Y,
        [int]$W,
        [int]$H,
        [System.Drawing.StringAlignment]$Align = [System.Drawing.StringAlignment]::Near
    )

    if ([string]::IsNullOrWhiteSpace($Text) -or $W -le 0 -or $H -le 0) {
        return
    }

    $format = New-StringFormat -Align $Align
    try {
        $rect = New-Rect $X $Y $W $H
        $Graphics.DrawString($Text, $Font, $Brush, $rect, $format)
    }
    finally {
        $format.Dispose()
    }
}

function Measure-TextHeight {
    param(
        [System.Drawing.Graphics]$Graphics,
        [string]$Text,
        [System.Drawing.Font]$Font,
        [int]$W,
        [int]$MaxH
    )

    if ([string]::IsNullOrWhiteSpace($Text) -or $W -le 0 -or $MaxH -le 0) {
        return 0
    }

    $format = New-StringFormat
    try {
        $layout = New-Object System.Drawing.SizeF([float]$W, [float]$MaxH)
        $size = $Graphics.MeasureString($Text, $Font, $layout, $format)
        return [int][Math]::Ceiling($size.Height)
    }
    finally {
        $format.Dispose()
    }
}

function Draw-ImageCover {
    param(
        [System.Drawing.Graphics]$Graphics,
        [string]$Path,
        [int]$X,
        [int]$Y,
        [int]$W,
        [int]$H
    )

    if (-not (Test-Path $Path)) {
        throw "No existe la imagen base: $Path"
    }

    $img = [System.Drawing.Image]::FromFile($Path)
    try {
        $scale = [Math]::Max($W / $img.Width, $H / $img.Height)
        $sw = [int]($W / $scale)
        $sh = [int]($H / $scale)
        $sx = [int](($img.Width - $sw) / 2)
        $sy = [int](($img.Height - $sh) / 2)

        $src = New-Object System.Drawing.Rectangle($sx, $sy, $sw, $sh)
        $dst = New-Object System.Drawing.Rectangle($X, $Y, $W, $H)
        $Graphics.DrawImage($img, $dst, $src, [System.Drawing.GraphicsUnit]::Pixel)
    }
    finally {
        $img.Dispose()
    }
}

function Draw-ImageContain {
    param(
        [System.Drawing.Graphics]$Graphics,
        [string]$Path,
        [int]$X,
        [int]$Y,
        [int]$W,
        [int]$H
    )

    if (-not (Test-Path $Path)) {
        return
    }

    $img = [System.Drawing.Image]::FromFile($Path)
    try {
        $scale = [Math]::Min($W / $img.Width, $H / $img.Height)
        $dw = [int]($img.Width * $scale)
        $dh = [int]($img.Height * $scale)
        $dx = $X + [int](($W - $dw) / 2)
        $dy = $Y + [int](($H - $dh) / 2)
        $dst = New-Object System.Drawing.Rectangle($dx, $dy, $dw, $dh)
        $Graphics.DrawImage($img, $dst)
    }
    finally {
        $img.Dispose()
    }
}

function Get-TemplateFolder {
    param([string]$BrandFocus)

    switch ($BrandFocus) {
        "neuroPlay" { return Join-Path $TemplatesRoot "neuroplay" }
        "portalSgt" { return Join-Path $TemplatesRoot "portal-sgt" }
        default { return Join-Path $TemplatesRoot "aprendeconmente" }
    }
}

function Get-TemplateKeywords {
    param(
        [string]$BrandFocus,
        [string]$Category,
        [string]$Topic
    )

    $value = (($Category + " " + $Topic).ToLowerInvariant())

    if ($BrandFocus -eq "portalSgt") {
        if ($value -match "acceso|famil") { return @("Acceso Familiar") }
        if ($value -match "informe|reporte|registro") { return @("Informes") }
        if ($value -match "comunic|mensaje") { return @("Comunicacion") }
        return @("Seguimiento")
    }

    if ($BrandFocus -eq "neuroPlay") {
        if ($value -match "lenguaje|lectura|letra|palabra") { return @("Lenguaje") }
        if ($value -match "logica|razonamiento|estrategia|problema") { return @("Logica") }
        if ($value -match "memoria|recordar") { return @("Memoria") }
        if ($value -match "familia|juego") { return @("Juego en Familia") }
        return @((U "Atenci\u00f3n"))
    }

    if ($value -match "lectura|comprension|consigna|fluidez") { return @("Lectura") }
    if ($value -match "escritura|expresion|texto") { return @("Escritura") }
    if ($value -match "memoria|recordar|retencion") { return @("Memoria") }
    if ($value -match "tecnica|estudio|organizacion|planificacion|rutina") { return @((U "T\u00e9cnicas de estudio")) }
    if ($value -match "dificultad|rendimiento|desmotivacion|escolar") { return @("Dificultades escolares") }
    return @((U "Atenci\u00f3n"))
}

function Select-TemplateImage {
    param([object]$Content)

    $folder = Get-TemplateFolder -BrandFocus $Content.brandFocus
    if (-not (Test-Path $folder)) {
        throw "No existe la carpeta de templates: $folder"
    }

    $files = @(Get-ChildItem -Path $folder -File | Where-Object { $_.Extension -match "^\.(png|jpg|jpeg|webp)$" })
    if ($files.Count -eq 0) {
        throw "No hay imagenes base en: $folder"
    }

    $keywords = Get-TemplateKeywords -BrandFocus $Content.brandFocus -Category $Content.category -Topic $Content.topic
    foreach ($keyword in $keywords) {
        $match = @($files | Where-Object { $_.BaseName -like "$keyword*" })
        if ($match.Count -gt 0) {
            return ($match | Get-Random).FullName
        }
    }

    return ($files | Get-Random).FullName
}

function Get-FlyerPalette {
    param(
        [object]$Brand,
        [string]$BrandFocus
    )

    $primary = Get-Color $Brand.colors.primaryBlue
    $accent = Get-Color $Brand.colors.cyan
    $bullet = Get-Color $Brand.colors.pink

    switch ($BrandFocus) {
        "portalSgt" {
            $accent = Get-Color "#1FA971"
            $bullet = Get-Color $Brand.colors.cyan
        }
        "neuroPlay" {
            $accent = Get-Color $Brand.colors.cyan
            $bullet = Get-Color $Brand.colors.pink
        }
        default {
            $accent = Get-Color $Brand.colors.primaryBlue
            $bullet = Get-Color $Brand.colors.cyan
        }
    }

    return [pscustomobject]@{
        Primary = $primary
        Accent = $accent
        Cyan = Get-Color $Brand.colors.cyan
        Pink = Get-Color $Brand.colors.pink
        Yellow = Get-Color $Brand.colors.yellow
        White = Get-Color $Brand.colors.white
        Panel = [System.Drawing.Color]::FromArgb(236, 255, 255, 255)
        LightPanel = [System.Drawing.Color]::FromArgb(222, 255, 253, 247)
        Shadow = [System.Drawing.Color]::FromArgb(105, 6, 20, 48)
        Overlay = [System.Drawing.Color]::FromArgb(25, 6, 20, 48)
        FooterOverlay = [System.Drawing.Color]::FromArgb(72, 6, 20, 48)
        Bullet = $bullet
    }
}

function Get-BrandLabel {
    param([string]$BrandFocus)

    switch ($BrandFocus) {
        "neuroPlay" { return "Neuro Play" }
        "portalSgt" { return "Portal SGT" }
        default { return "Aprende con Mente" }
    }
}

function Get-LogoPath {
    param([string]$BrandFocus)

    $brandLogo = switch ($BrandFocus) {
        "portalSgt" { Join-Path $LogosRoot "portal-sgt.jpg" }
        "neuroPlay" { Join-Path $LogosRoot "neuroplay.png" }
        default { Join-Path $LogosRoot "aprendeconmente.png" }
    }

    if (Test-Path $brandLogo) {
        return $brandLogo
    }

    $fallback = Join-Path $LogosRoot "aprendeconmente.png"
    if (Test-Path $fallback) {
        return $fallback
    }

    return $null
}


function Limit-Text {
    param(
        [string]$Text,
        [int]$MaxLength
    )

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return ""
    }

    $clean = [regex]::Replace($Text.Trim(), "\s+", " ")

    if ($clean.Length -le $MaxLength) {
        return $clean
    }

    $cut = $clean.Substring(0, [Math]::Max(0, $MaxLength - 1)).TrimEnd()
    $lastSpace = $cut.LastIndexOf(" ")

    if ($lastSpace -gt 38) {
        $cut = $cut.Substring(0, $lastSpace).TrimEnd()
    }

    return "$cut…"
}

function Get-ShortTitle {
    param([object]$Content)

    $topic = ""
    if ($Content.topic) {
        $topic = ([string]$Content.topic).Trim()
    }

    $category = ""
    if ($Content.category) {
        $category = ([string]$Content.category).Trim()
    }

    $title = ""

    switch ($Content.brandFocus) {
        "neuroPlay" {
            switch -Regex ($category) {
                "memory|memoria" { $title = "Memoria en juego" }
                "attention|atencion" { $title = "Atenci\u00f3n jugando" }
                "language|lenguaje" { $title = "Lenguaje en familia" }
                "logic|logica" { $title = "Pensar jugando" }
                "family|familia" { $title = "Jugar tambi\u00e9n ense\u00f1a" }
                default {
                    if ($topic.Length -gt 0) { $title = "Jugar con $topic" }
                    else { $title = "Jugar tambi\u00e9n ense\u00f1a" }
                }
            }
        }
        "portalSgt" {
            switch -Regex ($category) {
                "seguimiento|tracking" { $title = "Seguimiento claro" }
                "acceso|access" { $title = "Acceso simple" }
                "informes|reports" { $title = "Informes claros" }
                "comunicacion|communication" { $title = "Comunicaci\u00f3n ordenada" }
                default {
                    if ($topic.Length -gt 0) { $title = "Gesti\u00f3n para $topic" }
                    else { $title = "Seguimiento simple" }
                }
            }
        }
        default {
            switch -Regex ($category) {
                "attention|atencion" { $title = "Atenci\u00f3n: qu\u00e9 observar" }
                "reading|lectura" { $title = "Lectura con confianza" }
                "writing|escritura" { $title = "Escritura paso a paso" }
                "memory|memoria" { $title = "Memoria y aprendizaje" }
                "study|estudio" { $title = "Estudiar con m\u00e9todo" }
                "school|dificultades" { $title = "Dificultades escolares" }
                default {
                    if ($topic.Length -gt 0) { $title = "Acompa\u00f1ar $topic" }
                    else { $title = "Aprender mejor" }
                }
            }
        }
    }

    return Limit-Text -Text $title -MaxLength 54
}


function Get-Subtitle {
    param([object]$Content)

    if ($Content.flyerText) {
        $text = [string]$Content.flyerText
    }
    elseif ($Content.summary) {
        $text = [string]$Content.summary
    }
    elseif ($Content.topic) {
        $text = "Una idea simple para acompa\u00f1ar $($Content.topic)."
    }
    else {
        $text = "Una idea simple para acompa\u00f1ar mejor."
    }

    $text = [regex]::Replace($text, "\s+", " ").Trim()
    $text = $text -replace "^(Hoy|En este post|En esta publicaci\u00f3n),?\s+", ""

    return Limit-Text -Text $text -MaxLength 88
}


function Get-Benefits {
    param([object]$Content)

    $category = ""
    if ($Content.category) {
        $category = [string]$Content.category
    }

    switch ($Content.brandFocus) {
        "portalSgt" {
            switch -Regex ($category) {
                "seguimiento|tracking" { return @("Seguimiento", "Control", "Orden") }
                "acceso|access" { return @("Acceso familiar", "Datos claros", "Autonomia") }
                "informes|reports" { return @("Informes", "Evolucion", "Claridad") }
                "comunicacion|communication" { return @("Comunicacion", "Familias", "Organizacion") }
                default { return @("Seguimiento", "Informes", "Comunicacion") }
            }
        }
        "neuroPlay" {
            switch -Regex ($category) {
                "memory|memoria" { return @("Memoria", "Atencion", "Juego compartido") }
                "attention|atencion" { return @("Atencion", "Autocontrol", "Juego guiado") }
                "language|lenguaje" { return @("Lenguaje", "Vocabulario", "Interaccion") }
                "logic|logica" { return @("Logica", "Pensamiento", "Estrategia") }
                "family|familia" { return @("Familia", "Vinculo", "Aprendizaje") }
                default { return @("Juego", "Familia", "Aprendizaje") }
            }
        }
        default {
            switch -Regex ($category) {
                "attention|atencion" { return @("Atencion", "Rutinas", "Estrategias") }
                "reading|lectura" { return @("Lectura", "Comprension", "Confianza") }
                "writing|escritura" { return @("Escritura", "Organizacion", "Practica") }
                "memory|memoria" { return @("Memoria", "Aprendizaje", "Habitos") }
                "study|estudio" { return @("Estudio", "Planificacion", "Autonomia") }
                "school|dificultades" { return @("Observacion", "Acompanamiento", "Orientacion") }
                default { return @("Orientacion", "Familias", "Aprendizaje") }
            }
        }
    }
}

function Get-ContactText {
    param([object]$Brand)

    $whatsapp = "11 2732-5400"
    $location = "Villa Maipu, San Martin"

    if ($Brand.contact) {
        if ($Brand.contact.whatsappDisplay) {
            $whatsapp = [string]$Brand.contact.whatsappDisplay
        }
        elseif ($Brand.contact.whatsapp) {
            $whatsapp = [string]$Brand.contact.whatsapp
        }

        if ($Brand.contact.location) {
            $location = [string]$Brand.contact.location
        }
    }

    return "WhatsApp $whatsapp  |  $location"
}

function Get-Layouts {
    return @(
        [pscustomobject]@{ Name = "left-card"; X = 64; Y = 84; W = 456; MaxH = 620; Kind = "vertical" },
        [pscustomobject]@{ Name = "right-card"; X = 560; Y = 84; W = 456; MaxH = 620; Kind = "vertical" },
        [pscustomobject]@{ Name = "bottom-card"; X = 74; Y = 0; W = 932; MaxH = 310; Kind = "horizontal" },
        [pscustomobject]@{ Name = "top-card"; X = 74; Y = 70; W = 932; MaxH = 300; Kind = "horizontal" },
        [pscustomobject]@{ Name = "center-card"; X = 150; Y = 250; W = 780; MaxH = 430; Kind = "wide" }
    )
}

function Get-AllowedLayouts {
    param([string]$BrandFocus)

    switch ($BrandFocus) {
        "portalSgt" { return @("bottom-card", "center-card", "top-card", "right-card") }
        "neuroPlay" { return @("left-card", "right-card", "bottom-card", "top-card", "center-card") }
        default { return @("left-card", "right-card", "bottom-card", "top-card", "center-card") }
    }
}

function Get-PreferredLayoutFromPrompt {
    if (-not (Test-Path $ImagePromptPath)) {
        return $null
    }

    try {
        $imagePrompt = Read-JsonUtf8 $ImagePromptPath
        if ($imagePrompt.preferredLayout) {
            return [string]$imagePrompt.preferredLayout
        }
    }
    catch {
        return $null
    }

    return $null
}

function Get-RecentLayoutsForBrand {
    param([string]$BrandFocus)

    $recent = @()

    if (Test-Path $LayoutHistoryPath) {
        try {
            $history = Read-JsonUtf8 $LayoutHistoryPath
            if ($history.items) {
                $recent = @(
                    $history.items |
                    Where-Object { $_.brandFocus -eq $BrandFocus } |
                    Select-Object -Last 4 |
                    ForEach-Object { [string]$_.layout }
                )
            }
        }
        catch {
            $recent = @()
        }
    }

    return $recent
}

function Save-LayoutHistory {
    param(
        [object]$Content,
        [string]$LayoutName,
        [string]$VisualMode
    )

    $items = @()

    if (Test-Path $LayoutHistoryPath) {
        try {
            $history = Read-JsonUtf8 $LayoutHistoryPath
            if ($history.items) {
                $items = @($history.items)
            }
        }
        catch {
            $items = @()
        }
    }

    $items += [pscustomobject]@{
        createdAt = (Get-Date).ToString("s")
        brandFocus = $Content.brandFocus
        category = $Content.category
        topic = $Content.topic
        layout = $LayoutName
        visualMode = $VisualMode
    }

    $items = @($items | Select-Object -Last 80)

    $data = [pscustomobject]@{
        updatedAt = (Get-Date).ToString("s")
        items = $items
    }

    Write-JsonUtf8 -Path $LayoutHistoryPath -Data $data
}

function Select-Layout {
    param([object]$Content)

    $layouts = Get-Layouts
    $allowed = Get-AllowedLayouts -BrandFocus $Content.brandFocus
    $recentLayouts = @(Get-RecentLayoutsForBrand -BrandFocus $Content.brandFocus)
    $preferredLayout = Get-PreferredLayoutFromPrompt

    $pool = @($layouts | Where-Object { $_.Name -in $allowed })

    if ($preferredLayout) {
        $preferred = @($pool | Where-Object { $_.Name -eq $preferredLayout })
        if ($preferred.Count -gt 0 -and $recentLayouts -notcontains $preferredLayout) {
            return $preferred[0]
        }
    }

    $freshPool = @($pool | Where-Object { $recentLayouts -notcontains $_.Name })

    if ($freshPool.Count -gt 0) {
        return $freshPool | Get-Random
    }

    return $pool | Get-Random
}


function Get-PanelSpec {
    param(
        [System.Drawing.Graphics]$Graphics,
        [object]$Layout,
        [string]$Title,
        [string]$Subtitle,
        [object[]]$Benefits
    )

    $pad = 28
    $innerW = [int]$Layout.W - ($pad * 2)

    $benefitOptions = @(2, 1, 0)
    $titleSizes = @(32, 30, 28, 26)
    $subtitleSizes = @(20, 18, 16)

    if ($Layout.Kind -eq "horizontal") {
        $pad = 26
        $innerW = [int]$Layout.W - ($pad * 2)
        $benefitOptions = @(2, 1, 0)
        $titleSizes = @(34, 32, 30, 28)
        $subtitleSizes = @(20, 18, 16)
    }
    elseif ($Layout.Kind -eq "vertical") {
        $benefitOptions = @(2, 1, 0)
        $titleSizes = @(35, 32, 30, 28)
        $subtitleSizes = @(19, 17, 16)
    }

    foreach ($benefitCount in $benefitOptions) {
        foreach ($titleSize in $titleSizes) {
            foreach ($subtitleSize in $subtitleSizes) {
                $fontTitle = New-Font "Arial" $titleSize ([System.Drawing.FontStyle]::Bold)
                $fontSubtitle = New-Font "Arial" $subtitleSize ([System.Drawing.FontStyle]::Regular)
                $fontBenefit = New-Font "Arial" 19 ([System.Drawing.FontStyle]::Bold)

                try {
                    $headerH = 48
                    $titleH = Measure-TextHeight -Graphics $Graphics -Text $Title -Font $fontTitle -W $innerW -MaxH 96
                    $subtitleH = Measure-TextHeight -Graphics $Graphics -Text $Subtitle -Font $fontSubtitle -W $innerW -MaxH 56

                    if ($Layout.Kind -eq "horizontal") {
                        $titleH = [Math]::Min($titleH, 72)
                        $subtitleH = [Math]::Min($subtitleH, 42)
                    }
                    else {
                        $titleH = [Math]::Min($titleH, 92)
                        $subtitleH = [Math]::Min($subtitleH, 54)
                    }

                    $rowH = 36
                    $rowGap = 7

                    if ($Layout.Kind -eq "vertical") {
                        $rowH = 38
                        $rowGap = 8
                    }

                    $benefitsH = 0
                    if ($benefitCount -gt 0) {
                        $benefitsH = ($benefitCount * $rowH) + (($benefitCount - 1) * $rowGap)
                    }

                    $gap1 = 16
                    $gap2 = 10
                    $gap3 = 14

                    $needH = ($pad * 2) + $headerH + $gap1 + $titleH + $gap2 + $subtitleH
                    if ($benefitCount -gt 0) {
                        $needH += $gap3 + $benefitsH
                    }

                    if ($needH -le [int]$Layout.MaxH) {
                        return [pscustomobject]@{
                            Pad = $pad
                            H = [int][Math]::Ceiling($needH)
                            HeaderH = $headerH
                            TitleSize = $titleSize
                            SubtitleSize = $subtitleSize
                            BenefitSize = 19
                            TitleH = [int]$titleH
                            SubtitleH = [int]$subtitleH
                            BenefitCount = $benefitCount
                            BenefitRowH = $rowH
                            BenefitGap = $rowGap
                            Gap1 = $gap1
                            Gap2 = $gap2
                            Gap3 = $gap3
                        }
                    }
                }
                finally {
                    $fontTitle.Dispose()
                    $fontSubtitle.Dispose()
                    $fontBenefit.Dispose()
                }
            }
        }
    }

    return [pscustomobject]@{
        Pad = 26
        H = [int]$Layout.MaxH
        HeaderH = 46
        TitleSize = 28
        SubtitleSize = 17
        BenefitSize = 18
        TitleH = 82
        SubtitleH = 48
        BenefitCount = 0
        BenefitRowH = 36
        BenefitGap = 7
        Gap1 = 14
        Gap2 = 8
        Gap3 = 12
    }
}

function Draw-HeaderBrand {
    param(
        [System.Drawing.Graphics]$Graphics,
        [object]$Content,
        [string]$BrandLabel,
        [object]$Palette,
        [int]$X,
        [int]$Y,
        [int]$W,
        [int]$H,
        [System.Drawing.Brush]$BrushAccent,
        [System.Drawing.Brush]$BrushWhite,
        [System.Drawing.Brush]$BrushPrimary
    )

    $logoPath = Get-LogoPath -BrandFocus $Content.brandFocus
    $fontBrand = New-Font "Arial" 20 ([System.Drawing.FontStyle]::Bold)

    try {
        $chipW = [Math]::Min(310, [Math]::Max(220, ($BrandLabel.Length * 12) + 120))
        Draw-RoundedRectangle $Graphics $BrushAccent $X $Y $chipW $H ([int]($H / 2))

        if ($null -ne $logoPath) {
            Draw-ImageContain $Graphics $logoPath ($X + 12) ($Y + 7) 46 ($H - 14)
            Draw-WrappedText $Graphics $BrandLabel $fontBrand $BrushWhite ($X + 66) ($Y + 10) ($chipW - 78) 26
        }
        else {
            Draw-WrappedText $Graphics $BrandLabel $fontBrand $BrushWhite ($X + 12) ($Y + 10) ($chipW - 24) 26 ([System.Drawing.StringAlignment]::Center)
        }
    }
    finally {
        $fontBrand.Dispose()
    }
}

function Draw-ContentPanel {
    param(
        [System.Drawing.Graphics]$Graphics,
        [object]$Content,
        [object]$Brand,
        [object]$Palette,
        [object]$Layout,
        [System.Drawing.Brush]$BrushPrimary,
        [System.Drawing.Brush]$BrushAccent,
        [System.Drawing.Brush]$BrushBullet,
        [System.Drawing.Brush]$BrushWhite,
        [System.Drawing.Brush]$BrushPanel,
        [System.Drawing.Brush]$BrushLightPanel,
        [System.Drawing.Brush]$BrushShadow
    )

    $brandLabel = Get-BrandLabel -BrandFocus $Content.brandFocus
    $titleOriginal = [string]$Content.title
    $title = Get-ShortTitle -Content $Content
    $subtitle = Get-Subtitle -Content $Content
    $benefits = @(Get-Benefits -Content $Content)

    $spec = Get-PanelSpec -Graphics $Graphics -Layout $Layout -Title $title -Subtitle $subtitle -Benefits $benefits

    $x = [int]$Layout.X
    $y = [int]$Layout.Y
    $w = [int]$Layout.W
    $h = [int]$spec.H

    if ($Layout.Name -eq "bottom-card") {
        $y = 910 - $h
    }
    elseif ($Layout.Name -eq "center-card") {
        $y = [int](540 - ($h / 2))
    }

    Draw-RoundedRectangle $Graphics $BrushShadow ($x + 10) ($y + 12) $w $h 38
    Draw-RoundedRectangle $Graphics $BrushPanel $x $y $w $h 38

    $pad = [int]$spec.Pad
    $innerX = $x + $pad
    $innerY = $y + $pad
    $innerW = $w - ($pad * 2)
    $currentY = $innerY

    $fontTitle = New-Font "Arial" ([float]$spec.TitleSize) ([System.Drawing.FontStyle]::Bold)
    $fontSubtitle = New-Font "Arial" ([float]$spec.SubtitleSize) ([System.Drawing.FontStyle]::Regular)
    $fontBenefit = New-Font "Arial" ([float]$spec.BenefitSize) ([System.Drawing.FontStyle]::Bold)

    try {
        Draw-HeaderBrand `
            -Graphics $Graphics `
            -Content $Content `
            -BrandLabel $brandLabel `
            -Palette $Palette `
            -X $innerX `
            -Y $currentY `
            -W $innerW `
            -H ([int]$spec.HeaderH) `
            -BrushAccent $BrushAccent `
            -BrushWhite $BrushWhite `
            -BrushPrimary $BrushPrimary

        $currentY += [int]$spec.HeaderH + [int]$spec.Gap1

        Draw-WrappedText $Graphics $title $fontTitle $BrushPrimary $innerX $currentY $innerW ([int]$spec.TitleH)
        $currentY += [int]$spec.TitleH + [int]$spec.Gap2

        Draw-WrappedText $Graphics $subtitle $fontSubtitle $BrushPrimary $innerX $currentY $innerW ([int]$spec.SubtitleH)
        $currentY += [int]$spec.SubtitleH

        if ([int]$spec.BenefitCount -gt 0) {
            $currentY += [int]$spec.Gap3
            $itemsToDraw = [Math]::Min([int]$spec.BenefitCount, $benefits.Count)

            for ($i = 0; $i -lt $itemsToDraw; $i++) {
                $benefit = [string]$benefits[$i]
                Draw-RoundedRectangle $Graphics $BrushLightPanel $innerX $currentY $innerW ([int]$spec.BenefitRowH) 18
                Draw-RoundedRectangle $Graphics $BrushBullet ($innerX + 14) ($currentY + [int]((([int]$spec.BenefitRowH) - 16) / 2)) 16 16 8
                Draw-WrappedText $Graphics $benefit $fontBenefit $BrushPrimary ($innerX + 44) ($currentY + 7) ($innerW - 54) (([int]$spec.BenefitRowH) - 10)
                $currentY += [int]$spec.BenefitRowH + [int]$spec.BenefitGap
            }
        }
    }
    finally {
        $fontTitle.Dispose()
        $fontSubtitle.Dispose()
        $fontBenefit.Dispose()
    }

    return [pscustomobject]@{
        Name = $Layout.Name
        X = $x
        Y = $y
        W = $w
        H = $h
        BenefitCount = [int]$spec.BenefitCount
        Title = $title
        OriginalTitle = $titleOriginal
    }
}

function Draw-Footer {
    param(
        [System.Drawing.Graphics]$Graphics,
        [object]$Content,
        [object]$Brand,
        [System.Drawing.Brush]$BrushPrimary,
        [System.Drawing.Brush]$BrushWhite
    )

    $fontTag = New-Font "Arial" 25 ([System.Drawing.FontStyle]::Bold)
    try {
        Draw-RoundedRectangle $Graphics $BrushPrimary 60 952 960 84 34
        Draw-WrappedText $Graphics (Get-ContactText -Brand $Brand) $fontTag $BrushWhite 86 978 724 42
        $logoPath = Get-LogoPath -BrandFocus $Content.brandFocus
        if ($null -ne $logoPath) {
            Draw-ImageContain $Graphics $logoPath 828 963 158 62
        }
    }
    finally {
        $fontTag.Dispose()
    }
}

function New-Flyer {
    if (-not (Test-Path $OutputDir)) {
        New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
    }

    Add-Type -AssemblyName System.Drawing

    $content = Read-JsonUtf8 $ContentPath
    $brand = Read-JsonUtf8 $BrandPath
    $caption = $null
    $imagePrompt = $null

    if (Test-Path $ImagePromptPath) {
        try { $imagePrompt = Read-JsonUtf8 $ImagePromptPath } catch { $imagePrompt = $null }
    }

    if (Test-Path $CaptionPath) {
        $caption = Read-JsonUtf8 $CaptionPath
    }

    $templatePath = Select-TemplateImage -Content $content
    $palette = Get-FlyerPalette -Brand $brand -BrandFocus $content.brandFocus
    $layout = Select-Layout -Content $content

    $width = 1080
    $height = 1080

    $bitmap = New-Object System.Drawing.Bitmap($width, $height)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)

    $brushPrimary = New-Object System.Drawing.SolidBrush($palette.Primary)
    $brushAccent = New-Object System.Drawing.SolidBrush($palette.Accent)
    $brushBullet = New-Object System.Drawing.SolidBrush($palette.Bullet)
    $brushWhite = New-Object System.Drawing.SolidBrush($palette.White)
    $brushPanel = New-Object System.Drawing.SolidBrush($palette.Panel)
    $brushLightPanel = New-Object System.Drawing.SolidBrush($palette.LightPanel)
    $brushShadow = New-Object System.Drawing.SolidBrush($palette.Shadow)
    $brushOverlay = New-Object System.Drawing.SolidBrush($palette.Overlay)
    $brushFooterOverlay = New-Object System.Drawing.SolidBrush($palette.FooterOverlay)

    $panelInfo = $null

    try {
        $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $graphics.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit

        Draw-ImageCover $graphics $templatePath 0 0 $width $height

        $graphics.FillRectangle($brushOverlay, 0, 0, $width, $height)
        $graphics.FillRectangle($brushFooterOverlay, 0, 930, $width, 150)

        $panelInfo = Draw-ContentPanel `
            -Graphics $graphics `
            -Content $content `
            -Brand $brand `
            -Palette $palette `
            -Layout $layout `
            -BrushPrimary $brushPrimary `
            -BrushAccent $brushAccent `
            -BrushBullet $brushBullet `
            -BrushWhite $brushWhite `
            -BrushPanel $brushPanel `
            -BrushLightPanel $brushLightPanel `
            -BrushShadow $brushShadow

        Draw-Footer -Graphics $graphics -Content $content -Brand $brand -BrushPrimary $brushPrimary -BrushWhite $brushWhite

        $bitmap.Save($OutputPath, [System.Drawing.Imaging.ImageFormat]::Png)

        $metadata = [pscustomobject]@{
            createdAt = (Get-Date).ToString("s")
            contentId = $content.id
            brandFocus = $content.brandFocus
            category = $content.category
            topic = $content.topic
            title = $content.title
            layout = $layout.Name
            panel = $panelInfo
            templateImage = $templatePath
            outputImage = $OutputPath
            captionAvailable = ($null -ne $caption)
            visualMode = $(if ($null -ne $imagePrompt) { $imagePrompt.visualMode } else { $null })
            preferredLayout = $(if ($null -ne $imagePrompt) { $imagePrompt.preferredLayout } else { $null })
            textZone = $(if ($null -ne $imagePrompt) { $imagePrompt.textZone } else { $null })
            engine = "New-FlyerV2 v4-visual-variety-text-control"
        }

        Write-JsonUtf8 -Path $MetadataPath -Data $metadata
        Save-LayoutHistory -Content $content -LayoutName $layout.Name -VisualMode $metadata.visualMode
    }
    finally {
        $brushPrimary.Dispose()
        $brushAccent.Dispose()
        $brushBullet.Dispose()
        $brushWhite.Dispose()
        $brushPanel.Dispose()
        $brushLightPanel.Dispose()
        $brushShadow.Dispose()
        $brushOverlay.Dispose()
        $brushFooterOverlay.Dispose()

        $graphics.Dispose()
        $bitmap.Dispose()
    }

    Write-Host "Flyer V2 generado correctamente."
    Write-Host $OutputPath
}

New-Flyer
