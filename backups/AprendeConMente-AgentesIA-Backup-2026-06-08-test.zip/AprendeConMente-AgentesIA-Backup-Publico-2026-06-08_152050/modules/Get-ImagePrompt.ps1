param(
    [string]$Root = ""
)
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)

function Get-ProjectRoot {
    param([string]$RequestedRoot)
    if (-not [string]::IsNullOrWhiteSpace($RequestedRoot)) {
        return (Resolve-Path -LiteralPath $RequestedRoot).Path
    }
    if (-not [string]::IsNullOrWhiteSpace($PSScriptRoot)) {
        return (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot ".." )).Path
    }
    return (Get-Location).Path
}

$Root = Get-ProjectRoot -RequestedRoot $Root

$ContentPath = Join-Path $Root "output\last-content.json"
$PromptsPath = Join-Path $Root "config\image-prompts.json"
$OutputPath = Join-Path $Root "output\last-image-prompt.json"
$OutputTxtPath = Join-Path $Root "output\last-image-prompt.txt"

function U([string]$Text) {
    return [regex]::Replace($Text, '\\u([0-9a-fA-F]{4})', {
        param($m)
        [char][convert]::ToInt32($m.Groups[1].Value, 16)
    })
}

function Read-JsonUtf8 {
    param([string]$Path)

    if (-not (Test-Path $Path)) {
        throw "No existe el archivo: $Path"
    }

    $json = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
    return $json | ConvertFrom-Json
}

function Write-TextUtf8 {
    param(
        [string]$Path,
        [string]$Text
    )

    $dir = Split-Path $Path -Parent

    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    [System.IO.File]::WriteAllText($Path, $Text, [System.Text.UTF8Encoding]::new($false))
}

function Write-JsonUtf8 {
    param(
        [string]$Path,
        [object]$Data
    )

    $json = $Data | ConvertTo-Json -Depth 30
    Write-TextUtf8 -Path $Path -Text $json
}

function Get-PromptValue {
    param(
        [object]$Prompts,
        [string]$Brand,
        [string]$Category
    )

    if (-not $Prompts.$Brand) {
        throw "No existe configuracion visual para la marca: $Brand"
    }

    $brandPrompts = $Prompts.$Brand

    if ($brandPrompts.PSObject.Properties.Name -contains $Category) {
        return $brandPrompts.$Category
    }

    if ($brandPrompts.PSObject.Properties.Name -contains "default") {
        return $brandPrompts.default
    }

    throw "No existe prompt para marca '$Brand' categoria '$Category' ni default."
}

function Get-BrandDisplayName {
    param([string]$Brand)

    switch ($Brand) {
        "aprendeConMente" { return "Aprende con Mente" }
        "neuroPlay" { return "Neuro Play" }
        "portalSgt" { return "Portal SGT" }
        default { return $Brand }
    }
}

function Get-VisualFocus {
    param(
        [string]$Brand,
        [string]$Category
    )

    if ($Brand -eq "neuroPlay") {
        return (U "Juego educativo, aprendizaje en casa, participaci\u00f3n familiar, habilidades cognitivas y desarrollo infantil.")
    }

    if ($Brand -eq "portalSgt") {
        return (U "Tecnolog\u00eda simple para familias, seguimiento terap\u00e9utico, claridad, confianza y organizaci\u00f3n.")
    }

    switch ($Category) {
        "attention" {
            return (U "Atenci\u00f3n, concentraci\u00f3n, organizaci\u00f3n y acompa\u00f1amiento psicopedag\u00f3gico.")
        }
        "reading" {
            return (U "Lectura, comprensi\u00f3n, acompa\u00f1amiento adulto y confianza en el aprendizaje.")
        }
        "writing" {
            return (U "Escritura, organizaci\u00f3n de ideas, expresi\u00f3n escrita y proceso escolar.")
        }
        "memory" {
            return (U "Memoria, estimulaci\u00f3n cognitiva, atenci\u00f3n y aprendizaje activo.")
        }
        "literacy" {
            return (U "Alfabetizaci\u00f3n inicial, primeras letras, aprendizaje positivo y acompa\u00f1amiento.")
        }
        "studyTechniques" {
            return (U "T\u00e9cnicas de estudio, organizaci\u00f3n escolar, planificaci\u00f3n y autonom\u00eda.")
        }
        "parentTips" {
            return (U "Familia acompa\u00f1ando el aprendizaje, rutinas, apoyo emocional y autonom\u00eda.")
        }
        "schoolDifficulties" {
            return (U "Dificultades escolares, acompa\u00f1amiento profesional, confianza y progreso.")
        }
        default {
            return (U "Aprendizaje infantil, familia, psicopedagog\u00eda y acompa\u00f1amiento profesional.")
        }
    }
}


function Select-VisualMode {
    param(
        [object]$Prompts,
        [string]$Brand,
        [string]$Category
    )

    $modes = @("emocional", "educativo", "familiar", "tecnologico", "juego")

    if ($Prompts.globalRules -and $Prompts.globalRules.visualModes) {
        $modes = @($Prompts.globalRules.visualModes)
    }

    switch ($Brand) {
        "neuroPlay" {
            $preferred = @("juego", "familiar", "emocional")
        }
        "portalSgt" {
            $preferred = @("tecnologico", "educativo", "familiar")
        }
        default {
            $preferred = @("emocional", "educativo", "familiar")
        }
    }

    $pool = @($preferred | Where-Object { $modes -contains $_ })
    if ($pool.Count -eq 0) {
        $pool = $modes
    }

    return ($pool | Get-Random)
}

function Get-VisualModeInstruction {
    param([string]$Mode)

    switch ($Mode) {
        "emocional" {
            return (U "Modo visual emocional: mostrar una escena humana cercana, mirada natural, gesto de confianza, avance o alivio. Debe sentirse real, c\u00e1lida y emp\u00e1tica.")
        }
        "educativo" {
            return (U "Modo visual educativo: mostrar actividad concreta de aprendizaje, materiales visibles, foco en proceso, orden y claridad.")
        }
        "familiar" {
            return (U "Modo visual familiar: mostrar v\u00ednculo entre adulto y ni\u00f1o, acompa\u00f1amiento cotidiano, ambiente de casa luminoso y positivo.")
        }
        "tecnologico" {
            return (U "Modo visual tecnol\u00f3gico: mostrar celular, tablet o computadora con interfaz clara, moderna y simple, sin texto legible inventado.")
        }
        "juego" {
            return (U "Modo visual juego: mostrar din\u00e1mica l\u00fadica, desaf\u00edo, materiales manipulables, participaci\u00f3n activa y expresi\u00f3n positiva.")
        }
        default {
            return (U "Modo visual: escena editorial moderna, humana, clara y con buen impacto para redes sociales.")
        }
    }
}

function Select-TextZone {
    param([string]$Brand)

    switch ($Brand) {
        "portalSgt" { return (@("superior", "inferior", "centro", "derecha") | Get-Random) }
        "neuroPlay" { return (@("izquierda", "derecha", "inferior", "superior", "centro") | Get-Random) }
        default { return (@("izquierda", "derecha", "inferior", "superior", "centro") | Get-Random) }
    }
}

function Get-PreferredLayoutFromTextZone {
    param([string]$TextZone)

    switch ($TextZone) {
        "izquierda" { return "left-card" }
        "derecha" { return "right-card" }
        "inferior" { return "bottom-card" }
        "superior" { return "top-card" }
        "centro" { return "center-card" }
        default { return "bottom-card" }
    }
}

function Get-TextZoneInstruction {
    param([string]$TextZone)

    switch ($TextZone) {
        "izquierda" {
            return (U "Composici\u00f3n: dejar el lado izquierdo con aire visual limpio, pocos detalles y buen contraste para una tarjeta de texto.")
        }
        "derecha" {
            return (U "Composici\u00f3n: dejar el lado derecho con aire visual limpio, pocos detalles y buen contraste para una tarjeta de texto.")
        }
        "inferior" {
            return (U "Composici\u00f3n: dejar la parte inferior con aire visual limpio para una tarjeta horizontal y un llamado a WhatsApp.")
        }
        "superior" {
            return (U "Composici\u00f3n: dejar la parte superior con aire visual limpio para una tarjeta horizontal.")
        }
        "centro" {
            return (U "Composici\u00f3n: dejar una zona central limpia, con el sujeto o escena en segundo plano y sin elementos importantes en el centro.")
        }
        default {
            return (U "Composici\u00f3n: dejar espacio libre claro para superponer texto y logo.")
        }
    }
}

function Get-BrandColorInstruction {
    param([string]$Brand)

    switch ($Brand) {
        "neuroPlay" {
            return (U "Paleta sugerida: azul, turquesa, amarillo, coral y acentos l\u00fadicos. Colorido, pero profesional.")
        }
        "portalSgt" {
            return (U "Paleta sugerida: azul, turquesa, verde suave, blanco y grises c\u00e1lidos. Tecnol\u00f3gico, claro y humano.")
        }
        default {
            return (U "Paleta sugerida: azul, turquesa, amarillo, coral y blanco. Psicopedag\u00f3gico, c\u00e1lido y profesional.")
        }
    }
}


function Get-NegativePrompt {
    param([object]$Prompts)

    $avoid = @()

    if ($Prompts.globalRules -and $Prompts.globalRules.avoid) {
        $avoid = @($Prompts.globalRules.avoid)
    }

    if ($avoid.Count -eq 0) {
        return (U "Evitar estilo cartoon, anime, pixar, texto dentro de la imagen, logos inventados, marcas de agua, dise\u00f1o frio.")
    }

    return "Evitar: " + ($avoid -join ", ") + "."
}

$content = Read-JsonUtf8 $ContentPath
$prompts = Read-JsonUtf8 $PromptsPath

$basePrompt = Get-PromptValue -Prompts $prompts -Brand $content.brandFocus -Category $content.category
$brandDisplay = Get-BrandDisplayName -Brand $content.brandFocus
$visualFocus = Get-VisualFocus -Brand $content.brandFocus -Category $content.category
$negativePrompt = Get-NegativePrompt -Prompts $prompts
$visualMode = Select-VisualMode -Prompts $prompts -Brand $content.brandFocus -Category $content.category
$textZone = Select-TextZone -Brand $content.brandFocus
$preferredLayout = Get-PreferredLayoutFromTextZone -TextZone $textZone
$visualModeInstruction = Get-VisualModeInstruction -Mode $visualMode
$textZoneInstruction = Get-TextZoneInstruction -TextZone $textZone
$brandColorInstruction = Get-BrandColorInstruction -Brand $content.brandFocus

$finalPromptParts = @(
    $basePrompt,
    "",
    "Marca principal: $brandDisplay.",
    "Tema de la publicacion: $($content.topic).",
    "Enfoque visual: $visualFocus",
    "Modo visual elegido: $visualMode.",
    $visualModeInstruction,
    $textZoneInstruction,
    $brandColorInstruction,
    "",
    (U "Crear una imagen base para flyer de Instagram, sin texto agregado dentro de la imagen. No incluir frases, letras, n\u00fameros, pizarras con texto, logos ni marcas de agua."),
    (U "Priorizar una escena con un punto focal claro, emoci\u00f3n reconocible y fondo limpio. Debe detener el scroll sin parecer una foto gen\u00e9rica de banco de im\u00e1genes."),
    (U "Formato cuadrado 1080x1080, composici\u00f3n moderna, luz natural, profundidad visual suave, alta calidad editorial."),
    "",
    $negativePrompt
)

$finalPrompt = ($finalPromptParts -join "`r`n")

$result = [pscustomobject]@{
    id = $content.id
    brandFocus = $content.brandFocus
    category = $content.category
    topic = $content.topic
    title = $content.title
    basePrompt = $basePrompt
    finalPrompt = $finalPrompt
    negativePrompt = $negativePrompt
    visualMode = $visualMode
    textZone = $textZone
    preferredLayout = $preferredLayout
    createdAt = (Get-Date).ToString("s")
}

Write-JsonUtf8 -Path $OutputPath -Data $result
Write-TextUtf8 -Path $OutputTxtPath -Text $finalPrompt

Write-Host "Prompt visual generado correctamente."
Write-Host "JSON:"
Write-Host $OutputPath
Write-Host "TXT:"
Write-Host $OutputTxtPath