param(
    [string]$Root = ""
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)

function Get-ProjectRoot {
    param([string]$RequestedRoot)
    if (-not [string]::IsNullOrWhiteSpace($RequestedRoot)) {
        return (Resolve-Path -LiteralPath $RequestedRoot).Path
    }
    if (-not [string]::IsNullOrWhiteSpace($PSScriptRoot)) {
        return (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot ".." )).Path
    }
    return (Get-Location).Path
}

$Root = Get-ProjectRoot -RequestedRoot $Root
$OutputFile = Join-Path $Root "config\content-bank.json"

function U([string]$Text) {
    return [regex]::Replace($Text, '\\u([0-9a-fA-F]{4})', {
        param($m)
        [char][convert]::ToInt32($m.Groups[1].Value, 16)
    })
}

$items = New-Object System.Collections.Generic.List[object]
$id = 1

function Add-Idea {
    param(
        [string]$Category,
        [string]$BrandFocus,
        [string]$Type,
        [string]$Title,
        [string]$FlyerText,
        [string[]]$Benefits,
        [bool]$UseNeuroPlayProduct,
        [bool]$UsePortalSgt
    )

    $script:items.Add([pscustomobject]@{
        id = $script:id
        category = $Category
        brandFocus = $BrandFocus
        type = $Type
        title = U $Title
        flyerText = U $FlyerText
        benefits = @($Benefits | ForEach-Object { U $_ })
        captionTemplate = $Type
        layoutType = "dynamic"
        useNeuroPlayProduct = $UseNeuroPlayProduct
        usePortalSgt = $UsePortalSgt
        cta = "Consultanos por WhatsApp al 11 2732-5400."
    })

    $script:id++
}

$aprende = @(
    @("attention","La atenci\u00f3n tambi\u00e9n se entrena","La concentraci\u00f3n puede fortalecerse con estrategias adecuadas."),
    @("attention","Concentrarse tambi\u00e9n se aprende","Cada ni\u00f1o puede desarrollar recursos para enfocarse mejor."),
    @("attention","Sostener la atenci\u00f3n requiere acompa\u00f1amiento","Peque\u00f1as rutinas pueden ayudar a organizar mejor el aprendizaje."),
    @("memory","La memoria se construye d\u00eda a d\u00eda","Recordar tambi\u00e9n requiere pr\u00e1ctica, juego y acompa\u00f1amiento."),
    @("memory","La memoria de trabajo ayuda a aprender","Acompa\u00f1ar la memoria favorece consignas, lectura y estudio."),
    @("reading","Leer es mucho m\u00e1s que reconocer letras","La lectura se acompa\u00f1a desde la comprensi\u00f3n, el ritmo y la confianza."),
    @("reading","La comprensi\u00f3n lectora tambi\u00e9n se acompa\u00f1a","Leer con sentido ayuda a construir aprendizajes m\u00e1s s\u00f3lidos."),
    @("writing","Cada ni\u00f1o escribe a su ritmo","La escritura se desarrolla con tiempo, pr\u00e1ctica y estrategias adecuadas."),
    @("writing","Escribir tambi\u00e9n es organizar ideas","La producci\u00f3n escrita necesita planificaci\u00f3n, confianza y acompa\u00f1amiento."),
    @("literacy","La alfabetizaci\u00f3n inicial es un proceso","Las primeras letras se aprenden mejor con juego, tiempo y gu\u00eda."),
    @("studyTechniques","Estudiar mejor vale m\u00e1s que estudiar m\u00e1s","Las t\u00e9cnicas de estudio ayudan a organizar tiempo, atenci\u00f3n y memoria."),
    @("parentTips","La familia tambi\u00e9n acompa\u00f1a el aprendizaje","Peque\u00f1as acciones en casa pueden sumar al proceso psicopedag\u00f3gico."),
    @("progressStories","Cada avance cuenta","Un peque\u00f1o logro puede ser el inicio de un cambio importante."),
    @("myths","No todos aprenden de la misma manera","Cada ni\u00f1o necesita estrategias acordes a su forma de aprender."),
    @("myths","Esperar no siempre alcanza","Consultar a tiempo permite acompa\u00f1ar mejor las dificultades escolares.")
)

$neuro = @(
    @("neuroPlay","Aprender jugando tambi\u00e9n es aprender","El juego en casa puede acompa\u00f1ar lo trabajado en sesi\u00f3n."),
    @("neuroPlay","El juego puede fortalecer la memoria","Algunos juegos ayudan a recordar, observar y concentrarse."),
    @("neuroPlay","Jugar en familia tambi\u00e9n acompa\u00f1a el desarrollo","Compartir juegos permite estimular habilidades desde casa."),
    @("neuroPlay","La atenci\u00f3n tambi\u00e9n se practica jugando","Los juegos pueden ayudar a sostener la concentraci\u00f3n de forma natural."),
    @("neuroPlay","El lenguaje tambi\u00e9n crece en el juego","Nombrar, describir y conversar durante el juego favorece la comunicaci\u00f3n."),
    @("neuroPlay","La l\u00f3gica se entrena con desaf\u00edos","Resolver, probar y pensar estrategias tambi\u00e9n es aprendizaje."),
    @("neuroPlay","La motricidad fina tambi\u00e9n se estimula jugando","Manipular piezas, encastrar y coordinar movimientos favorece el desarrollo.")
)

$portal = @(
    @("portalSgt","Seguimiento terap\u00e9utico desde casa","Las familias pueden consultar cada sesi\u00f3n desde celular o computadora."),
    @("portalSgt","Cada sesi\u00f3n queda registrada","Portal SGT permite acceder al seguimiento del proceso terap\u00e9utico."),
    @("portalSgt","M\u00e1s claridad para acompa\u00f1ar mejor","Ver sesiones, adjuntos y avances ayuda a las familias a estar informadas."),
    @("portalSgt","Informaci\u00f3n disponible 24x7","Portal SGT permite consultar avances desde cualquier dispositivo.")
)

while (($items | Where-Object brandFocus -eq "aprendeConMente").Count -lt 60) {
    $x = Get-Random $aprende
    Add-Idea $x[0] "aprendeConMente" "educational" $x[1] $x[2] @(
        "Acompa\u00f1amiento psicopedag\u00f3gico",
        "Estrategias personalizadas",
        "Orientaci\u00f3n a familias"
    ) $false $false
}

while (($items | Where-Object brandFocus -eq "neuroPlay").Count -lt 25) {
    $x = Get-Random $neuro
    Add-Idea $x[0] "neuroPlay" "neuroPlay" $x[1] $x[2] @(
        "Juego compartido",
        "Estimulaci\u00f3n en casa",
        "Recursos para familias"
    ) $true $false
}

while (($items | Where-Object brandFocus -eq "portalSgt").Count -lt 15) {
    $x = Get-Random $portal
    Add-Idea $x[0] "portalSgt" "portalSgt" $x[1] $x[2] @(
        "Sesiones registradas",
        "Acceso 24x7",
        "Materiales y adjuntos"
    ) $false $true
}

$json = $items | ConvertTo-Json -Depth 10
[System.IO.File]::WriteAllText($OutputFile, $json, [System.Text.UTF8Encoding]::new($false))

Write-Host "content-bank.json generado correctamente con $($items.Count) ideas."
Write-Host "Aprende con Mente:" (($items | Where-Object brandFocus -eq "aprendeConMente").Count)
Write-Host "Neuro Play:" (($items | Where-Object brandFocus -eq "neuroPlay").Count)
Write-Host "Portal SGT:" (($items | Where-Object brandFocus -eq "portalSgt").Count)
Write-Host $OutputFile