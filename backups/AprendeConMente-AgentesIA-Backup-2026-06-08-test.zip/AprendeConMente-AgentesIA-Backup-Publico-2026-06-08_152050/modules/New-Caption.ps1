param(
    [string]$Root = ""
)
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)

function Get-ProjectRoot {
    param([string]$RequestedRoot)
    if (-not [string]::IsNullOrWhiteSpace($RequestedRoot)) {
        return (Resolve-Path -LiteralPath $RequestedRoot).Path
    }
    if (-not [string]::IsNullOrWhiteSpace($PSScriptRoot)) {
        return (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot ".." )).Path
    }
    return (Get-Location).Path
}

$Root = Get-ProjectRoot -RequestedRoot $Root

$ContentPath = Join-Path $Root "output\last-content.json"
$BrandPath = Join-Path $Root "config\brand.json"
$GeneratorsPath = Join-Path $Root "config\content-generators.json"
$CaptionJsonPath = Join-Path $Root "output\last-caption.json"
$CaptionTxtPath = Join-Path $Root "output\captions\last-caption.txt"

function U([string]$Text) {
    return [regex]::Replace($Text, '\\u([0-9a-fA-F]{4})', {
        param($m)
        [char][convert]::ToInt32($m.Groups[1].Value, 16)
    })
}

function Read-JsonUtf8 {
    param([string]$Path)

    if (-not (Test-Path $Path)) {
        throw "No existe el archivo: $Path"
    }

    $json = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
    return $json | ConvertFrom-Json
}

function Write-TextUtf8 {
    param(
        [string]$Path,
        [string]$Text
    )

    $dir = Split-Path $Path -Parent

    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    [System.IO.File]::WriteAllText($Path, $Text, [System.Text.UTF8Encoding]::new($false))
}

function Write-JsonUtf8 {
    param(
        [string]$Path,
        [object]$Data
    )

    $json = $Data | ConvertTo-Json -Depth 30
    Write-TextUtf8 -Path $Path -Text $json
}

function Join-Hashtags {
    param([object]$Generators)

    if ($Generators.hashtags) {
        return (($Generators.hashtags | Select-Object -First 10) -join " ")
    }

    return "#Psicopedagogia #AprendeConMente #NeuroPlay #EstimulacionCognitiva #Aprendizaje"
}

function New-EducationalCaption {
    param(
        [object]$Content,
        [object]$Brand,
        [string]$Hashtags
    )

    $paragraphs = @(
        "Muchas familias consultan cuando aparecen dificultades relacionadas con $($Content.topic). A veces no se trata de falta de ganas, sino de que el ni\u00f1o necesita otras estrategias para organizarse, comprender o sostener mejor el aprendizaje.",
        "En Aprende con Mente trabajamos desde la psicopedagog\u00eda, la alfabetizaci\u00f3n inicial, las t\u00e9cnicas de estudio y la estimulaci\u00f3n cognitiva, siempre respetando el ritmo de cada ni\u00f1o.",
        "$($Content.flyerText)",
        "La familia tambi\u00e9n forma parte del proceso. Por eso buscamos que cada orientaci\u00f3n sea clara, posible y cercana a la vida cotidiana.",
        "$($Content.cta)",
        "$Hashtags"
    )

    return (($paragraphs | ForEach-Object { U $_ }) -join "`r`n`r`n")
}

function New-NeuroPlayCaption {
    param(
        [object]$Content,
        [object]$Brand,
        [string]$Hashtags
    )

    $paragraphs = @(
        "El juego tambi\u00e9n puede ser una forma de acompa\u00f1ar el desarrollo. Cuando una actividad se comparte en casa, el ni\u00f1o puede practicar habilidades importantes de una manera m\u00e1s cercana y natural.",
        "Desde Neuro Play pensamos los juegos como recursos para seguir estimulando memoria, atenci\u00f3n, lenguaje, l\u00f3gica y motricidad fuera del consultorio.",
        "$($Content.flyerText)",
        "La idea no es sumar presi\u00f3n, sino generar momentos de juego compartido que acompa\u00f1en lo trabajado en el proceso psicopedag\u00f3gico.",
        "$($Content.cta)",
        "$Hashtags"
    )

    return (($paragraphs | ForEach-Object { U $_ }) -join "`r`n`r`n")
}

function New-PortalCaption {
    param(
        [object]$Content,
        [object]$Brand,
        [string]$Hashtags
    )

    $paragraphs = @(
        "Acompa\u00f1ar un proceso terap\u00e9utico tambi\u00e9n implica poder seguirlo con claridad. Para muchas familias, tener informaci\u00f3n disponible ayuda a entender mejor cada etapa.",
        "Portal SGT permite consultar sesiones, materiales, adjuntos y avances desde celular o computadora, en un entorno pensado para facilitar el seguimiento familiar.",
        "$($Content.flyerText)",
        "De esta manera, el trabajo del profesional y el acompa\u00f1amiento de la familia pueden estar m\u00e1s conectados.",
        "$($Content.cta)",
        "$Hashtags"
    )

    return (($paragraphs | ForEach-Object { U $_ }) -join "`r`n`r`n")
}

$content = Read-JsonUtf8 $ContentPath
$brand = Read-JsonUtf8 $BrandPath
$generators = Read-JsonUtf8 $GeneratorsPath

$hashtags = Join-Hashtags -Generators $generators

switch ($content.brandFocus) {
    "neuroPlay" {
        $captionText = New-NeuroPlayCaption -Content $content -Brand $brand -Hashtags $hashtags
    }
    "portalSgt" {
        $captionText = New-PortalCaption -Content $content -Brand $brand -Hashtags $hashtags
    }
    default {
        $captionText = New-EducationalCaption -Content $content -Brand $brand -Hashtags $hashtags
    }
}

$wordCount = (($captionText -split "\s+") | Where-Object { $_.Trim().Length -gt 0 }).Count

$captionObject = [pscustomobject]@{
    id = $content.id
    title = $content.title
    brandFocus = $content.brandFocus
    category = $content.category
    topic = $content.topic
    caption = $captionText
    wordCount = $wordCount
    createdAt = (Get-Date).ToString("s")
}

Write-JsonUtf8 -Path $CaptionJsonPath -Data $captionObject
Write-TextUtf8 -Path $CaptionTxtPath -Text $captionText

Write-Host "Caption generado correctamente."
Write-Host "Palabras:" $wordCount
Write-Host "JSON:"
Write-Host $CaptionJsonPath
Write-Host "TXT:"
Write-Host $CaptionTxtPath