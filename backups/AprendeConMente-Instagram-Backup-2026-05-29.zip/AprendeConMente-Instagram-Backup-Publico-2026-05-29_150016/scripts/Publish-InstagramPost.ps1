[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)]
    [string]$PostDirectory,
    [Parameter(Mandatory)]
    [string]$PublicImageUrl,
    [string]$ApiBase = 'https://graph.instagram.com/v25.0'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$captionPath = Join-Path $PostDirectory 'caption.txt'
$metadataPath = Join-Path $PostDirectory 'metadata.json'
$credentialPath = Join-Path $root 'config\instagram.credential.xml'

if (-not (Test-Path -LiteralPath $captionPath)) {
    throw "No se encontró caption.txt en $PostDirectory."
}
if (Test-Path -LiteralPath $metadataPath) {
    $existingMetadata = Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json
    if ($existingMetadata.published -and $existingMetadata.instagramMediaId) {
        Write-Output "Instagram ya estaba publicado. Media ID: $($existingMetadata.instagramMediaId)"
        exit 0
    }
}
if ($env:INSTAGRAM_USER_ID -and $env:INSTAGRAM_ACCESS_TOKEN) {
    $instagramUserId = $env:INSTAGRAM_USER_ID
    $instagramAccessToken = $env:INSTAGRAM_ACCESS_TOKEN
}
elseif (Test-Path -LiteralPath $credentialPath) {
    $stored = Import-Clixml -LiteralPath $credentialPath
    $instagramUserId = $stored.UserId
    $credential = New-Object System.Management.Automation.PSCredential('instagram', $stored.AccessToken)
    $instagramAccessToken = $credential.GetNetworkCredential().Password
}
else {
    throw 'No se encontró la credencial de Instagram. Debe autorizarse la cuenta primero.'
}
if ($PublicImageUrl -notmatch '^https://') {
    throw 'Meta necesita una URL pública HTTPS para tomar la imagen.'
}

$caption = Get-Content -LiteralPath $captionPath -Raw
function Get-MetaErrorMessage {
    param([Parameter(Mandatory)]$ErrorRecord)
    $body = $ErrorRecord.ErrorDetails.Message
    if (-not $body -and $ErrorRecord.Exception.Response) {
        try {
            $reader = New-Object System.IO.StreamReader($ErrorRecord.Exception.Response.GetResponseStream())
            $body = $reader.ReadToEnd()
        }
        catch {
            $body = $null
        }
    }
    if ($body) {
        try {
            $parsed = $body | ConvertFrom-Json
            if ($parsed.error.message) {
                return "$($ErrorRecord.Exception.Message) Meta: $($parsed.error.message) (code $($parsed.error.code), type $($parsed.error.type))"
            }
        }
        catch {
            return "$($ErrorRecord.Exception.Message) Meta: $body"
        }
    }
    return $ErrorRecord.Exception.Message
}
$createBody = @{
    image_url = $PublicImageUrl
    caption = $caption
    access_token = $instagramAccessToken
}
$createUri = "$ApiBase/$instagramUserId/media"

if (-not $PSCmdlet.ShouldProcess($createUri, 'Crear y publicar el post en Instagram')) {
    return
}

try {
    $container = Invoke-RestMethod -Method Post -Uri $createUri -Body $createBody
}
catch {
    throw (Get-MetaErrorMessage $_)
}
if (-not $container.id) {
    throw 'Meta no devolvió un identificador de publicación.'
}

$statusUri = "$ApiBase/$($container.id)"
$ready = $false
for ($attempt = 1; $attempt -le 20; $attempt++) {
    try {
        $status = Invoke-RestMethod -Method Get -Uri $statusUri -Body @{
            fields = 'status_code'
            access_token = $instagramAccessToken
        }
    }
    catch {
        throw (Get-MetaErrorMessage $_)
    }
    if ($status.status_code -eq 'FINISHED') {
        $ready = $true
        break
    }
    if ($status.status_code -in @('ERROR', 'EXPIRED')) {
        throw "Meta no pudo preparar la imagen para publicar. Estado: $($status.status_code)."
    }
    Start-Sleep -Seconds 3
}
if (-not $ready) {
    throw 'La imagen no quedo lista para publicar despues de 60 segundos.'
}

$publishBody = @{
    creation_id = $container.id
    access_token = $instagramAccessToken
}
$publishUri = "$ApiBase/$instagramUserId/media_publish"
try {
    $published = Invoke-RestMethod -Method Post -Uri $publishUri -Body $publishBody
}
catch {
    throw (Get-MetaErrorMessage $_)
}

if (Test-Path -LiteralPath $metadataPath) {
    $metadata = Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json
    $metadata.published = $true
    $metadata | Add-Member -NotePropertyName instagramMediaId -NotePropertyValue $published.id -Force
    $metadata | Add-Member -NotePropertyName publishedAt -NotePropertyValue (Get-Date).ToString('o') -Force
    $metadata | ConvertTo-Json | Set-Content -LiteralPath $metadataPath -Encoding UTF8
}

Write-Output "Publicado en Instagram. Media ID: $($published.id)"
