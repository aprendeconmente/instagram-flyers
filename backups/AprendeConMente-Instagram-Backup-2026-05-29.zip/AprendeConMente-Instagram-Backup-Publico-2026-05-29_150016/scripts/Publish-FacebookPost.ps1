[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)]
    [string]$PostDirectory,
    [Parameter(Mandatory)]
    [string]$PublicImageUrl,
    [string]$ApiBase = 'https://graph.facebook.com/v25.0'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$captionPath = Join-Path $PostDirectory 'caption.txt'
$metadataPath = Join-Path $PostDirectory 'metadata-facebook.json'
$imagePath = Join-Path $PostDirectory 'post.png'
$credentialPath = Join-Path $root 'config\facebook.credential.xml'

if (-not (Test-Path -LiteralPath $captionPath)) {
    throw "No se encontro caption.txt en $PostDirectory."
}
if (-not (Test-Path -LiteralPath $imagePath)) {
    throw "No se encontro post.png en $PostDirectory."
}
if (Test-Path -LiteralPath $metadataPath) {
    $existingMetadata = Get-Content -LiteralPath $metadataPath -Raw | ConvertFrom-Json
    if ($existingMetadata.published -and ($existingMetadata.facebookPhotoId -or $existingMetadata.facebookPostId)) {
        Write-Output "Facebook ya estaba publicado. Foto ID: $($existingMetadata.facebookPhotoId)"
        exit 0
    }
}
if ($env:FACEBOOK_PAGE_ID -and $env:FACEBOOK_PAGE_ACCESS_TOKEN) {
    $pageId = $env:FACEBOOK_PAGE_ID
    $pageAccessToken = $env:FACEBOOK_PAGE_ACCESS_TOKEN
}
elseif (Test-Path -LiteralPath $credentialPath) {
    $stored = Import-Clixml -LiteralPath $credentialPath
    $pageId = $stored.PageId
    $credential = New-Object System.Management.Automation.PSCredential('facebook', $stored.AccessToken)
    $pageAccessToken = $credential.GetNetworkCredential().Password
}
else {
    throw 'No se encontro la credencial de la Pagina de Facebook. Debe autorizarse primero.'
}
if ($PublicImageUrl -notmatch '^https://') {
    throw 'Facebook necesita una URL publica HTTPS para tomar la imagen.'
}

$caption = Get-Content -LiteralPath $captionPath -Raw
$captionLines = @($caption -split "`r?`n" | Where-Object { $_.Trim() -and $_ -notmatch '^\s*#' })
$shortCaption = if ($captionLines.Count -gt 0) {
    $first = $captionLines[0]
    "$first`n`nWhatsApp: 11 2732-5400`nhttps://aprendeconmente.github.io/web/"
} else {
    'Aprende con Mente'
}
function Get-MetaErrorMessage {
    param([Parameter(Mandatory)]$ErrorRecord)
    $body = $ErrorRecord.ErrorDetails.Message
    if (-not $body -and $ErrorRecord.Exception.Response) {
        try {
            $reader = New-Object System.IO.StreamReader($ErrorRecord.Exception.Response.GetResponseStream())
            $body = $reader.ReadToEnd()
        }
        catch {
            $body = $null
        }
    }
    if ($body) {
        try {
            $parsed = $body | ConvertFrom-Json
            if ($parsed.error.message) {
                return "$($ErrorRecord.Exception.Message) Meta: $($parsed.error.message) (code $($parsed.error.code), type $($parsed.error.type))"
            }
        }
        catch {
            return "$($ErrorRecord.Exception.Message) Meta: $body"
        }
    }
    return $ErrorRecord.Exception.Message
}
$photoUri = "$ApiBase/$pageId/photos"
if (-not $PSCmdlet.ShouldProcess($photoUri, 'Publicar la foto en la Pagina de Facebook')) {
    return
}

$published = $null
$attempts = @(
    [pscustomobject]@{ Label = 'caption-completo'; Message = $caption },
    [pscustomobject]@{ Label = 'caption-corto'; Message = $shortCaption },
    [pscustomobject]@{ Label = 'solo-imagen'; Message = '' }
)
$lastError = $null
foreach ($attempt in $attempts) {
    $photoForm = @{
        source = Get-Item -LiteralPath $imagePath
        published = $true
        access_token = $pageAccessToken
    }
    if ($attempt.Message) {
        $photoForm.message = $attempt.Message
    }
    try {
        $published = Invoke-RestMethod -Method Post -Uri $photoUri -Form $photoForm
        break
    }
    catch {
        $lastError = Get-MetaErrorMessage $_
        if ($lastError -notmatch '500|Internal Server Error|reduce the amount of data') {
            throw $lastError
        }
        Start-Sleep -Seconds 8
    }
}
if (-not $published) {
    throw $lastError
}
if (-not $published.id -and -not $published.post_id) {
    throw 'Facebook no devolvio un identificador para la publicacion.'
}

$metadata = [ordered]@{
    published = $true
    facebookPhotoId = $published.id
    facebookPostId = $published.post_id
    publishedAt = (Get-Date).ToString('o')
    publicImageUrl = $PublicImageUrl
}
$metadata | ConvertTo-Json | Set-Content -LiteralPath $metadataPath -Encoding UTF8
Write-Output "Publicado en Facebook. Foto ID: $($published.id)"
