[CmdletBinding()]
param(
    [datetime]$Date = (Get-Date),
    [ValidateSet('1200', '1600')]
    [string]$Slot = '1200'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$dateKey = $Date.ToString('yyyy-MM-dd')
$instagramSlot = if ($Slot -eq '1200') { '1100' } else { '1500' }
$postDirectory = Join-Path $root "output\$dateKey\$instagramSlot"
$imagePath = Join-Path $postDirectory 'post.png'
$logPath = Join-Path $root 'logs\assistant.log'

try {
    & (Join-Path $PSScriptRoot 'New-DailyPost.ps1') -Date $Date -Slot $instagramSlot
    $publicImageUrl = & (Join-Path $PSScriptRoot 'Publish-ImageToGitHub.ps1') -ImagePath $imagePath -DateKey "$dateKey-$instagramSlot"
    $publishResult = & (Join-Path $PSScriptRoot 'Publish-FacebookPost.ps1') -PostDirectory $postDirectory -PublicImageUrl $publicImageUrl -Confirm:$false
    $logTag = if (($publishResult -join ' ') -match 'ya estaba publicado') { 'FACEBOOK-YA-PUBLICADO' } else { 'FACEBOOK-PUBLICADO' }
    "[$(Get-Date -Format s)] $logTag $dateKey $Slot desde-IG-$instagramSlot $publicImageUrl" | Add-Content -LiteralPath $logPath -Encoding UTF8
}
catch {
    "[$(Get-Date -Format s)] ERROR-FACEBOOK $dateKey $Slot $($_.Exception.Message)" | Add-Content -LiteralPath $logPath -Encoding UTF8
    throw
}
